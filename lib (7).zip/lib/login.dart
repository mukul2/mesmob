import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/Screens/create_account_page.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:http/http.dart' as http;

class Login extends StatefulWidget {
  final FirebaseAuth auth;
  final FirebaseFirestore firestore;

  const Login({
    Key key,
    @required this.auth,
    @required this.firestore,
  }) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
//assets/background.png
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Align(alignment: Alignment.center,
            //child: Image.asset("assets/background.png",fit: BoxFit.cover,),
            child: Container(color: Color.fromARGB(100,234, 250, 241),),
          ),
          Align(alignment: Alignment.center,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  Card(
                    elevation: 10,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(0.0),
                    ),
                    color: Colors.white,
                    child: Container(
                      width: 400,
                      // height: 400,
                      child: Padding(
                        padding: const EdgeInsets.all(60.0),
                        child: Builder(builder: (BuildContext context) {
                          return Wrap(
                            // mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Image.asset(
                              //   "assets/stahtlogogreen.jpg",
                              //   height: 100,
                              // ),
                              Container(
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  child: Image.asset("assets/maulaji_sqr.png",fit: BoxFit.cover,)),
                              TextFormField(
                                textAlign: TextAlign.left,
                                decoration: const InputDecoration(hintText: "Email"),
                                controller: _emailController,
                              ),
                              TextFormField(
                                textAlign: TextAlign.left,
                                decoration:
                                const InputDecoration(hintText: "Password"),
                                controller: _passwordController,
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: InkWell(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => CreateAccount(
                                                    auth: widget.auth,
                                                    firestore: widget.firestore,
                                                  )),
                                            );

                                            //CreateAccount
                                          },
                                          child: Text(
                                            "Create an Account",
                                            style: TextStyle(
                                                color: Colors.blue,
                                                fontWeight: FontWeight.bold),
                                          )),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: RaisedButton(
                                        color: Theme.of(context).primaryColor,
                                        onPressed: () async {
                                          final String retVal =
                                          await Auth(auth: widget.auth).signIn(
                                            email: _emailController.text,
                                            password: _passwordController.text,
                                          );
                                          if (retVal == "Success") {
                                            _emailController.clear();
                                            _passwordController.clear();
                                          } else {
                                            Scaffold.of(context).showSnackBar(
                                                SnackBar(content: Text(retVal)));
                                          }
                                        },
                                        child: const Text(
                                          "SIGN IN",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          );
                        }),
                      ),
                    ),
                  ),


                  Card(
                    elevation: 10,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(0.0),
                    ),
                    color: Colors.white,
                    child: Container(
                      width: 400,
                      // height: 400,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PhoneVerificationWidget(
                                  auth: widget.auth,
                                  firestore: widget.firestore,
                                )),
                          );
                        },
                        child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Login via OTP",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, color: Colors.blue),
                              ),
                            )),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PhoneVerificationWidget extends StatefulWidget {
  FirebaseAuth auth;

  FirebaseFirestore firestore;

  String countryCode = "Select";

  PhoneVerificationWidget({this.auth, this.firestore});

  List allCountryCodes;

  @override
  _PhoneVerificationWidgetState createState() =>
      _PhoneVerificationWidgetState();
}

class _PhoneVerificationWidgetState extends State<PhoneVerificationWidget> {
  TextEditingController controller = TextEditingController();
  final GlobalKey _menuKey = new GlobalKey();
  var button;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    downloadCountryCodes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 400,
          // height: 400,
          child: Wrap(
            children: [
              Card(
                elevation: 10,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0.0),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 90,
                      child: button,
                    ),
                    Container(
                      width: 294,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: controller,
                          decoration: InputDecoration(hintText: "Phone number"),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Card(
                elevation: 10,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0.0),
                ),
                child: InkWell(
                  onTap: () async {
                    print(widget.countryCode + controller.text);
                    ConfirmationResult confirmationResult = await widget.auth
                        .signInWithPhoneNumber(
                            widget.countryCode + controller.text);

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ConfirmOTP(
                                auth: widget.auth,
                                firestore: widget.firestore,
                                confirmationResult: confirmationResult,
                              )),
                    );
                  },
                  child: Container(
                    color: Theme.of(context).primaryColor,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Center(
                          child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Send OTP",
                          style: TextStyle(color: Colors.white),
                        ),
                      )),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void initCountryCodes() {
    List allItem = [];
    for (int i = 0; i < widget.allCountryCodes.length; i++) {
      allItem.add(PopupMenuItem<String>(
          child: Text(widget.allCountryCodes[i]["name"] +
              " +" +
              widget.allCountryCodes[i]["callingCodes"].first),
          value: "+" + widget.allCountryCodes[i]["callingCodes"].first));
    }

    button = new PopupMenuButton(
      child: Center(child: Text(widget.countryCode)),
      key: _menuKey,
      itemBuilder: (context) {
        return List.generate(allItem.length, (i) {
          return PopupMenuItem<String>(
              child: Text(widget.allCountryCodes[i]["name"] +
                  " +" +
                  widget.allCountryCodes[i]["callingCodes"].first),
              value: "+" + widget.allCountryCodes[i]["callingCodes"].first);
        });
      },
      onSelected: (String choice) {
        setState(() {
          widget.countryCode = choice;

          button = new PopupMenuButton(
            child: Center(child: Text(widget.countryCode)),
            key: _menuKey,
            itemBuilder: (context) {
              return List.generate(allItem.length, (i) {
                return PopupMenuItem<String>(
                    child: Text(widget.allCountryCodes[i]["name"] +
                        " +" +
                        widget.allCountryCodes[i]["callingCodes"].first),
                    value:
                        "+" + widget.allCountryCodes[i]["callingCodes"].first);
              });
            },
            onSelected: (String choice) {
              setState(() {
                widget.countryCode = choice;
                button = new PopupMenuButton(
                  child: Center(child: Text(widget.countryCode)),
                  key: _menuKey,
                  itemBuilder: (context) {
                    return List.generate(allItem.length, (i) {
                      return PopupMenuItem<String>(
                          child: Text(widget.allCountryCodes[i]["name"] +
                              " +" +
                              widget.allCountryCodes[i]["callingCodes"].first),
                          value: "+" +
                              widget.allCountryCodes[i]["callingCodes"].first);
                    });
                  },
                  onSelected: (String choice) {
                    setState(() {
                      widget.countryCode = choice;
                    });
                  },
                );
              });
            },
          );
        });
      },
    );
  }

  void downloadCountryCodes() async {
    widget.firestore.collection("country").get().then((value) {
      print("size " + value.docs.first.data()["data"]);
      if (value.size > 0 && value.docs.length > 0) {
        setState(() {
          widget.allCountryCodes = jsonDecode(value.docs.first.data()["data"]);
        });
        print("size " + widget.allCountryCodes.length.toString());
        initCountryCodes();
      }
    });
  }
}

class ConfirmOTP extends StatefulWidget {
  FirebaseAuth auth;

  FirebaseFirestore firestore;

  ConfirmationResult confirmationResult;

  String countryCode = "Select";

  ConfirmOTP({this.auth, this.firestore, this.confirmationResult});

  @override
  _ConfirmOTPState createState() => _ConfirmOTPState();
}

class _ConfirmOTPState extends State<ConfirmOTP> {
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 400,
          // height: 400,
          child: Wrap(
            children: [
              Card(
                elevation: 10,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0.0),
                ),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: controller,
                      decoration: InputDecoration(hintText: "OTP"),
                    ),
                  ),
                ),
              ),
              Card(
                elevation: 10,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0.0),
                ),
                child: InkWell(
                  onTap: () async {
                    widget.confirmationResult
                        .confirm(controller.text)
                        .then((value) {
                      if (value.user != null && value.user.uid != null) {




                        widget.firestore.collection("users")
                            .where("uid", isEqualTo: value.user.uid)
                            .get().then((valueD) async{
                           if(valueD.size>0 &&valueD.docs.length>0)  {

                             Navigator.pop(context);
                             Navigator.pop(context);
                             // Navigator.push(
                             //   context,
                             //   MaterialPageRoute(
                             //       builder: (context) => OTPConfirmed(
                             //         auth: widget.auth,
                             //         firestore: widget.firestore,queryDocumentSnapshot:valueD.docs.first ,
                             //       )),
                             // );
                           } else{

                             await widget.firestore.collection("users").add({"name":"","uid": value.user.uid,"email":"","phone":value.user.phoneNumber});
                             Navigator.pop(context);
                             Navigator.pop(context);
                             // widget.firestore.collection("users")
                             //     .where("uid", isEqualTo: value.user.uid)
                             //     .get().then((value) {
                             //   if(value.size>0 &&value.docs.length>0)  {
                             //     Navigator.push(
                             //       context,
                             //       MaterialPageRoute(
                             //           builder: (context) => OTPConfirmed(
                             //             auth: widget.auth,
                             //             firestore: widget.firestore,queryDocumentSnapshot:valueD.docs.first ,
                             //           )),
                             //     );
                             //   }
                             // });
                             // Navigator.push(
                             //   context,
                             //   MaterialPageRoute(
                             //       builder: (context) => OTPConfirmedNewProfile(
                             //         auth: widget.auth,
                             //         firestore: widget.firestore,
                             //       )),
                             // );
                           }
                        });





                      }
                    });
                    // print(widget.countryCode+controller.text);
                    // ConfirmationResult confirmationResult = await widget.auth.signInWithPhoneNumber(widget.countryCode+controller.text);
                    // dfd
                  },
                  child: Container(
                    color: Theme.of(context).primaryColor,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Center(
                          child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Verify",
                          style: TextStyle(color: Colors.white),
                        ),
                      )),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OTPConfirmed extends StatefulWidget {
  FirebaseAuth auth;


  FirebaseFirestore firestore;

  String countryCode = "Select";
  QueryDocumentSnapshot queryDocumentSnapshot ;


  OTPConfirmed({this.auth, this.firestore,this.queryDocumentSnapshot});

  @override
  _state createState() => _state();
}

class _state extends State<OTPConfirmed> {
  TextEditingController controller = TextEditingController();
  TextEditingController controllerName = new TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   // controllerName.text = widget.queryDocumentSnapshot.data()["name"].toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text(widget.queryDocumentSnapshot.data().toString()),
            CircleAvatar(radius: 40,),
            TextFormField(controller: controllerName,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.all(10),

              ),
            )
          ],
        ),
      ),
    );
  }
}




class OTPConfirmedNewProfile extends StatefulWidget {
  FirebaseAuth auth;


  FirebaseFirestore firestore;



  OTPConfirmedNewProfile({this.auth, this.firestore});

  @override
  _stateNewProfile createState() => _stateNewProfile();
}

class _stateNewProfile extends State<OTPConfirmedNewProfile> {
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("Verified"),
    );
  }
}

