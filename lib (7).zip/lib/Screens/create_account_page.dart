import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
class CreateAccount extends StatefulWidget {
  final FirebaseAuth auth;
  final FirebaseFirestore firestore;

  const CreateAccount({
    Key key,
    @required this.auth,
    @required this.firestore,
  }) : super(key: key);

  @override
  _State createState() => _State();
}

class _State extends State<CreateAccount> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _displayNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(0.0),
          ),
          color: Colors.white,
          child: Container(
            width: 400,
            // height: 400,
            child: Padding(
              padding: const EdgeInsets.all(60.0),
              child: Builder(builder: (BuildContext context) {
                return Wrap(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Image.asset(
                    //   "assets/stahtlogogreen.jpg",
                    //   height: 100,
                    // ),
                    Container(width: MediaQuery.of(context).size.width,child: Text("Maulaji Messenger - Create Account",style: TextStyle(fontSize: 20),)),
                    TextFormField(
                      textAlign: TextAlign.left,
                      decoration: const InputDecoration(hintText: "Display Name"),
                      controller: _displayNameController,
                    ),
                    TextFormField(
                      textAlign: TextAlign.left,
                      decoration: const InputDecoration(hintText: "Email"),
                      controller: _emailController,
                    ),
                    TextFormField(
                      textAlign: TextAlign.left,
                      decoration: const InputDecoration(hintText: "Password"),
                      controller: _passwordController,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0,20, 0, 0),
                      child:Card( shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0.0),
                ),color: Theme.of(context).primaryColor,
                        child: Container(width: MediaQuery.of(context).size.width,
                          child: Center(
                            child: InkWell(
                                onTap: () async{
                                  //TODO
                                  final bool retVal =
                                  await Auth(firestore: widget.firestore,auth: widget.auth).createAccount(
                                    email: _emailController.text,
                                    password: _passwordController.text,
                                    name: _displayNameController.text
                                  );

                                  if (retVal ) {
                                    _emailController.clear();
                                    _passwordController.clear();
                                    _displayNameController.clear();

                                    await widget.auth.currentUser.updateProfile(displayName: _displayNameController.text);
                                    Navigator.of(context).pop();
                                  } else {
                                    Scaffold.of(context)
                                        .showSnackBar(SnackBar(content: Text(retVal.toString())));
                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: Text(
                                    "Create an Account",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                        ),
                      ),
                    ),



                  ],
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
