import 'dart:async';
import 'dart:collection';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:async';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'dart:io';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/src/foundation/constants.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:maulajimessenger/call/GroupCall.dart';
import 'package:maulajimessenger/call/WebCallingSimple.dart';
import 'package:maulajimessenger/call/WebCallingSimpleConf.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/io.dart';
StreamSocket streamSocket = new StreamSocket();

HashMap onlineUser = new HashMap<String, String>();

class Home extends StatefulWidget {
  int selectedTabMenu = 0;

  bool isSearchModeOn = false;
  bool isCallFullScreen = true;
  String userStatus = "free";
  int CallDuration = 0;

  int selectedItem = 0;
  String partnerId;
  String partnerName;

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;
  dynamic chatBody;
  SharedPreferences sharedPreferences;
  bool showMobileView = false;
  bool showProfileCompleteDialog = false;

  dynamic currentProfile;

  bool shouldShowIncomming = false;
  bool isRingTonePlaying = false;
  Widget callWidget = Text("");
  bool callWidgetShow = false;

  bool showMiniProfile = false;

  bool showSplash = true;
  String searchKey = "";

  int mobileViewLevel = 1;

  Home({
    Key key,
    @required this.auth,
    @required this.firestore,
    @required this.sharedPreferences,
  }) : super(key: key);

  @override
  _State createState() => _State();
}

class _State extends State<Home> {
  bool audioVolume = true;
  IO.Socket socket2;

  doSomething(data) {
    setState(() {
      widget.chatBody = data;
    });
  }

  final GlobalKey _menuKey = new GlobalKey();
  TextEditingController searchController = new TextEditingController();
  AudioPlayer audioPlayer;

  playLocal() async {
    // audioPlayer.resume();

    if (widget.isRingTonePlaying == false) {
      setState(() {
        widget.isRingTonePlaying = true;
      });
      audioPlayer.resume();
      setState(() {
        widget.isRingTonePlaying = true;
      });
    }
  }

  initAudio() async {
    audioPlayer = await AudioPlayer();
    if (kIsWeb) {
      await audioPlayer.setUrl("assets/assets/skype_ringtone.mp3",
          isLocal: true);
    } else {
      final byteData = await rootBundle.load('assets/skype_ringtone.mp3');

      final file =
          File('${(await getTemporaryDirectory()).path}/skype_ringtone.mp3');
      await file.writeAsBytes(byteData.buffer
          .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));
      //  audioPlayer.play(file.path,isLocal: true);
      audioPlayer.setUrl(file.path, isLocal: true);
    }

    // await audioPlayer.setUrl("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3");
  }

  @override
  void initState() {
    initSignaling();

    Future.delayed(Duration(seconds: 3), () {
      setState(() {
        widget.showSplash = false;
      });
    });

    initAudio();
    // TODO: implement initState
    super.initState();

    widget.firestore
        .collection("users")
        .where("uid", isEqualTo: widget.auth.currentUser.uid)
        .snapshots()
        .listen((value) {
      if (value.size > 0 && value.docs.length > 0) {
        if (value.docs.first.exists && value.docs.first.data() != null) {
          if (value.docs.first.data()["name"] == "" ||
              value.docs.first.data()["email"] == "" ||
              value.docs.first.data()["phone"] == "") {
            setState(() {
              // widget.showProfileCompleteDialog = true;
              widget.currentProfile = value.docs.first.data();
            });
          } else {
            setState(() {
              widget.showProfileCompleteDialog = false;
            });
          }
        }
      }
    });

    widget.firestore
        .collection("users")
        .where("uid", isEqualTo: widget.auth.currentUser.uid)
        .get()
        .then((value) {
      if (value.size > 0 && value.docs.length > 0) {
        if (value.docs.first.exists && value.docs.first.data() != null) {
          if (value.docs.first.data()["name"] == "" ||
              value.docs.first.data()["email"] == "" ||
              value.docs.first.data()["phone"] == "") {
            setState(() {
              // widget.showProfileCompleteDialog = true;
              widget.currentProfile = value.docs.first.data();
            });
          } else {
            setState(() {
              widget.showProfileCompleteDialog = false;
            });
          }
        }
      }
    });
    //save status

    if (true) {
      Timer.periodic(Duration(milliseconds: 5000), (timer) {
        if (mounted) {
          widget.firestore
              .collection("user_status")
              .doc(widget.auth.currentUser.uid)
              .set({
            "status": widget.userStatus,
            "time": DateTime.now().millisecondsSinceEpoch
          });
        } else {
          timer.cancel();
        }
      });
    }

    //call income listener
    if (true) {
      Timer.periodic(Duration(milliseconds: 1000), (timer) {
        if (mounted) {
          widget.firestore
              .collection("incall")
              .doc(widget.auth.currentUser.uid)
              .get()
              .then((value) {
            if (value.exists) {
              if ((value.data()["time"] + 2000) >
                  DateTime.now().millisecondsSinceEpoch) {
                audioPlayer.pause();

                if (widget.isRingTonePlaying == true) {
                  setState(() {
                    widget.isRingTonePlaying = false;
                  });
                }
                if (widget.shouldShowIncomming == true) {
                  setState(() {
                    widget.shouldShowIncomming = false;
                  });
                }
              } else {
                widget.firestore
                    .collection("incomming")
                    .doc(widget.auth.currentUser.uid)
                    .get()
                    .then((value) {
                  if (value.exists) {
                    if ((value.data()["time"] + 2000) >
                        DateTime.now().millisecondsSinceEpoch) {
                      widget.firestore
                          .collection("callQue")
                          .doc(widget.auth.currentUser.uid)
                          .snapshots()
                          .listen((valueCaller) {
                        if (valueCaller.exists &&
                            valueCaller.data() != null &&
                            valueCaller.data()["active"] == null) {
                          if (audioVolume) {
                            playLocal();
                          }

                          if (widget.shouldShowIncomming == false) {
                            setState(() {
                              widget.shouldShowIncomming = true;
                              widget.partnerId = valueCaller.data()["caller"];
                              widget.partnerName =
                                  valueCaller.data()["callerName"];
                            });
                            // initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context); initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context);
                          }
                        } else {
                          audioPlayer.pause();
                          if (widget.isRingTonePlaying == true) {
                            setState(() {
                              widget.isRingTonePlaying = false;
                            });
                          }
                          if (widget.shouldShowIncomming == true) {
                            setState(() {
                              widget.shouldShowIncomming = false;
                            });
                          }
                        }
                      });

                      widget.firestore
                          .collection("callQue")
                          .doc(widget.auth.currentUser.uid)
                          .get()
                          .then((valueCaller) {});
                    } else {
                      audioPlayer.pause();
                      if (widget.isRingTonePlaying == true) {
                        setState(() {
                          widget.isRingTonePlaying = false;
                        });
                      }
                      if (widget.shouldShowIncomming == true) {
                        setState(() {
                          widget.shouldShowIncomming = false;
                        });
                      }
                    }
                  } else {
                    audioPlayer.pause();

                    if (widget.isRingTonePlaying == true) {
                      setState(() {
                        widget.isRingTonePlaying = false;
                      });
                    }
                    if (widget.shouldShowIncomming == true) {
                      setState(() {
                        widget.shouldShowIncomming = false;
                      });
                    }
                  }
                });
              }
            } else {
              widget.firestore
                  .collection("incomming")
                  .doc(widget.auth.currentUser.uid)
                  .get()
                  .then((value) {
                if (value.exists) {
                  if ((value.data()["time"] + 2000) >
                      DateTime.now().millisecondsSinceEpoch) {
                    widget.firestore
                        .collection("callQue")
                        .doc(widget.auth.currentUser.uid)
                        .snapshots()
                        .listen((valueCaller) {
                      if (valueCaller.exists &&
                          valueCaller.data() != null &&
                          valueCaller.data()["active"] == null) {
                        if (audioVolume) {
                          playLocal();
                        }

                        if (widget.shouldShowIncomming == false) {
                          setState(() {
                            widget.shouldShowIncomming = true;
                            widget.partnerId = valueCaller.data()["caller"];
                            widget.partnerName =
                                valueCaller.data()["callerName"];
                          });
                          // initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context); initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context);
                        }
                      } else {
                        audioPlayer.pause();
                        if (widget.isRingTonePlaying == true) {
                          setState(() {
                            widget.isRingTonePlaying = false;
                          });
                        }
                        if (widget.shouldShowIncomming == true) {
                          setState(() {
                            widget.shouldShowIncomming = false;
                          });
                        }
                      }
                    });

                    // widget.firestore
                    //     .collection("callQue")
                    //     .doc(widget.auth.currentUser.uid)
                    //     .get()
                    //     .then((valueCaller) {
                    //   if (valueCaller.exists && valueCaller.data() != null &&
                    //       valueCaller.data()["active"] != false){
                    //     if (audioVolume) {
                    //       playLocal();
                    //     }
                    //
                    //   if (widget.shouldShowIncomming == false)
                    //     setState(() {
                    //       widget.shouldShowIncomming = true;
                    //       widget.partnerId = valueCaller.data()["caller"];
                    //     });
                    // }
                    //   //initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context); initCallIntent("a", widget.auth.currentUser.uid, widget.partnerId, false, widget.firestore, context);
                    //
                    // });
                  } else {
                    audioPlayer.pause();

                    if (widget.isRingTonePlaying == true) {
                      setState(() {
                        widget.isRingTonePlaying = false;
                      });
                    }
                    if (widget.shouldShowIncomming == true) {
                      setState(() {
                        widget.shouldShowIncomming = false;
                      });
                    }
                  }
                } else {
                  audioPlayer.pause();
                  if (widget.isRingTonePlaying == true) {
                    setState(() {
                      widget.isRingTonePlaying = false;
                    });
                  }
                  if (widget.shouldShowIncomming == true) {
                    setState(() {
                      widget.shouldShowIncomming = false;
                    });
                  }
                }
              });
            }
          });
        } else {
          audioPlayer.pause();
          if (widget.isRingTonePlaying == true) {
            setState(() {
              widget.isRingTonePlaying = false;
            });
          }
          if (widget.shouldShowIncomming == true) {
            setState(() {
              widget.shouldShowIncomming = false;
            });
          }
          timer.cancel();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width > 500) {
      setState(() {
        widget.showMobileView = false;
        //widget.isCallFullScreen = false;
      });
    } else {
      setState(() {
        widget.showMobileView = true;
        //widget.isCallFullScreen = true;
      });
    }

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.fromLTRB(0, kIsWeb ? 0 : 30, 0, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
              child: widget.callWidgetShow && widget.showMobileView
                  ? Container(
                      height: widget.isCallFullScreen
                          ? MediaQuery.of(context).size.height
                          : 50,
                      width: MediaQuery.of(context).size.width,
                      color: Colors.redAccent,
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                                height: MediaQuery.of(context).size.height - 70,
                                child: widget.callWidget),
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: InkWell(
                                onTap: () {
                                  setState(() {
                                    widget.isCallFullScreen =
                                        !widget.isCallFullScreen;
                                  });
                                },
                                child: Container(
                                    height: 50,
                                    width: MediaQuery.of(context).size.width,
                                    color: Colors.redAccent,
                                    child: Center(
                                        child: Text(
                                      widget.isCallFullScreen
                                          ? "Back to Chat"
                                          : "Back to Call",
                                      style: TextStyle(color: Colors.white),
                                    )))),
                          ),
                        ],
                      ),
                    )
                  : Container(
                      height: 0,
                      width: 0,
                    ),
            ),
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: !widget.showMobileView
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              getFndList(),
                              Container(
                                color: Colors.grey,
                                width: 1,
                                height: widget.showMobileView &&
                                        widget.callWidgetShow
                                    ? MediaQuery.of(context).size.height - 70
                                    : MediaQuery.of(context).size.height,
                              ),
                              getBody(),
                            ],
                          )
                        : widget.mobileViewLevel == 1
                            ? Stack(
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: getFndList(),
                                  ),
                                  Align(
                                    alignment: Alignment.center,
                                    child: !widget.showMobileView
                                        ? Align(
                                            alignment: Alignment.topRight,
                                            child: Visibility(
                                              visible: widget.callWidgetShow,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Card(
                                                  elevation: 10,
                                                  child: Container(
                                                    //color: Colors.grey,
                                                    height: widget
                                                            .isCallFullScreen
                                                        ? MediaQuery.of(context)
                                                            .size
                                                            .height
                                                        : 300,
                                                    width: widget
                                                            .isCallFullScreen
                                                        ? MediaQuery.of(context)
                                                                .size
                                                                .width -
                                                            350
                                                        : (300),
                                                    child: Stack(
                                                      children: [
                                                        Align(
                                                          alignment:
                                                              Alignment.center,
                                                          child:
                                                              widget.callWidget,
                                                        ),
                                                        Align(
                                                          alignment: Alignment
                                                              .bottomLeft,
                                                          child: InkWell(
                                                              onTap: () {
                                                                setState(() {
                                                                  widget.isCallFullScreen =
                                                                      !widget
                                                                          .isCallFullScreen;
                                                                });
                                                              },
                                                              child: Container(
                                                                  color: Colors
                                                                      .white,
                                                                  child: Icon(
                                                                    widget.isCallFullScreen
                                                                        ? Icons
                                                                            .fullscreen_exit
                                                                        : Icons
                                                                            .fullscreen_outlined,
                                                                    color: Colors
                                                                        .black,
                                                                  ))),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(
                                            width: 0,
                                            height: 0,
                                          ),
                                  ),
                                ],
                              )
                            : getBody(),
                  ),
                  widget.callWidgetShow && !widget.showMobileView
                      ? Align(
                          alignment: Alignment.topRight,
                          child: Padding(
                            padding: const EdgeInsets.all(0.0),
                            child: Container(
                              //color: Colors.grey,
                              height: widget.isCallFullScreen
                                  ? (MediaQuery.of(context).size.height)
                                  : (widget.showMobileView ? 70 : 350),
                              width: widget.isCallFullScreen
                                  ? (widget.showMobileView
                                      ? MediaQuery.of(context).size.width
                                      : MediaQuery.of(context).size.width - 350)
                                  : (500),
                              child: Stack(
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: widget.callWidget,
                                  ),
                                  Align(
                                    alignment: Alignment.bottomLeft,
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            widget.isCallFullScreen =
                                                !widget.isCallFullScreen;
                                          });
                                        },
                                        child: Container(
                                            color: Colors.white,
                                            child: Icon(
                                              widget.isCallFullScreen
                                                  ? Icons.fullscreen_exit
                                                  : Icons.fullscreen_outlined,
                                              color: Colors.black,
                                            ))),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      : Container(
                          width: 0,
                          height: 0,
                        ),
                  widget.shouldShowIncomming
                      ? Align(
                          alignment: Alignment.center,
                          child: Center(
                            child: Container(
                              height: widget.showMobileView
                                  ? MediaQuery.of(context).size.height
                                  : MediaQuery.of(context).size.height * 0.4,
                              width: widget.showMobileView
                                  ? MediaQuery.of(context).size.width
                                  : MediaQuery.of(context).size.width * 0.4,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [
                                  Colors.blue,
                                  Colors.lightBlueAccent,
                                  Colors.blueAccent,
                                  Colors.lightBlue,
                                ],
                              )),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Center(
                                      child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      "Incomming Call",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 25),
                                    ),
                                  )),
                                  Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: CircleAvatar(
                                        radius: 40,
                                      ),
                                    ),
                                  ),
                                  Center(
                                      child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                      widget.partnerName,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20),
                                    ),
                                  )),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              String partnerID =
                                                  widget.partnerId;
                                              if (partnerID != null) {
                                                initCallIntent(
                                                    "a",
                                                    widget.auth.currentUser.uid,
                                                    partnerID,
                                                    false,
                                                    widget.firestore,
                                                    context);
                                              }
                                            },
                                            child: Card(
                                              color: Colors.greenAccent,
                                              child: Center(
                                                  child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Text(
                                                  "Answer",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              )),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              widget.firestore
                                                  .collection("callQue")
                                                  .doc(widget
                                                      .auth.currentUser.uid)
                                                  .update({"active": false});
                                              widget.firestore
                                                  .collection("callQue")
                                                  .doc(widget.partnerId)
                                                  .update({"active": false});
                                            },
                                            child: Card(
                                              color: Colors.redAccent,
                                              child: Center(
                                                  child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Text(
                                                  "Decline",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              )),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  // Row(
                                  //   mainAxisAlignment: MainAxisAlignment.center,
                                  //   crossAxisAlignment: CrossAxisAlignment.center,
                                  //   children: [
                                  //     Padding(
                                  //       padding: const EdgeInsets.all(20.0),
                                  //       child: FloatingActionButton(
                                  //         backgroundColor: Colors.greenAccent,
                                  //         onPressed: () {
                                  //           String partnerID = widget.partnerId;
                                  //           if (partnerID != null) {
                                  //             initCallIntent(
                                  //                 "a",
                                  //                 widget.auth.currentUser.uid,
                                  //                 partnerID,
                                  //                 false,
                                  //                 widget.firestore,
                                  //                 context);
                                  //           }
                                  //         },
                                  //         child: Icon(Icons.call, color: Colors.white),
                                  //       ),
                                  //     ),
                                  //     Padding(
                                  //       padding: const EdgeInsets.all(20.0),
                                  //       child: FloatingActionButton(
                                  //         backgroundColor: Colors.redAccent,
                                  //         onPressed: () {
                                  //           widget.firestore
                                  //               .collection("callQue")
                                  //               .doc(widget.auth.currentUser.uid)
                                  //               .update({"active": false});
                                  //           widget.firestore
                                  //               .collection("callQue")
                                  //               .doc(widget.partnerId)
                                  //               .update({"active": false});
                                  //         },
                                  //         child:
                                  //             Icon(Icons.call_end, color: Colors.white),
                                  //       ),
                                  //     )
                                  //   ],
                                  // ),
                                ],
                              ),
                            ),
                          ),
                        )
                      : Container(
                          height: 0,
                          width: 0,
                        ),
                  !kIsWeb && widget.showSplash
                      ? Align(
                          child: Image.asset(
                            "assets/splash_app.jpg",
                            fit: BoxFit.cover,
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                          ),
                        )
                      : Container(
                          height: 0,
                          width: 0,
                        )
                ],
              ),
            ),
          ],
        ),
      ),
    );

    return Scaffold(
      body: Column(
        children: [
          widget.shouldShowIncomming
              ? Container(
                  color: Colors.redAccent,
                  height: 60,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: FloatingActionButton(
                                onPressed: () {
                                  String partnerID = widget.partnerId;
                                  if (partnerID != null) {
                                    initCallIntent(
                                        "a",
                                        widget.auth.currentUser.uid,
                                        partnerID,
                                        false,
                                        widget.firestore,
                                        context);
                                  }
                                },
                                child: Icon(Icons.call, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              : Container(
                  height: 0,
                  width: 0,
                ),
          !widget.showMobileView
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getFndList(),
                    Container(
                      color: Colors.grey,
                      width: 1,
                      height: MediaQuery.of(context).size.height,
                    ),
                    getBody(),
                  ],
                )
              : getFndList(),
        ],
      ),
    );

    return Scaffold(
      body: widget.shouldShowIncomming
          ? Container(
              height: 100,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: FloatingActionButton(
                            onPressed: () {
                              String partnerID = widget.partnerId;
                              if (partnerID != null) {
                                initCallIntent(
                                    "a",
                                    widget.auth.currentUser.uid,
                                    partnerID,
                                    false,
                                    widget.firestore,
                                    context);
                              }
                            },
                            child: Icon(Icons.call, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            )
          : !widget.showMobileView
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getFndList(),
                    Container(
                      color: Colors.grey,
                      width: 1,
                      height: MediaQuery.of(context).size.height,
                    ),
                    getBody(),
                  ],
                )
              : getFndList(),
    );
  }

  Widget getFndList() {
    final button = new PopupMenuButton(
      key: _menuKey,
      itemBuilder: (_) => <PopupMenuItem<String>>[
        new PopupMenuItem<String>(
            child: const Text('Profile'), value: 'profile'),
        new PopupMenuItem<String>(
            child: const Text('Group Meeting'), value: 'grp'),
        //  new PopupMenuItem<String>(child: const Text('Plain Web'), value: 'web'),
        new PopupMenuItem<String>(child: const Text('Logout'), value: 'logout'),
      ],
      onSelected: (String choice) async {
        if (choice == "logout") {
          widget.auth.signOut();
        }
        if (choice == "profile") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ProfileUpdate(
                      auth: widget.auth, firestore: widget.firestore)));
        }
        if (choice == "grp") {
          //GroupCall

          QuerySnapshot q = await widget.firestore
              .collection("users")
              .where("uid", isEqualTo: widget.auth.currentUser.uid)
              .get();

          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) =>  WillPopScope(
          //           onWillPop: () async => false,
          //           child: GroupCall(
          //               room_id: "grp",
          //               containsVideo: true,
          //               ownID: widget.auth.currentUser.uid,
          //               partnerid:"",
          //               isCaller:
          //               true,
          //               firestore:
          //               widget.firestore),
          //
          //         )));
          // }
          // if (choice == "web") {
          //   //GroupCall
          //   Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //           builder: (context) =>  WillPopScope(
          //             onWillPop: () async => false,
          //             child: PlainWebCall(
          //                 containsVideo: true,
          //                 ownID:"p"+widget.sharedPreferences.getString("patient_id"),
          //                 partnerid:"d162",
          //                 isCaller:
          //                 true,
          //                 firestore:
          //                 widget.firestore),
          //
          //           )));
        }
      },
    );
    return Stack(
      children: [
        Align(
          alignment: Alignment.topCenter,
          child: Container(
            height: MediaQuery.of(context).size.height,
            color: Color.fromARGB(255, 239, 247, 255),
            width:
                widget.showMobileView ? MediaQuery.of(context).size.width : 349,
            child: ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 0, 8),
                  child: Container(
                    height: 50,
                    child: Center(
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  widget.showMiniProfile = true;
                                });
                              },
                              child: Center(
                                child: Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0, 0, 10, 0),
                                      child: prePareUserPhoto(
                                          widget.auth.currentUser.uid),

                                      // child: CircleAvatar(radius: 18,backgroundImage: NetworkImage("https://images-na.ssl-images-amazon.com/images/I/71Y2Ov9rHaL._SL1500_.jpg",)),
                                    ),
                                    getNameFromIdR(widget.auth.currentUser.uid,
                                        false, widget.firestore, widget.auth)

                                    //Text(widget.sharedPreferences.get("uphoto")),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: button,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                widget.isSearchModeOn == false
                    ? Column(
                        children: [
                          InkWell(
                            onTap: () {
                              setState(() {
                                widget.isSearchModeOn = true;
                              });
                            },
                            child: Stack(
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 10),
                                    child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          border:
                                              Border.all(color: Colors.grey),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(
                                                  3.0) //                 <--- border radius here
                                              ),
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Row(
                                            children: [
                                              Center(child: Icon(Icons.search)),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        10, 0, 0, 0),
                                                child: Center(
                                                    child: Text("Search")),
                                              ),
                                            ],
                                          ),
                                        )),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Container(
                              height: 50,
                              child: Row(
                                children: [
                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 0;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.chat,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              0
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Chat",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                0
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),
                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 1;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.call_outlined,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              1
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Call",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                1
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),
                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 2;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.contacts,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              2
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Contacts",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                2
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: 1,
                              color: Colors.grey,
                            ),
                          ),
                          widget.selectedTabMenu == 0
                              ? LastChatHistoryWidget(
                                  widgetparent: widget,
                                  callback: doSomething,
                                  firestore: widget.firestore,
                                  firebaseAuth: widget.auth,
                                )
                              : (widget.selectedTabMenu == 1
                                  ? Text("Ignor")
                                  : StreamBuilder<QuerySnapshot>(
                                      stream: widget.firestore
                                          .collection("fnd")
                                          .where("self",
                                              isEqualTo:
                                                  widget.auth.currentUser.uid)
                                          .snapshots(),
                                      builder: (BuildContext context,
                                          AsyncSnapshot<QuerySnapshot>
                                              snapshot) {
                                        if (snapshot.hasData &&
                                            snapshot.data.size > 0 &&
                                            snapshot.data.docs.length > 0) {
                                          return ListView.builder(
                                            shrinkWrap: true,
                                            itemCount:
                                                snapshot.data.docs.length,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              return Container(
                                                child: new InkWell(
                                                  onTap: () async {
                                                    setState(() {
                                                      widget.chatBody = {
                                                        "uid": snapshot.data
                                                            .docs[index]["fnd"]
                                                      };
                                                    });

                                                    if (widget.showMobileView) {
                                                      setState(() {
                                                        widget.mobileViewLevel =
                                                            2;
                                                      });
                                                    }
                                                  },
                                                  child: ListTile(
                                                    tileColor: Color.fromARGB(
                                                        255, 249, 252, 255),
                                                    leading: prePareUserPhoto(
                                                        snapshot.data
                                                                .docs[index]
                                                            ["fnd"]),
                                                    title: getNameFromIdR(
                                                        snapshot.data
                                                            .docs[index]["fnd"],
                                                        false,
                                                        widget.firestore,
                                                        widget.auth),
                                                    subtitle: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              5.0),
                                                      child:
                                                          Text("Send Message"),
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          );

                                          return Center(
                                              child: Text("Total fnd " +
                                                  snapshot.data.docs.length
                                                      .toString()));
                                        } else {
                                          return Center(
                                              child: Text("No Contacts"));
                                        }
                                      })),
                        ],
                      )
                    : Column(
                        children: [
                          Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [
                                  Colors.blueAccent,
                                  Colors.blue,
                                  Colors.lightBlue,
                                  Colors.lightBlue,
                                ],
                              )),
                              child: Container(
                                height: 60,
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: TextFormField(
                                          onChanged: (val) {
                                            setState(() {
                                              widget.searchKey = val;
                                            });
                                          },
                                          controller: searchController,
                                          cursorColor: Colors.white,
                                          style: TextStyle(color: Colors.white),
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintText: "Search People",
                                            hintStyle:
                                                TextStyle(color: Colors.white),
                                            contentPadding: EdgeInsets.all(10),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Container(
                                        width: 40,
                                        height: 40,
                                        child: Center(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: InkWell(
                                              onTap: () {
                                                setState(() {
                                                  searchController.text = "";

                                                  widget.isSearchModeOn = false;
                                                });
                                              },
                                              child: Icon(
                                                Icons.close,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )),

                          StreamBuilder<QuerySnapshot>(
                              stream: widget.firestore
                                  .collection("users")
                                  //.where("uid", isNotEqualTo:  widget.auth.currentUser.uid)
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                if (snapshot.hasData &&
                                    snapshot.data.docs.length > 0) {
                                  List filtereData = [];
                                  if (searchController.text.isNotEmpty &&
                                      searchController.text != "" &&
                                      searchController.text.length > 0) {
                                    for (int i = 0;
                                        i < snapshot.data.docs.length;
                                        i++) {
                                      if (snapshot.data.docs[i].data()["uid"] !=
                                              widget.auth.currentUser.uid &&
                                          snapshot.data.docs[i]
                                              .data()["name"]
                                              .toString()
                                              .toLowerCase()
                                              .startsWith(searchController.text
                                                  .toLowerCase()))
                                        filtereData
                                            .add(snapshot.data.docs[i].data());
                                    }
                                  }
                                  return ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: filtereData.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Container(
                                        child: new InkWell(
                                          onTap: () async {
                                            setState(() {
                                              widget.searchKey = "";
                                              widget.chatBody =
                                                  filtereData[index];
                                              widget.selectedItem = index;
                                            });
                                            if (widget.showMobileView) {
                                              setState(() {
                                                widget.mobileViewLevel = 2;
                                              });
                                            }
                                          },
                                          child: ListTile(
                                            tileColor: Color.fromARGB(
                                                255, 249, 252, 255),
                                            leading: prePareUserPhoto(
                                                filtereData[index]
                                                            ["uid"] !=
                                                        null
                                                    ? filtereData[index]["uid"]
                                                    : (filtereData[index]
                                                                ["sender"] !=
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? filtereData[index]
                                                            ["sender"]
                                                        : filtereData[index]
                                                            ["receiver"])),
                                            title: Text(
                                                filtereData[index]["name"]),
                                            subtitle: Padding(
                                              padding:
                                                  const EdgeInsets.all(5.0),
                                              child: Text("Send Message"),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                } else {
                                  return Text("No Match");
                                }
                              }),
                          //searchController.text
                        ],
                      ),
              ],
            ),
          ),
        ),
        widget.showMiniProfile
            ? Positioned(
                left: 0,
                right: 0,
                top: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    color: Colors.white,
                    elevation: 8,
                    child: Column(
                      children: [
                        ListTile(
                          title: Padding(
                            padding: EdgeInsets.all(0),
                            child: Image.asset(
                              "assets/maulaji_sqr.png",
                              height: 50,
                              fit: BoxFit.cover,
                            ),
                          ),
                          onTap: () {
                            setState(() {
                              widget.showMiniProfile = false;
                            });
                          },
                          trailing: Icon(Icons.close),
                        ),
                        Divider(),
                        Center(
                          child: Row(
                            children: [
                              Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(20, 0, 10, 0),
                                  child: prePareUserPhoto(
                                      widget.auth.currentUser.uid)),

                              // child: CircleAvatar(radius: 18,backgroundImage: NetworkImage("https://images-na.ssl-images-amazon.com/images/I/71Y2Ov9rHaL._SL1500_.jpg",)),

                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  getNameFromIdWithStyle(
                                      widget.auth.currentUser.uid,
                                      TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                      widget.firestore,
                                      widget.auth),
                                  Text(widget.auth.currentUser.email != null &&
                                          widget.auth.currentUser.email.length >
                                              0
                                      ? (widget.auth.currentUser.email)
                                      : (widget.auth.currentUser.phoneNumber)),
                                  Text(
                                    "My Maulaji account",
                                    style: TextStyle(
                                        color: Theme.of(context).primaryColor),
                                  ),
                                ],
                              )

                              //Text(widget.sharedPreferences.get("uphoto")),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 300,
                        ),
                      ],
                    ),
                  ),
                ))
            : Container(
                height: 0,
                width: 0,
              ),
      ],
    );
  }

  Widget getBody() {
    TextEditingController controller = new TextEditingController();
    if (false) {
      return Container(
          height: MediaQuery.of(context).size.height,
          width: widget.showMobileView
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width - 350,
          child: Scaffold(
            body: Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text("Select a user to chat"),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Visibility(
                    visible: widget.callWidgetShow,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 10,
                        child: Container(
                          //color: Colors.grey,
                          height: widget.isCallFullScreen
                              ? MediaQuery.of(context).size.height
                              : (MediaQuery.of(context).size.height * 0.20),
                          width: widget.isCallFullScreen
                              ? MediaQuery.of(context).size.width - 350
                              : (MediaQuery.of(context).size.width * 0.20),
                          child: Stack(
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: widget.callWidget,
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.isCallFullScreen =
                                            !widget.isCallFullScreen;
                                      });
                                    },
                                    child: Icon(
                                      widget.isCallFullScreen
                                          ? Icons.fullscreen_exit
                                          : Icons.fullscreen_outlined,
                                      color: Colors.white,
                                    )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ));
    } else {
      return Padding(
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child: Container(
            color: Colors.white,
            height: !kIsWeb && !widget.callWidgetShow
                ? MediaQuery.of(context).size.height
                : MediaQuery.of(context).size.height,
            width: widget.showMobileView
                ? MediaQuery.of(context).size.width
                : MediaQuery.of(context).size.width - 350,
            child: Stack(
              children: [
                widget.chatBody == null
                    ? Center(
                        child: Image.asset(
                        "assets/background.png",
                        fit: BoxFit.cover,
                      ))
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                widget.chatBody != null
                    ? Positioned(
                        top: 70,
                        child: Container(
                          color: Colors.grey,
                          height: 0.5,
                          width: MediaQuery.of(context).size.width,
                        ))
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                widget.chatBody != null
                    ? Container(
                        height: 70,
                        //  color:   Color.fromARGB(255,238, 246, 255),
                        child: Center(
                            child: Stack(
                          children: [
                            Visibility(
                                visible: widget.showMobileView,
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.mobileViewLevel = 1;
                                      });
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Icon(Icons.chevron_left),
                                    ),
                                  ),
                                )),
                            Positioned(
                                left: widget.showMobileView ? 50 : 0,
                                top: 0,
                                bottom: 0,
                                child: Container(
                                  width: 300,
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(10, 0, 0, 0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        widget.chatBody["name"] != null
                                            ? Text(
                                                widget.chatBody["name"] == null
                                                    ? "No user Name"
                                                    : widget.chatBody["name"],
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black,
                                                    fontSize: 20),
                                              )
                                            : getNameFromId(
                                                widget.chatBody,
                                                true,
                                                widget.firestore,
                                                widget.auth),
                                        widget.chatBody["email"] != null
                                            ? Text(widget.chatBody["email"])
                                            : getEmailFromId(widget.chatBody),
                                      ],
                                    ),
                                  ),
                                )),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Container(
                                  width: 50,
                                  child: InkWell(
                                    onTap: () async {
                                      String partnerID;
                                      if (widget.chatBody["uid"] != null) {
                                        partnerID = widget.chatBody["uid"];
                                        initCallIntent(
                                            "v",
                                            widget.auth.currentUser.uid,
                                            partnerID,
                                            true,
                                            widget.firestore,
                                            context);
                                      } else {
                                        if (widget.chatBody["sender"] ==
                                            widget.auth.currentUser.uid) {
                                          partnerID =
                                              widget.chatBody["receiver"];
                                        } else {
                                          partnerID = widget.chatBody["sender"];
                                        }
                                        initCallIntent(
                                            "v",
                                            widget.auth.currentUser.uid,
                                            partnerID,
                                            true,
                                            widget.firestore,
                                            context);
                                      }
                                    },
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      child: Card(
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(35.0),
                                        ),
                                        color:
                                            Color.fromARGB(255, 241, 241, 241),
                                        child: Icon(Icons.call_outlined),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        )),
                      )
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                widget.chatBody != null
                    ? Positioned(
                        top: 75,
                        left: 0,
                        right: 0,
                        bottom: 70,
                        child: StreamBuilder<QuerySnapshot>(
                            stream: widget.firestore
                                .collection(createRoomName(
                                    widget.auth.currentUser.uid,
                                    widget.chatBody["sender"] != null
                                        ? (widget.chatBody["sender"] ==
                                                widget.auth.currentUser.uid
                                            ? widget.chatBody["receiver"]
                                            : widget.chatBody["sender"])
                                        : widget.chatBody["uid"]))
                                .orderBy("time")
                                .snapshots(),
                            builder: (BuildContext c,
                                AsyncSnapshot<QuerySnapshot> snapshot) {
                              if (snapshot.hasData && snapshot.data.size > 0) {
                                return Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  child: ListView.builder(
                                      // controller: scrollController,
                                      shrinkWrap: true,
                                      itemCount: snapshot.data == null
                                          ? 0
                                          : snapshot.data.size,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Stack(
                                            children: [
                                              Align(
                                                alignment: snapshot
                                                            .data.docs[index]
                                                            .data()["sender"] ==
                                                        widget.auth.currentUser
                                                            .uid
                                                    ? Alignment.centerRight
                                                    : Alignment.centerLeft,
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(0.0),
                                                  child:
                                                      snapshot.data.docs[index]
                                                                      .data()[
                                                                  "sender"] ==
                                                              widget
                                                                  .auth
                                                                  .currentUser
                                                                  .uid
                                                          ? Column(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment: snapshot
                                                                              .data
                                                                              .docs[
                                                                                  index]
                                                                              .data()[
                                                                          "sender"] ==
                                                                      widget
                                                                          .auth
                                                                          .currentUser
                                                                          .uid
                                                                  ? CrossAxisAlignment
                                                                      .end
                                                                  : CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Padding(
                                                                  padding:
                                                                      const EdgeInsets
                                                                              .fromLTRB(
                                                                          0,
                                                                          0,
                                                                          5,
                                                                          0),
                                                                  child: Text(
                                                                    DateFormat('hh:mm aa').format(DateTime.fromMillisecondsSinceEpoch(snapshot
                                                                        .data
                                                                        .docs[
                                                                            index]
                                                                        .data()["time"])),
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            12),
                                                                  ),
                                                                ),
                                                                Card(
                                                                  color: snapshot.data.docs[index].data()[
                                                                              "sender"] ==
                                                                          widget
                                                                              .auth
                                                                              .currentUser
                                                                              .uid
                                                                      ? Colors
                                                                          .white
                                                                      : Color.fromARGB(
                                                                          255,
                                                                          238,
                                                                          246,
                                                                          255),
                                                                  child:
                                                                      Container(
                                                                          child:
                                                                              Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            8.0),
                                                                    child: Text(snapshot
                                                                        .data
                                                                        .docs[
                                                                            index]
                                                                        .data()["message"]),
                                                                  )),
                                                                ),
                                                              ],
                                                            )
                                                          : Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                widget.chatBody[
                                                                            "img"] ==
                                                                        null
                                                                    ? CircleAvatar(
                                                                        radius:
                                                                            10,
                                                                      )
                                                                    : CircleAvatar(
                                                                        radius:
                                                                            10,
                                                                        backgroundImage:
                                                                            NetworkImage(widget.chatBody["img"]),
                                                                      ),
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .center,
                                                                  crossAxisAlignment: snapshot.data.docs[index].data()[
                                                                              "sender"] ==
                                                                          widget
                                                                              .auth
                                                                              .currentUser
                                                                              .uid
                                                                      ? CrossAxisAlignment
                                                                          .end
                                                                      : CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              5,
                                                                              0,
                                                                              0,
                                                                              0),
                                                                      child:
                                                                          Text(
                                                                        DateFormat('hh:mm aa').format(DateTime.fromMillisecondsSinceEpoch(snapshot
                                                                            .data
                                                                            .docs[index]
                                                                            .data()["time"])),
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                12),
                                                                      ),
                                                                    ),
                                                                    Card(
                                                                      color: snapshot.data.docs[index].data()["sender"] ==
                                                                              widget
                                                                                  .auth.currentUser.uid
                                                                          ? Colors
                                                                              .white
                                                                          : Color.fromARGB(
                                                                              255,
                                                                              238,
                                                                              246,
                                                                              255),
                                                                      child: Container(
                                                                          child: Padding(
                                                                        padding:
                                                                            const EdgeInsets.all(8.0),
                                                                        child: Text(snapshot
                                                                            .data
                                                                            .docs[index]
                                                                            .data()["message"]),
                                                                      )),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                ),
                                              )
                                            ],
                                          ),
                                        );
                                      }),
                                );
                              } else {
                                return Center(
                                  child: Text("Send your first message"),
                                );
                              }
                            }))
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                widget.chatBody != null
                    ? Align(
                        alignment: Alignment.bottomCenter,
                        child: Stack(
                          children: [
                            Positioned(
                              bottom: 10,
                              left: 10,
                              right: 100,
                              child: Container(
                                height: 60,
                                child: Center(
                                  child: Card(
                                    elevation: 0,
                                    color: Color.fromARGB(255, 238, 246, 255),
                                    child: Container(
                                      child: new TextField(
                                        onSubmitted: (val) async {
                                          String room = createRoomName(
                                              widget.auth.currentUser.uid,
                                              widget.chatBody["sender"] != null
                                                  ? (widget.chatBody[
                                                              "sender"] ==
                                                          widget.auth
                                                              .currentUser.uid
                                                      ? widget
                                                          .chatBody["receiver"]
                                                      : widget
                                                          .chatBody["sender"])
                                                  : widget.chatBody["uid"]);

                                          await widget.firestore
                                              .collection("last")
                                              .doc(room)
                                              .set({
                                            "message": val,
                                            "sender":
                                                widget.auth.currentUser.uid,
                                            "receiver": widget
                                                        .chatBody["sender"] !=
                                                    null
                                                ? (widget.chatBody["sender"] ==
                                                        widget.auth.currentUser
                                                            .uid
                                                    ? widget
                                                        .chatBody["receiver"]
                                                    : widget.chatBody["sender"])
                                                : widget.chatBody["uid"]
                                          });

                                          await widget.firestore
                                              .collection(room)
                                              .add({
                                            "time": DateTime.now()
                                                .millisecondsSinceEpoch,
                                            "message": val,
                                            "sender":
                                                widget.auth.currentUser.uid,
                                            "receiver": widget
                                                        .chatBody["sender"] !=
                                                    null
                                                ? (widget.chatBody["sender"] ==
                                                        widget.auth.currentUser
                                                            .uid
                                                    ? widget
                                                        .chatBody["receiver"]
                                                    : widget.chatBody["sender"])
                                                : widget.chatBody["uid"]
                                          });
                                          controller.clear();
                                        },
                                        controller: controller,
                                        textAlign: TextAlign.left,
                                        decoration: new InputDecoration(
                                          hintText: "Type your message",
                                          contentPadding: EdgeInsets.all(10),
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              right: 10,
                              child: Container(
                                height: 60,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Center(
                                      child: new InkWell(
                                        onTap: () async {
                                          //widget.room
                                          showBottomSheet(
                                              context: context,
                                              builder: (context) => Container(
                                                    height: 300,
                                                  ));
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Icon(
                                            Icons.emoji_emotions,
                                            color:
                                                Theme.of(context).primaryColor,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Center(
                                      child: new InkWell(
                                        onTap: () async {
                                          //widget.room
                                          String text = controller.text;
                                          if (text.length > 0) {
                                            String room = createRoomName(
                                                widget.auth.currentUser.uid,
                                                widget.chatBody["sender"] !=
                                                        null
                                                    ? (widget.chatBody[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? widget.chatBody[
                                                            "receiver"]
                                                        : widget
                                                            .chatBody["sender"])
                                                    : widget.chatBody["uid"]);

                                            await widget.firestore
                                                .collection("last")
                                                .doc(room)
                                                .set({
                                              "message": text,
                                              "sender":
                                                  widget.auth.currentUser.uid,
                                              "receiver": widget
                                                          .chatBody["sender"] !=
                                                      null
                                                  ? (widget.chatBody[
                                                              "sender"] ==
                                                          widget.auth
                                                              .currentUser.uid
                                                      ? widget
                                                          .chatBody["receiver"]
                                                      : widget
                                                          .chatBody["sender"])
                                                  : widget.chatBody["uid"]
                                            });

                                            await widget.firestore
                                                .collection(room)
                                                .add({
                                              "time": DateTime.now()
                                                  .millisecondsSinceEpoch,
                                              "message": text,
                                              "sender":
                                                  widget.auth.currentUser.uid,
                                              "receiver": widget
                                                          .chatBody["sender"] !=
                                                      null
                                                  ? (widget.chatBody[
                                                              "sender"] ==
                                                          widget.auth
                                                              .currentUser.uid
                                                      ? widget
                                                          .chatBody["receiver"]
                                                      : widget
                                                          .chatBody["sender"])
                                                  : widget.chatBody["uid"]
                                            });
                                            controller.clear();
                                          }
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Icon(
                                            Icons.send,
                                            color: Colors.blue,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                widget.showProfileCompleteDialog
                    ? Align(
                        alignment: Alignment.center,
                        child: Card(
                          color: Color.fromARGB(255, 239, 247, 255),
                          elevation: 20,
                          child: Container(
                              width: 400,
                              height: 400,
                              child: ProfileUpdateDialog(
                                auth: widget.auth,
                                firestore: widget.firestore,
                                currentProfile: widget.currentProfile,
                              )),
                        ),
                      )
                    : Container(
                        width: 0,
                        height: 0,
                      ),
                showAddFndDialog(),
              ],
            )),
      );
    }
  }

  String createRoomName(String uid, partner) {
    final List<String> ids = <String>[uid, partner];
    ids.sort();
    return ids.first + "-" + ids.last;
  }

  // Future<void> _handleCameraAndMic() async {
  //   await PermissionHandler().requestPermissions(
  //     [PermissionGroup.camera, PermissionGroup.microphone],
  //   );
  // }
  void initCallIntent(String callTYpe, String ownid, String partner,
      bool isCaller, FirebaseFirestore firestore, BuildContext context) async {
    print("found");
    if (!kIsWeb) {
      // await _handleCameraAndMic();
    }

    QuerySnapshot callerNameQ = await firestore
        .collection("users")
        .where("uid", isEqualTo: isCaller ? ownid : partner)
        .get();
    String callerName = callerNameQ.docs.first.data()["name"];

    QuerySnapshot targetNameQ = await firestore
        .collection("users")
        .where("uid", isEqualTo: isCaller ? partner : ownid)
        .get();
    String targetName = targetNameQ.docs.first.data()["name"];
    await firestore.collection("callQue").doc(ownid).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid,
      "callerName": callerName,
      "targetName": targetName
    });
    await firestore.collection("callQue").doc(partner).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid,
      "callerName": callerName,
      "targetName": targetName
    });
    await firestore.collection("refresh").doc(ownid).delete();
    await firestore.collection("refresh").doc(partner).delete();
    firestore
        .collection("callQue")
        .doc(ownid)
        .snapshots()
        .listen((valueCaller) {
      if (valueCaller.exists &&
          valueCaller.data() != null &&
          valueCaller.data()["active"] == null) {
      } else {
        setState(() {
          widget.callWidgetShow = false;
          widget.userStatus = "incall";
        });
      }
    });
    List ids = [];
    ids.add(ownid);
    ids.add(partner);
    ids.sort();

    doSomething() {
      setState(() {
        widget.callWidgetShow = false;
        widget.userStatus = "free";
        widget.CallDuration = 0;
      });
    }

    callUserIsNoAvailable() {
      setState(() {
        widget.callWidgetShow = false;
      });
    }
    // firestore.collection("callHistory").add({
    //   "caller": isCaller ? ownid : partner,
    //   "target": isCaller ? partner : ownid,
    //   "time":DateTime.now().millisecondsSinceEpoch
    // }).then((value) {
    //
    // });

    callStartedNotify() {
      // setState(() {
      //   widget.CallDuration = widget.CallDuration + 1 ;
      // });
      if (false) {
        setState(() {
          widget.CallDuration = widget.CallDuration + 1;
        });

        Timer.periodic(Duration(milliseconds: 1000), (timer) {
          if (mounted) {
            setState(() {
              widget.CallDuration = widget.CallDuration + 1;
            });
          } else {
            timer.cancel();
          }
        });
      }
    }

    setState(() {
      widget.callWidget = WillPopScope(
        onWillPop: () async => false,
        child: SimpleWebCall(
          containsVideo: false,
          ownID: ownid,
          partnerid: partner,
          isCaller: isCaller,
          firestore: firestore,
          partnerPair: ids.first + "-" + ids.last,
          callback: doSomething,
          callStartedNotify: callStartedNotify,
          callUserIsNoAvailable: callUserIsNoAvailable,
        ),
      );
      widget.callWidgetShow = true;
    });
    if (widget.showMobileView) {}
/*
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => WillPopScope(
                  onWillPop: () async => false,
                  child: SimpleWebCall(
                    containsVideo: callTYpe == false,
                    ownID: ownid,
                    partnerid: partner,
                    isCaller: isCaller,
                    firestore: firestore,
                    partnerPair: ids.first + "-" + ids.last,
                  ),
                )));

 */
  }

  void initCallIntentMobile(String callTYpe, String ownid, String partner,
      bool isCaller, FirebaseFirestore firestore, BuildContext context) async {
    print("found");
    if (!kIsWeb) {
      // await _handleCameraAndMic();
    }

    await firestore.collection("callQue").doc(ownid).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("callQue").doc(partner).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("refresh").doc(ownid).delete();
    await firestore.collection("refresh").doc(partner).delete();
    firestore
        .collection("callQue")
        .doc(ownid)
        .snapshots()
        .listen((valueCaller) {
      if (valueCaller.exists &&
          valueCaller.data() != null &&
          valueCaller.data()["active"] == null) {
      } else {
        setState(() {
          widget.callWidgetShow = false;
        });
      }
    });
    List ids = [];
    ids.add(ownid);
    ids.add(partner);
    ids.sort();

    doSomething() {
      setState(() {
        widget.callWidgetShow = false;
      });
    }

    setState(() {
      widget.callWidget = WillPopScope(
        onWillPop: () async => false,
        child: SimpleWebCall(
          containsVideo: false,
          ownID: ownid,
          partnerid: partner,
          isCaller: isCaller,
          firestore: firestore,
          partnerPair: ids.first + "-" + ids.last,
          callback: doSomething,
        ),
      );
      widget.callWidgetShow = true;
    });
/*
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => WillPopScope(
                  onWillPop: () async => false,
                  child: SimpleWebCall(
                    containsVideo: callTYpe == false,
                    ownID: ownid,
                    partnerid: partner,
                    isCaller: isCaller,
                    firestore: firestore,
                    partnerPair: ids.first + "-" + ids.last,
                  ),
                )));

 */
  }

  Widget getEmailFromId(body) {
    return FutureBuilder<QuerySnapshot>(
        future: widget.firestore
            .collection("users")
            .where("uid",
                isEqualTo: body["uid"] != null
                    ? body["uid"]
                    : (body["receiver"] == widget.auth.currentUser.uid
                        ? body["sender"]
                        : body["receiver"]))
            .get(),
        builder: (context, snapuserInfo) {
          if (snapuserInfo.hasData) {
            return Text(
              snapuserInfo.data.docs.first.data()["email"],
              style: TextStyle(),
            );
          } else {
            return Text("No Email address found");
          }
        });
  }

  Widget createLastChatList() {
    //return Text("Please wait") ;
    List oneS = [];
    List oneR = [];
    List Sum = [];

    Widget returnWidget = Text("Please wait");

    widget.firestore
        .collection("last")
        .where("sender", isEqualTo: widget.auth.currentUser.uid)
        .snapshots()
        .listen((event) {
      if (event.size > 0 && event.docs.length > 0) {
        oneS = event.docs;
        Sum.clear();
        Sum.addAll(oneS);
        Sum.addAll(oneR);

        returnWidget = Text(Sum.length.toString());

        return returnWidget;
      } else {
        return returnWidget;
      }
    });
    widget.firestore
        .collection("last")
        .where("receiver", isEqualTo: widget.auth.currentUser.uid)
        .snapshots()
        .listen((event) {
      if (event.size > 0 && event.docs.length > 0) {
        oneR = event.docs;
        Sum.clear();
        Sum.addAll(oneS);
        Sum.addAll(oneR);

        returnWidget = Text(Sum.length.toString());
        return returnWidget;
      } else {
        return returnWidget;
      }
    });

    return returnWidget;

    /*

    StreamBuilder<QuerySnapshot>(
        stream: widget.firestore
            .collection("last")
            .where("sender", isEqualTo: widget.auth.currentUser.uid)
            .snapshots(),
        builder: (context, projectSnapSender) {
          List allHistory = [];
          if (projectSnapSender.hasData) {
            if (true || projectSnapSender.data.docs.length > 0)
              allHistory.addAll(projectSnapSender.data.docs);
            return StreamBuilder<QuerySnapshot>(
                stream: widget.firestore
                    .collection("last")
                    .where("receiver", isEqualTo: widget.auth.currentUser.uid)
                    .snapshots(),
                builder: (context, projectSnapReceiver) {
                  if (projectSnapReceiver.hasData) {
                    if (true|| projectSnapReceiver.data.docs.length > 0)
                      allHistory.addAll(projectSnapSender.data.docs);
                  } else {
                    return Text("Please wait");
                  }
                  List filteredData = [];
                  for (int i = 0; i < allHistory.length; i++) {
                    if ( allHistory[i].data()["sender"] != widget.auth.currentUser.uid) {
                      filteredData.add(allHistory[i]);
                    }
                    if ( allHistory[i].data()["receiver"] !=
                        widget.auth.currentUser.uid) {
                      filteredData.add(allHistory[i]);
                    }
                  }
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: (filteredData == null)
                        ? 0
                        : filteredData.length,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return Container(
                        child: new InkWell(
                          onTap: () async {
                            setState(() {
                              widget.chatBody =
                                  filteredData[index]
                                      .data();
                              widget.selectedItem = index;
                            });
                          },
                          child: ListTile(
                            tileColor:
                            widget.selectedItem == index
                                ? Color.fromARGB(
                                255, 206, 231, 255)
                                : Color.fromARGB(
                                255, 249, 252, 255),
                            leading: CircleAvatar(
                                radius: 18,
                                backgroundImage: NetworkImage(
                                    "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                            // title: Text(filteredData[index].data()["receiver"]),
                            title: getNameFromId(filteredData[index].data(),false),
                            subtitle: Padding(
                              padding:
                              const EdgeInsets.all(5.0),
                              child: Text("Sub title"),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                });
          } else {
            return Text("No Chat history");
            return StreamBuilder<QuerySnapshot>(
                stream: widget.firestore
                    .collection("last")
                    .where("receiver",
                    isEqualTo:
                    widget.auth.currentUser.uid)
                    .snapshots(),
                builder: (context, projectSnapReceiver) {
                  if (projectSnapReceiver.hasData) {
                    if (projectSnapReceiver
                        .data.docs.length >
                        0)
                      allHistory.addAll(
                          projectSnapSender.data.docs);
                  } else {
                    return Text("Please wait");
                  }
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: (allHistory == null)
                        ? 0
                        : allHistory.length,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return Container(
                        child: new InkWell(
                          onTap: () async {
                            setState(() {
                              widget.chatBody =
                                  allHistory[index].data();
                              widget.selectedItem = index;
                            });
                          },
                          child: ListTile(
                            tileColor:
                            widget.selectedItem == index
                                ? Color.fromARGB(
                                255, 206, 231, 255)
                                : Color.fromARGB(
                                255, 249, 252, 255),
                            leading: CircleAvatar(
                                radius: 18,
                                backgroundImage: NetworkImage(
                                    "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                            title: Text(allHistory[index]
                                .data()["receiver"]),
                            subtitle: Padding(
                              padding:
                              const EdgeInsets.all(5.0),
                              child: Text("Sub title"),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                });
            ;
          }
        })

     */
  }

  prePareUserPhoto(String uid) {
    return StreamBuilder<DocumentSnapshot>(
        // Initialize FlutterFire:
        //  future: Firebase.initializeApp(),
        stream: widget.firestore.collection("user_status").doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData &&
              snapshot.data.exists &&
              snapshot.data.data() != null) {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                        radius: 20,
                        backgroundImage: widget.auth.currentUser.photoURL !=
                                null
                            ? NetworkImage(
                                widget.auth.currentUser.photoURL,
                              )
                            : NetworkImage(
                                "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: snapshot.data.data()["status"] == "free" &&
                                    snapshot.data.data()["time"] + 3000 >
                                        DateTime.now().millisecondsSinceEpoch
                                ? Colors.greenAccent
                                : (snapshot.data.data()["status"] == "incall" &&
                                        snapshot.data.data()["time"] + 3000 >
                                            DateTime.now()
                                                .millisecondsSinceEpoch
                                    ? Colors.redAccent
                                    : Colors.grey)),
                      ),
                    ),
                  )
                ],
              ),
            );
          } else {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                        radius: 20,
                        backgroundImage: widget.auth.currentUser.photoURL !=
                                null
                            ? NetworkImage(
                                widget.auth.currentUser.photoURL,
                              )
                            : NetworkImage(
                                "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.grey),
                      ),
                    ),
                  )
                ],
              ),
            );
          }
        });
  }

  String getCallTime() {
    // return " 00:" + widget.CallDuration.toString();
  }

  Widget showAddFndDialog() {
    if (widget.chatBody == null) {
      return Container(
        height: 0,
        width: 0,
      );
    } else {
      String fndID = widget.chatBody["sender"] != null
          ? (widget.chatBody["sender"] == widget.auth.currentUser.uid
              ? widget.chatBody["receiver"]
              : widget.chatBody["sender"])
          : widget.chatBody["uid"];

      return StreamBuilder<QuerySnapshot>(
          stream: widget.firestore
              .collection("fnd")
              .where("self", isEqualTo: widget.auth.currentUser.uid)
              .where("fnd", isEqualTo: fndID)
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData &&
                snapshot.data.size > 0 &&
                snapshot.data.size > 0) {
              return Container(
                width: 0,
                height: 0,
              );
            } else {
              return Positioned(
                  top: 75,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Wrap(
                      children: [
                        InkWell(
                          onTap: () {
                            widget.firestore.collection("fnd").add({
                              "self": widget.auth.currentUser.uid,
                              "fnd": fndID,
                              "active": true
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                color: Theme.of(context).primaryColor,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(10, 5, 10, 5),
                                  child: Text(
                                    "Add to Contact",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            widget.firestore.collection("fnd").add({
                              "self": widget.auth.currentUser.uid,
                              "fnd": fndID,
                              "active": false
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                color: Colors.white,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(10, 5, 10, 5),
                                  child: Text(
                                    "Don't add to Contact",
                                    style: TextStyle(
                                        color: Colors.redAccent,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                        )
                      ],
                    ),
                  ));
            }
          });
    }

    // return  widget.chatBody != null
    //       ? Positioned(
    //       top: 75,
    //       left: 0,
    //       right: 0,
    //       child: Center(
    //         child: Wrap(
    //           children: [
    //             InkWell(onTap: (){
    //
    //
    //               widget.firestore.collection("fnd").add({"self":widget.auth.currentUser.uid,"fnd":fndID,"active":true});
    //
    //             },
    //               child: Padding(
    //                 padding: const EdgeInsets.all(8.0),
    //                 child: Card(
    //                     color: Theme.of(context).primaryColor,
    //                     child: Padding(
    //                       padding:
    //                       const EdgeInsets.fromLTRB(10, 5, 10, 5),
    //                       child: Text(
    //                         "Add to Contact",
    //                         style: TextStyle(
    //                             color: Colors.white,
    //                             fontWeight: FontWeight.bold),
    //                       ),
    //                     )),
    //               ),
    //             ),
    //             InkWell(onTap: (){
    //
    //
    //               widget.firestore.collection("fnd").add({"self":widget.auth.currentUser.uid,"fnd":fndID,"active":false});
    //
    //             },
    //               child: Padding(
    //                 padding: const EdgeInsets.all(8.0),
    //                 child: Card(
    //                     color: Colors.white,
    //                     child: Padding(
    //                       padding:
    //                       const EdgeInsets.fromLTRB(10, 5, 10, 5),
    //                       child: Text(
    //                         "Don't add to Contact",
    //                         style: TextStyle(
    //                             color: Colors.redAccent,
    //                             fontWeight: FontWeight.bold),
    //                       ),
    //                     )),
    //               ),
    //             )
    //           ],
    //         ),
    //       ))
    //       : Container(
    //     width: 0,
    //     height: 0,
    //   );
  }

  getString() {}

  void initSignaling() async {
    socket2 = IO.io('http://localhost:3000');
    socket2.onConnect((_) {
      print('connect');
      socket2.emit('msg', 'test');
    });
    socket2.on('event', (data) => print(data));
    socket2.onDisconnect((_) => print('disconnect'));
    socket2.on('fromServer', (_) => print(_));

    Timer.periodic(Duration(milliseconds: 2000), (timer) {
      if (mounted) {
        socket2.emit('setOnline', {"userId": widget.auth.currentUser.uid});
      }
    });


    socket2.on("online", (data)  {
      print("online users");
     // print(data.toString());
      onlineUser[data] = data;
      //print(onlineUser);
    });

    Timer.periodic(Duration(milliseconds: 5000), (timer) {
      if (mounted) {
        onlineUser.clear()
      }else{
        timer.cancel();
      }
    });

    // socket2.on('getOnline', (data) {
    //   List all = [];
    //  // all = jsonDecode(data.toString());
    //  // print(data);
    //   all.clear();
    //   jsonDecode(data.toString()).asMap().forEach((i, value) {
    //     print('index=$i, value=$value');
    //     all.add(value);
    //   });
    //   print(all.length.toString());
    // });
  }
}

class LastChatHistoryWidget extends StatefulWidget {
  String selectedItemId;

  void Function(dynamic) callback;

  FirebaseFirestore firestore;
  FirebaseAuth firebaseAuth;

  List oneS = [];
  List oneR = [];
  List Sum = [];
  Home widgetparent;
  IO.Socket socket;

  // Widget returnWidget = Scaffold(body: Center(child: Text("Please wait"),),);
  Widget returnWidget = Padding(
    padding: EdgeInsets.all(50),
    child: CircularProgressIndicator(),
  );

  LastChatHistoryWidget(
      {this.widgetparent,
      this.firestore,
      this.firebaseAuth,
      this.callback,
      this.socket});

  @override
  _LastChatHistoryWidgetState createState() => _LastChatHistoryWidgetState();
}

class _LastChatHistoryWidgetState extends State<LastChatHistoryWidget> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer.periodic(Duration(milliseconds: 1000), (timer) {
      if (mounted) {
        widget.firestore
            .collection("last")
            .where("sender", isEqualTo: widget.firebaseAuth.currentUser.uid)
            .get()
            .then((value) {
          setState(() {
            widget.oneS = value.docs;
            /* widget.Sum.clear();
                widget.Sum .addAll(widget.oneS);
                widget.Sum .addAll(widget.oneR);

                */
          });

          widget.firestore
              .collection("last")
              .where("receiver", isEqualTo: widget.firebaseAuth.currentUser.uid)
              .get()
              .then((value) {
            setState(() {
              widget.oneR = value.docs;
              widget.Sum.clear();
              widget.Sum.addAll(widget.oneS);
              widget.Sum.addAll(widget.oneR);
            });
            setState(() {
              widget.returnWidget = ListView.builder(
                  shrinkWrap: true,
                  itemCount: (widget.Sum == null || widget.Sum == null)
                      ? 0
                      : widget.Sum.length,
                  itemBuilder: (BuildContext context, int index) {
                    return ListTile(
                      tileColor: widget.selectedItemId != null &&
                              ((widget.selectedItemId ==
                                      widget.Sum[index].data()["receiver"]) |
                                  (widget.selectedItemId ==
                                      widget.Sum[index].data()["sender"]))
                          ? Color.fromARGB(255, 217, 236, 255)
                          : Color.fromARGB(255, 239, 247, 255),
                      onTap: () {
                        widget.callback(widget.Sum[index].data());
                        setState(() {
                          // widget.chatBody = filtereData[index];
                          widget.selectedItemId =
                              widget.Sum[index].data()["receiver"] ==
                                      widget.firebaseAuth.currentUser.uid
                                  ? widget.Sum[index].data()["sender"]
                                  : widget.Sum[index].data()["receiver"];
                        });

                        setState(() {
                          //  widget.widgetparent.chatBody =  widget.Sum[index];
                          widget.widgetparent.selectedItem = index;
                        });
                        if (widget.widgetparent.showMobileView) {
                          setState(() {
                            widget.widgetparent.mobileViewLevel = 2;
                          });
                        }
                      },
                      leading: prePareUserPhoto(
                          widget.socket,
                          widget.firebaseAuth,
                          widget.Sum[index].data()["receiver"] ==
                                  widget.firebaseAuth.currentUser.uid
                              ? widget.Sum[index].data()["sender"]
                              : widget.Sum[index].data()["receiver"]),
                      title: getNameFromIdR(
                          widget.Sum[index].data()["receiver"] ==
                                  widget.firebaseAuth.currentUser.uid
                              ? widget.Sum[index].data()["sender"]
                              : widget.Sum[index].data()["receiver"],
                          false,
                          widget.firestore,
                          widget.firebaseAuth),
                      subtitle: Text(widget.Sum[index].data()["message"]),
                    );
                  });
            });
          });
        });
      }
    });

/*

    widget.firestore
        .collection("last")
        .where("sender", isEqualTo: widget.firebaseAuth.currentUser.uid)
        .snapshots().listen((event) {
      if(event.size>0 && event.docs.length>0){


        widget.oneS = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);



        setState(() {


        widget.oneS = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);

        widget.returnWidget = ListView.builder(
            shrinkWrap: true,
            itemCount:
            (widget.Sum == null || widget.Sum == null)
                ? 0
                : widget.Sum.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(tileColor:  widget.selectedItemId!=null && ((widget.selectedItemId ==  widget.Sum[index].data()["receiver"]) |( widget.selectedItemId ==  widget.Sum[index].data()["sender"]))?Color.fromARGB(255, 217, 236, 255 ):Colors.white,onTap: (){
                setState(() {
                 // widget.chatBody = filtereData[index];
                  widget.selectedItemId =  widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"];
                });
              },leading: CircleAvatar(radius: 18,),title:getNameFromIdR( widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"] ,false,widget.firestore,widget.firebaseAuth) ,subtitle: Text(widget.Sum[index].data()["message"]),);

            });
        });

      }

    });
    widget.firestore
        .collection("last")
        .where("receiver", isEqualTo: widget.firebaseAuth.currentUser.uid)
        .snapshots().listen((event) {
      if(event.size>0 && event.docs.length>0){

        setState(() {


        widget.oneR = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);

        widget.returnWidget =  ListView.builder(
            shrinkWrap: true,
            itemCount:
            (widget.Sum == null || widget.Sum == null)
                ? 0
                : widget.Sum.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(tileColor: widget.selectedItemId!=null && ((widget.selectedItemId ==  widget.Sum[index].data()["receiver"]) |( widget.selectedItemId ==  widget.Sum[index].data()["sender"]))?Color.fromARGB(255, 217, 236, 255 ):Colors.white,onTap: (){
                setState(() {
                 // widget.chatBody = filtereData[index];
                  widget.selectedItemId =  widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"];
                });
              },leading: CircleAvatar(radius: 18,),title:getNameFromIdR( widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"] ,false,widget.firestore,widget.firebaseAuth) ,subtitle: Text(widget.Sum[index].data()["message"]),);

            });
        });
      }

    });
    */
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: widget.returnWidget,
    );
  }

  prePareUserPhoto(IO.Socket socket, FirebaseAuth auth, String uid) {

    onlineUser.containsKey(uid)








    return StreamBuilder<DocumentSnapshot>(
        // Initialize FlutterFire:
        //  future: Firebase.initializeApp(),
        stream: widget.firestore.collection("user_status").doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData &&
              snapshot.data.exists &&
              snapshot.data.data() != null) {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                        radius: 20,
                        backgroundImage: auth.currentUser.photoURL != null
                            ? NetworkImage(
                                auth.currentUser.photoURL,
                              )
                            : NetworkImage(
                                "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: snapshot.data.data()["status"] == "free" &&
                                    snapshot.data.data()["time"] + 3000 >
                                        DateTime.now().millisecondsSinceEpoch
                                ? Colors.greenAccent
                                : Colors.redAccent),
                      ),
                    ),
                  )
                ],
              ),
            );
          } else {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                        radius: 20,
                        backgroundImage: auth.currentUser.photoURL != null
                            ? NetworkImage(
                                auth.currentUser.photoURL,
                              )
                            : NetworkImage(
                                "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.redAccent),
                      ),
                    ),
                  )
                ],
              ),
            );
          }
        });
  }
}

Widget getNameFromIdWithStyle(String id, TextStyle style,
    FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore.collection("users").where("uid", isEqualTo: id).get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style,
          );
        } else {
          return Text("Please wait");
        }
      });
}

Widget getNameFromIdR(
    String id, bool style, FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore.collection("users").where("uid", isEqualTo: id).get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style
                ? TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20)
                : TextStyle(),
          );
        } else {
          return Text("Please wait");
        }
      });
}

class ProfileUpdateDialog extends StatefulWidget {
  dynamic currentProfile;

  FirebaseFirestore firestore;

  FirebaseAuth auth;

  ProfileUpdateDialog({this.currentProfile, this.auth, this.firestore});

  @override
  _ProfileUpdateDialogState createState() => _ProfileUpdateDialogState();
}

class _ProfileUpdateDialogState extends State<ProfileUpdateDialog> {
  TextEditingController textEditingControllerName = TextEditingController();
  TextEditingController textEditingControllerEmail = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    textEditingControllerName.text = widget.currentProfile["name"];
    textEditingControllerEmail.text = widget.currentProfile["email"];
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 400,
        height: 400,
        child: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                color: Colors.blue,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Profile Update",
                    style: TextStyle(
                        backgroundColor: Colors.blue,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 20, 8, 0),
                child: Text(
                  "Display Name",
                  style: TextStyle(
                      color: Colors.blue, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                child: TextField(
                  controller: textEditingControllerName,
                  decoration:
                      InputDecoration(contentPadding: EdgeInsets.all(10)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 20, 8, 0),
                child: Text(
                  "Email",
                  style: TextStyle(
                      color: Colors.blue, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                child: TextField(
                  controller: textEditingControllerEmail,
                  decoration:
                      InputDecoration(contentPadding: EdgeInsets.all(10)),
                ),
              ),
              InkWell(
                onTap: () {
                  widget.firestore
                      .collection("users")
                      .where("uid", isEqualTo: widget.auth.currentUser.uid)
                      .get()
                      .then((value) {
                    widget.firestore
                        .collection("users")
                        .doc(value.docs.first.id)
                        .update({
                      "email": textEditingControllerEmail.text,
                      "name": textEditingControllerName.text
                    });
                  });
                },
                child: Card(
                  elevation: 0,
                  color: Theme.of(context).primaryColor,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                          child: Text(
                        "Save",
                        style: TextStyle(color: Colors.white),
                      )),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

Widget getNameFromId(
    dynamic body, bool style, FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore
          .collection("users")
          .where("uid",
              isEqualTo: body["uid"] != null
                  ? body["uid"]
                  : (body["receiver"] == auth.currentUser.uid
                      ? body["sender"]
                      : body["receiver"]))
          .get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style
                ? TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20)
                : TextStyle(),
          );
        } else {
          return Text("Please wait");
        }
      });
}

class CreateRoomActivity extends StatefulWidget {
  FirebaseFirestore firestore;

  FirebaseAuth auth;

  CreateRoomActivity({this.firestore, this.auth});

  @override
  _CreateRoomActivityState createState() => _CreateRoomActivityState();
}

class _CreateRoomActivityState extends State<CreateRoomActivity> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: InkWell(
                onTap: () async {
                  QuerySnapshot q = await widget.firestore
                      .collection("users")
                      .where("uid", isEqualTo: widget.auth.currentUser.uid)
                      .get();

                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => WillPopScope(
                  //           onWillPop: () async => false,
                  //           child: Conf(
                  //             containsVideo:  false,
                  //             ownID: widget.auth.currentUser.uid,
                  //             isCaller: true,
                  //             firestore: widget.firestore,
                  //
                  //           ),
                  //         )));
                  // widget.firestore.collection("con").add({"created_by":widget.auth.currentUser.uid}).then((value) {
                  //
                  // });
                },
                child: Card(
                  color: Colors.blue,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Join Room as Presenter"),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => WillPopScope(
                                onWillPop: () async => false,
                                child: Conf(
                                  containsVideo: false,
                                  ownID: widget.auth.currentUser.uid,
                                  isCaller: false,
                                  firestore: widget.firestore,
                                ),
                              )));
                },
                child: Card(
                  color: Colors.blue,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Join Room as Audience"),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class ProfileUpdate extends StatefulWidget {
  FirebaseAuth auth;

  FirebaseFirestore firestore;

  ProfileUpdate({this.auth, this.firestore});

  @override
  _ProfileUpdateState createState() => _ProfileUpdateState();
}

class _ProfileUpdateState extends State<ProfileUpdate> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

class StreamSocket {
  final _socketResponse = StreamController<dynamic>();

  void Function(dynamic) get addResponse => _socketResponse.sink.add;

  Stream<dynamic> get getResponse => _socketResponse.stream;

  void dispose() {
    _socketResponse.close();
  }
}
