import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:socket_io_client/socket_io_client.dart' as IO;



class AppSignal {

   IO.Socket socket;

   AppSignal();
   IO.Socket initSignal(){
    if(socket==null){
      //socket = IO.io('https://talk.maulaji.com');
      socket = IO.io('http://localhost:3000');
      socket.onConnect((_) {

      });
      return socket;
    }else{

      return socket;
    }

  }




}
