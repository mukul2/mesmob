import 'dart:collection';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/call/WebCallingSimple.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CommonFunctions {

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;
  HashMap onlineUser;
  HashMap awayUser;
  HashMap busyUser;
  CommonFunctions({this.auth,this.firestore,this.onlineUser,this.busyUser,this.awayUser});





  prePareUserPhoto({String uid}) {
    Widget statusWIdget;

    if (onlineUser.containsKey(uid) &&
        onlineUser[uid] + 3000 > DateTime.now().millisecondsSinceEpoch) {
      statusWIdget = InkWell(onTap: ()async{
        // uid
        if(uid == auth.currentUser.uid ){




          SharedPreferences prefs;
          Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
          prefs = await _prefs;
          String userStatus = prefs.getString("uStatus");
          if(userStatus == null){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));
          }
          if(userStatus!= null && userStatus == "online" ){
            prefs.setString("uStatus", "away");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "away" ){
            prefs.setString("uStatus", "busy");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "busy" ){
            prefs.setString("uStatus", "offline");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "offline" ){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));

          }
        }
      },
        child: Container(
          width: 10,
          height: 10,
          decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.greenAccent),
        ),
      );
    }else  if (awayUser.containsKey(uid) &&
        awayUser[uid] + 3000 > DateTime.now().millisecondsSinceEpoch) {
      statusWIdget = InkWell(onTap: ()async{
        // uid
        if(uid == auth.currentUser.uid ){
          SharedPreferences prefs;
          Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
          prefs = await _prefs;
          String userStatus = prefs.getString("uStatus");
          if(userStatus == null){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));
          }
          if(userStatus!= null && userStatus == "online" ){
            prefs.setString("uStatus", "away");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "away" ){
            prefs.setString("uStatus", "busy");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "busy" ){
            prefs.setString("uStatus", "offline");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "offline" ){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));

          }
        }
      },
        child: Container(
          width: 10,
          height: 10,
          decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.yellow),
        ),
      );
    }else  if (busyUser.containsKey(uid) &&
        busyUser[uid] + 3000 > DateTime.now().millisecondsSinceEpoch) {
      statusWIdget = InkWell(onTap: ()async{
        // uid
        if(uid == auth.currentUser.uid ){
          SharedPreferences prefs;
          Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
          prefs = await _prefs;
          String userStatus = prefs.getString("uStatus");
          if(userStatus == null){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));
          }
          if(userStatus!= null && userStatus == "online" ){
            prefs.setString("uStatus", "away");print(prefs.getString("uStatus"));


          }
          if(userStatus!= null && userStatus == "away" ){
            prefs.setString("uStatus", "busy");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "busy" ){
            prefs.setString("uStatus", "offline");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "offline" ){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));

          }
        }
      },
        child: Container(
          width: 10,
          height: 10,
          decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.redAccent),
        ),
      );
    }else {
      statusWIdget = InkWell(onTap: ()async{
        //uid
        if(uid == auth.currentUser.uid ){
          SharedPreferences prefs;
          Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
          prefs = await _prefs;
          String userStatus = prefs.getString("uStatus");
          if(userStatus == null){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));
          }
          if(userStatus!= null && userStatus == "online" ){
            prefs.setString("uStatus", "away");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "away" ){
            prefs.setString("uStatus", "busy");
            print(prefs.getString("uStatus"));

          }
          if(userStatus!= null && userStatus == "busy" ){
            prefs.setString("uStatus", "offline");
            print(prefs.getString("uStatus"));

          }if(userStatus!= null && userStatus == "offline" ){
            prefs.setString("uStatus", "online");
            print(prefs.getString("uStatus"));

          }
        }
      },
        child: Container(
          width: 10,
          height: 10,
          decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.grey),
        ),
      );
    }

    return StreamBuilder<QuerySnapshot>(
      // Initialize FlutterFire:
      //  future: Firebase.initializeApp(),
        stream: firestore.collection("users").where("uid",isEqualTo: uid).snapshots(),
        builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot) {

          if(snapshot.hasData && snapshot.data!=null&&snapshot.data.size>1 && snapshot.data.docs.length>0){
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,

                    child: snapshot.data.docs.first.data()["photo"]!=null?CircleAvatar(backgroundImage: NetworkImage("https://talk.maulaji.com/"+snapshot.data.docs.first.data()["photo"]),): CircleAvatar( backgroundImage: AssetImage("assets/user_photo.jpg"),),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: statusWIdget,
                    ),
                  )
                ],
              ),
            );
          }else return CircleAvatar( backgroundImage: AssetImage("assets/user_photo.jpg"),);
          //Image.asset("assets/user_photo.jpg")
        });




  }
  Widget getNameFromIdR(
  {String id, bool style}) {
    return FutureBuilder<QuerySnapshot>(
        future: firestore.collection("users").where("uid", isEqualTo: id).get(),
        builder: (context, snapuserInfo) {
          if (snapuserInfo.hasData) {
            return Text(
              snapuserInfo.data.docs.first.data()["name"],
              style: style
                  ? TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 20)
                  : TextStyle(),
            );
          } else {
            return Text("Please wait");
          }
        });
  }

  void initCallIntent({String callTYpe, String ownid, String partner,
      bool isCaller, BuildContext context}) async {
    //socket2.emit("calldial",{"partner":partner});
    // setState(() {
    //   widget.shouldShowIncomming = false;
    // });

    if (true) {


      List ids = [];
      ids.add(ownid);
      ids.add(partner);
      ids.sort();

      doSomething() {
        // setState(() {
        //   widget.callWidgetShow = false;
        //   widget.userStatus = "free";
        //   widget.CallDuration = 0;
        // });
        //   Navigator.pop(context);
      }

      callUserIsNoAvailable() {
        // setState(() {
        //   widget.callWidgetShow = false;
        //
        // });
        // Navigator.pop(context);
      }
      // firestore.collection("callHistory").add({
      //   "caller": isCaller ? ownid : partner,
      //   "target": isCaller ? partner : ownid,
      //   "time":DateTime.now().millisecondsSinceEpoch
      // }).then((value) {
      //
      // });

      callStartedNotify() {
        // setState(() {
        //   widget.CallDuration = widget.CallDuration + 1 ;
        // });

      }

      firestore.collection("users").where("uid",isEqualTo: partner).get().then((value){
        String partnerName = value.docs.first.data()["name"];
        firestore.collection("users").where("uid",isEqualTo: ownid).get().then((value){
          String ownName = value.docs.first.data()["name"];
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>WillPopScope(
                    onWillPop: () async => false,
                    child: SimpleWebCall(
                      containsVideo: false,
                      ownID: ownid,
                      partnerid: partner,
                      isCaller: isCaller,
                      firestore: firestore,
                      partnerPair: ids.first + "-" + ids.last,
                      callback: doSomething,
                      callStartedNotify: callStartedNotify,
                      callUserIsNoAvailable: callUserIsNoAvailable,
                      partnerName: partnerName,
                      ownName: ownName,

                    ),
                  )));
          // setState(() {
          //   widget.callWidget = WillPopScope(
          //     onWillPop: () async => false,
          //     child: SimpleWebCall(
          //       containsVideo: false,
          //       ownID: ownid,
          //       partnerid: partner,
          //       isCaller: isCaller,
          //       firestore: firestore,
          //       partnerPair: ids.first + "-" + ids.last,
          //       callback: doSomething,
          //       callStartedNotify: callStartedNotify,
          //       callUserIsNoAvailable: callUserIsNoAvailable,
          //       partnerName: partnerName,
          //       ownName: ownName,
          //
          //     ),
          //   );
          //   widget.callWidgetShow = true;
          // });
        });
      });









    }
  }

}