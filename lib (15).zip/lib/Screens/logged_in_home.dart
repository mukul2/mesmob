import 'dart:async';
import 'dart:html';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:drop_zone/drop_zone.dart';
import 'package:emojis/emoji.dart';
import 'package:http/http.dart' as http;
import 'dart:html' as html;
import 'dart:collection';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/services/Signal.dart';
import 'dart:io';
import 'dart:async';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:video_player/video_player.dart';
import 'dart:io';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/src/foundation/constants.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:maulajimessenger/call/WebCallingSimple.dart';
import 'package:maulajimessenger/call/WebCallingSimpleConf.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/io.dart';

StreamSocket streamSocket = new StreamSocket();

HashMap onlineUser = new HashMap<String, int>();

String base = "https://talk.maulaji.com/";

class Home extends StatefulWidget {
  int selectedTabMenu = 0;
  Widget chatBodyWidget = Center(
      child: Image.asset(
    "assets/background.png",
    fit: BoxFit.cover,
  ));

  bool isSearchModeOn = false;
  bool isCallFullScreen = true;
  String userStatus = "free";
  int CallDuration = 0;

  int selectedItem = 0;
  String partnerId;
  String partnerName;

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;
  dynamic chatBody;
  bool showEmojiList = false;
  bool showEmojiListSingle = false;
  SharedPreferences sharedPreferences;
  bool showMobileView = false;
  bool showProfileCompleteDialog = false;

  dynamic currentProfile;

  bool shouldShowIncomming = false;
  bool isRingTonePlaying = false;
  Widget callWidget = Text("");
  bool callWidgetShow = false;

  bool showMiniProfile = false;

  bool showSplash = true;
  String searchKey = "";

  int mobileViewLevel = 1;

  Home({
    Key key,
    @required this.auth,
    @required this.firestore,
    @required this.sharedPreferences,
  }) : super(key: key);

  @override
  _State createState() => _State();
}

class _State extends State<Home> {
  TextEditingController controller = new TextEditingController();
  TextEditingController controllerGrp = new TextEditingController();
  bool audioVolume = true;
  IO.Socket socket2;

  doSomething(data) {
    setState(() {
      widget.chatBody = data;
      startChatBodyViewCreate();
    });
  }

  final GlobalKey _menuKey = new GlobalKey();
  TextEditingController searchController = new TextEditingController();
  AudioPlayer audioPlayer;

  playLocal() async {
    if (true) {
      if (widget.isRingTonePlaying == false) {
        setState(() {
          widget.isRingTonePlaying = true;
        });
        //   audioPlayer.seek(Duration(seconds: 0)).then((value) {});
        audioPlayer.resume();
        // audioPlayer.onPlayerCompletion.listen((event) {
        //   audioPlayer.seek(Duration(seconds: 0)).then((value) {
        //     audioPlayer.resume();
        //   });
        //
        // });
      }
    }
  }

  StopRing() async {
    // audioPlayer.resume();

    if (widget.isRingTonePlaying) {
      audioPlayer.pause();
      setState(() {
        widget.isRingTonePlaying = false;
      });
    }
  }

  initAudio() async {
    audioPlayer = await AudioPlayer();
    if (kIsWeb) {
      await audioPlayer.setUrl("assets/assets/ring.mp3",
          isLocal: true);
    } else {
      // final byteData = await rootBundle.load('assets/ring.mp3');
      //
      // final file =
      //     File('${(await getTemporaryDirectory()).path}/ring.mp3');
      // await file.writeAsBytes(byteData.buffer
      //     .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));
      // //  audioPlayer.play(file.path,isLocal: true);
      // audioPlayer.setUrl(file.path, isLocal: true);
    }

    // await audioPlayer.setUrl("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3");
  }

  @override
  void initState() {
    initSignaling();
    callReceiveSignal();

    if (!kIsWeb) {
      Future.delayed(Duration(seconds: 3), () {
        setState(() {
          widget.showSplash = false;
        });
      });
    }

    initAudio();
    // TODO: implement initState
    super.initState();

    startChatBodyViewCreate();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width > 500) {
     // DeviceModeMobile.getInstance().dataReload();

      setState(() {
        widget.showMobileView = false;
        //widget.isCallFullScreen = false;
      });
    } else {

      //DeviceModeDesktop.getInstance().dataReload();
      setState(() {
        widget.showMobileView = true;
        //widget.isCallFullScreen = true;
      });
    }

    return Scaffold(backgroundColor: Color.fromARGB(5, 0,0, 0),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(0, kIsWeb ? 0 : 30, 0, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
              child: widget.callWidgetShow && widget.showMobileView
                  ? Container(
                height: widget.isCallFullScreen
                    ? MediaQuery.of(context).size.height
                    : 50,
                width: MediaQuery.of(context).size.width,
                color: Colors.redAccent,
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                          height: MediaQuery.of(context).size.height - 70,
                          child: widget.callWidget),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              widget.isCallFullScreen =
                              !widget.isCallFullScreen;
                            });
                          },
                          child: Container(
                              height: 50,
                              width: MediaQuery.of(context).size.width,
                              color: Colors.redAccent,
                              child: Center(
                                  child: Text(
                                    widget.isCallFullScreen
                                        ? "Back to Chat"
                                        : "Back to Call",
                                    style: TextStyle(color: Colors.white),
                                  )))),
                    ),
                  ],
                ),
              )
                  : Container(
                height: 0,
                width: 0,
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: !widget.showMobileView
                        ? Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getFndList(),
                        Container(
                          color: Colors.grey,
                          width: 1,
                          height: widget.showMobileView &&
                              widget.callWidgetShow
                              ? MediaQuery.of(context).size.height - 70
                              : MediaQuery.of(context).size.height,
                        ),
                        getBody(),
                      ],
                    )
                        :  widget.mobileViewLevel == 1
                        ? Stack(
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: getFndList(),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: !widget.showMobileView
                              ? Align(
                            alignment: Alignment.topRight,
                            child: Visibility(
                              visible: widget.callWidgetShow,
                              child: Padding(
                                padding:
                                const EdgeInsets.all(8.0),
                                child: Card(
                                  elevation: 10,
                                  child: Container(
                                    //color: Colors.grey,
                                    height: widget
                                        .isCallFullScreen
                                        ? MediaQuery.of(context)
                                        .size
                                        .height
                                        : 300,
                                    width: widget
                                        .isCallFullScreen
                                        ? MediaQuery.of(context)
                                        .size
                                        .width -
                                        0
                                        : (300),
                                    child: Stack(
                                      children: [
                                        Align(
                                          alignment:
                                          Alignment.center,
                                          child:
                                          widget.callWidget,
                                        ),
                                        Align(
                                          alignment: Alignment
                                              .bottomLeft,
                                          child: InkWell(
                                              onTap: () {
                                                setState(() {
                                                  widget.isCallFullScreen =
                                                  !widget
                                                      .isCallFullScreen;
                                                });
                                              },
                                              child: Container(
                                                  color: Colors
                                                      .white,
                                                  child: Icon(
                                                    widget.isCallFullScreen
                                                        ? Icons
                                                        .fullscreen_exit
                                                        : Icons
                                                        .fullscreen_outlined,
                                                    color: Colors
                                                        .black,
                                                  ))),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                              : Container(
                            width: 0,
                            height: 0,
                          ),
                        ),
                      ],
                    )
                        : getBody(),
                  ),
                  widget.callWidgetShow && !widget.showMobileView
                      ? Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: Container(
                        //color: Colors.grey,
                        height: widget.isCallFullScreen
                            ? (MediaQuery.of(context).size.height)
                            : (widget.showMobileView ? 70 : 0),
                        width: widget.isCallFullScreen
                            ? (widget.showMobileView
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width - 0)
                            : (500),
                        child: Stack(
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: widget.callWidget,
                            ),
                            Align(
                              alignment: Alignment.bottomLeft,
                              child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      widget.isCallFullScreen =
                                      !widget.isCallFullScreen;
                                    });
                                  },
                                  child: Container(
                                      color: Colors.white,
                                      child: Icon(
                                        widget.isCallFullScreen
                                            ? Icons.fullscreen_exit
                                            : Icons.fullscreen_outlined,
                                        color: Colors.black,
                                      ))),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                      : Container(
                    width: 0,
                    height: 0,
                  ),
                  widget.shouldShowIncomming
                      ? Align(
                    alignment: Alignment.center,
                    child: Center(
                      child: Container(
                        height: widget.showMobileView
                            ? MediaQuery.of(context).size.height
                            : MediaQuery.of(context).size.height * 0.4,
                        width: widget.showMobileView
                            ? MediaQuery.of(context).size.width
                            : MediaQuery.of(context).size.width * 0.4,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topRight,
                              end: Alignment.bottomLeft,
                              colors: [
                                Colors.blue,
                                Colors.lightBlueAccent,
                                Colors.blueAccent,
                                Colors.lightBlue,
                              ],
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "Incomming Call",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25),
                                  ),
                                )),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: FutureBuilder<QuerySnapshot>(
                                  // Initialize FlutterFire:
                                  //  future: Firebase.initializeApp(),
                                    future:widget.firestore.collection("users").where("uid",isEqualTo: widget.partnerId).get(),
                                    builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot) {if(snapshot.hasData && snapshot.data.docs.first.data()!=null){
                                      if(snapshot.data.docs.first.data()["photo"]!=null)
                                        return CircleAvatar(radius: 30,backgroundImage: NetworkImage(  base +snapshot.data.docs.first.data()["photo"]),);
                                      else return Image.asset("assets/user_photo.png");

                                    }else return CircleAvatar();

                                    }),
                              ),
                            ),
                            Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    widget.partnerName,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20),
                                  ),
                                )),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.center,
                                crossAxisAlignment:
                                CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        audioPlayer.pause();

                                        if (true) {
                                          String partnerID =
                                              widget.partnerId;
                                          if (partnerID != null) {
                                            initCallIntent(
                                                "a",
                                                widget
                                                    .auth.currentUser.uid,
                                                partnerID,
                                                false,
                                                widget.firestore,
                                                context);
                                          }
                                        }
                                      },
                                      child: Card(
                                        color: Colors.greenAccent,
                                        child: Center(
                                            child: Padding(
                                              padding:
                                              const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Answer",
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                                            )),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        StopRing();
                                        AppSignal().initSignal().emit(
                                            "reject", {
                                          "id":
                                          widget.auth.currentUser.uid
                                        });
                                        setState(() {
                                          widget.shouldShowIncomming =
                                          false;
                                        });
                                        if (false) {
                                          widget.firestore
                                              .collection("callQue")
                                              .doc(widget
                                              .auth.currentUser.uid)
                                              .update({"active": false});
                                          widget.firestore
                                              .collection("callQue")
                                              .doc(widget.partnerId)
                                              .update({"active": false});
                                        }
                                      },
                                      child: Card(
                                        color: Colors.redAccent,
                                        child: Center(
                                            child: Padding(
                                              padding:
                                              const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Decline",
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                                            )),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            // Row(
                            //   mainAxisAlignment: MainAxisAlignment.center,
                            //   crossAxisAlignment: CrossAxisAlignment.center,
                            //   children: [
                            //     Padding(
                            //       padding: const EdgeInsets.all(20.0),
                            //       child: FloatingActionButton(
                            //         backgroundColor: Colors.greenAccent,
                            //         onPressed: () {
                            //           String partnerID = widget.partnerId;
                            //           if (partnerID != null) {
                            //             initCallIntent(
                            //                 "a",
                            //                 widget.auth.currentUser.uid,
                            //                 partnerID,
                            //                 false,
                            //                 widget.firestore,
                            //                 context);
                            //           }
                            //         },
                            //         child: Icon(Icons.call, color: Colors.white),
                            //       ),
                            //     ),
                            //     Padding(
                            //       padding: const EdgeInsets.all(20.0),
                            //       child: FloatingActionButton(
                            //         backgroundColor: Colors.redAccent,
                            //         onPressed: () {
                            //           widget.firestore
                            //               .collection("callQue")
                            //               .doc(widget.auth.currentUser.uid)
                            //               .update({"active": false});
                            //           widget.firestore
                            //               .collection("callQue")
                            //               .doc(widget.partnerId)
                            //               .update({"active": false});
                            //         },
                            //         child:
                            //             Icon(Icons.call_end, color: Colors.white),
                            //       ),
                            //     )
                            //   ],
                            // ),
                          ],
                        ),
                      ),
                    ),
                  )
                      : Container(
                    height: 0,
                    width: 0,
                  ),
                  !kIsWeb && widget.showSplash
                      ? Align(
                    child: Image.asset(
                      "assets/splash_app.jpg",
                      fit: BoxFit.cover,
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height,
                    ),
                  )
                      : Container(
                    height: 0,
                    width: 0,
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );

    return Scaffold(
      body: Column(
        children: [
          widget.shouldShowIncomming
              ? Container(
                  color: Colors.redAccent,
                  height: 60,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: FloatingActionButton(
                                onPressed: () {
                                  String partnerID = widget.partnerId;
                                  if (partnerID != null) {
                                    initCallIntent(
                                        "a",
                                        widget.auth.currentUser.uid,
                                        partnerID,
                                        false,
                                        widget.firestore,
                                        context);
                                  }
                                },
                                child: Icon(Icons.call, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              : Container(
                  height: 0,
                  width: 0,
                ),
          !widget.showMobileView
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getFndList(),
                    Container(
                      color: Colors.grey,
                      width: 1,
                      height: MediaQuery.of(context).size.height,
                    ),
                    getBody(),
                  ],
                )
              : getFndList(),
        ],
      ),
    );

    return Scaffold(
      body: widget.shouldShowIncomming
          ? Container(
              height: 100,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: FloatingActionButton(
                            onPressed: () {
                              String partnerID = widget.partnerId;
                              if (partnerID != null) {
                                initCallIntent(
                                    "a",
                                    widget.auth.currentUser.uid,
                                    partnerID,
                                    false,
                                    widget.firestore,
                                    context);
                              }
                            },
                            child: Icon(Icons.call, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            )
          : !widget.showMobileView
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getFndList(),
                    Container(
                      color: Colors.grey,
                      width: 1,
                      height: MediaQuery.of(context).size.height,
                    ),
                    getBody(),
                  ],
                )
              : getFndList(),
    );
  }

  Widget getFndList() {
    final button = new PopupMenuButton(
      key: _menuKey,
      itemBuilder: (_) => <PopupMenuItem<String>>[
        //  new PopupMenuItem<String>(child: const Text('Plain Web'), value: 'web'),
        new PopupMenuItem<String>(child: const Text('Logout'), value: 'logout'),
      ],
      onSelected: (String choice) async {
        if (choice == "logout") {
          widget.auth.signOut();
        }
        if (choice == "profile") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ProfileUpdate(
                      auth: widget.auth, firestore: widget.firestore)));
        }
        if (choice == "grp") {
          //GroupCall

          QuerySnapshot q = await widget.firestore
              .collection("users")
              .where("uid", isEqualTo: widget.auth.currentUser.uid)
              .get();

          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) =>  WillPopScope(
          //           onWillPop: () async => false,
          //           child: GroupCall(
          //               room_id: "grp",
          //               containsVideo: true,
          //               ownID: widget.auth.currentUser.uid,
          //               partnerid:"",
          //               isCaller:
          //               true,
          //               firestore:
          //               widget.firestore),
          //
          //         )));
          // }
          // if (choice == "web") {
          //   //GroupCall
          //   Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //           builder: (context) =>  WillPopScope(
          //             onWillPop: () async => false,
          //             child: PlainWebCall(
          //                 containsVideo: true,
          //                 ownID:"p"+widget.sharedPreferences.getString("patient_id"),
          //                 partnerid:"d162",
          //                 isCaller:
          //                 true,
          //                 firestore:
          //                 widget.firestore),
          //
          //           )));
        }
      },
    );
    return Stack(
      children: [
        Align(
          alignment: Alignment.topCenter,
          child: Container(
            height: MediaQuery.of(context).size.height,
            color: Color.fromARGB(255,238, 246, 255),
            width:
                widget.showMobileView ? MediaQuery.of(context).size.width : 349,
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(height: 70,color:  Color.fromARGB(255,238, 246, 255),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 0, 8),
                    child: Container(
                      height: 50,
                      child: Center(
                        child: Stack(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    widget.showMiniProfile = true;
                                  });
                                },
                                child: Center(
                                  child: Row(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 0, 10, 0),
                                        child: prePareUserPhoto(widget.auth,
                                            widget.auth.currentUser.uid),

                                        // child: CircleAvatar(radius: 18,backgroundImage: NetworkImage("https://images-na.ssl-images-amazon.com/images/I/71Y2Ov9rHaL._SL1500_.jpg",)),
                                      ),
                                      getNameFromIdR(widget.auth.currentUser.uid,
                                          false, widget.firestore, widget.auth)

                                      //Text(widget.sharedPreferences.get("uphoto")),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: button,
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                widget.isSearchModeOn == false
                    ? Column(
                        children: [
                          InkWell(
                            onTap: () {
                              setState(() {
                                widget.isSearchModeOn = true;
                              });
                            },
                            child: Stack(
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 10),
                                    child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          border:
                                              Border.all(color: Colors.grey),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(
                                                  3.0) //                 <--- border radius here
                                              ),
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Row(
                                            children: [
                                              Center(child: Icon(Icons.search)),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        10, 0, 0, 0),
                                                child: Center(
                                                    child: Text("Search")),
                                              ),
                                            ],
                                          ),
                                        )),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Container(
                              height: 50,
                              child: Row(
                                children: [
                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 0;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.chat,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              0
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Chat",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                0
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),

                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 1;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.contacts,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              1
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Contacts",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                1
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),
                                  Expanded(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              widget.selectedTabMenu = 2;
                                            });
                                          },
                                          child: Column(
                                            children: [
                                              Icon(Icons.group,
                                                  color:
                                                      widget.selectedTabMenu ==
                                                              2
                                                          ? Theme.of(context)
                                                              .primaryColor
                                                          : Colors.grey),
                                              Center(
                                                  child: Text(
                                                "Group Chat",
                                                style: TextStyle(
                                                    color:
                                                        widget.selectedTabMenu ==
                                                                2
                                                            ? Theme.of(context)
                                                                .primaryColor
                                                            : Colors.grey),
                                              )),
                                            ],
                                          ))),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: 1,
                              color: Colors.grey,
                            ),
                          ),
                          getSmallTab(),
                        ],
                      )
                    : Column(
                        children: [
                          Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [
                                  Colors.blueAccent,
                                  Colors.blue,
                                  Colors.lightBlue,
                                  Colors.lightBlue,
                                ],
                              )),
                              child: Container(
                                height: 60,
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: TextFormField(
                                          onChanged: (val) {
                                            setState(() {
                                              widget.searchKey = val;
                                            });
                                          },
                                          controller: searchController,
                                          cursorColor: Colors.white,
                                          style: TextStyle(color: Colors.white),
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintText: "Search People",
                                            hintStyle:
                                                TextStyle(color: Colors.white),
                                            contentPadding: EdgeInsets.all(10),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Container(
                                        width: 40,
                                        height: 40,
                                        child: Center(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: InkWell(
                                              onTap: () {
                                                setState(() {
                                                  searchController.text = "";

                                                  widget.isSearchModeOn = false;
                                                });
                                              },
                                              child: Icon(
                                                Icons.close,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )),

                          StreamBuilder<QuerySnapshot>(
                              stream: widget.firestore
                                  .collection("users")
                                  //.where("uid", isNotEqualTo:  widget.auth.currentUser.uid)
                                  .snapshots(),
                              builder: (BuildContext context,
                                  AsyncSnapshot<QuerySnapshot> snapshot) {
                                if (snapshot.hasData &&
                                    snapshot.data.docs.length > 0) {
                                  List filtereData = [];
                                  if (searchController.text.isNotEmpty &&
                                      searchController.text != "" &&
                                      searchController.text.length > 0) {
                                    for (int i = 0;
                                        i < snapshot.data.docs.length;
                                        i++) {
                                      if (snapshot.data.docs[i].data()["uid"] !=
                                              widget.auth.currentUser.uid &&
                                          snapshot.data.docs[i]
                                              .data()["name"]
                                              .toString()
                                              .toLowerCase()
                                              .startsWith(searchController.text
                                                  .toLowerCase()))
                                        filtereData
                                            .add(snapshot.data.docs[i].data());
                                    }
                                  }
                                  return ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: filtereData.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Container(
                                        child: new InkWell(
                                          onTap: () async {
                                            setState(() {
                                              widget.searchKey = "";
                                              widget.chatBody =
                                                  filtereData[index];
                                              widget.selectedItem = index;
                                            });
                                            if (widget.showMobileView) {
                                              setState(() {
                                                widget.mobileViewLevel = 2;

                                              });
                                            }
                                            startChatBodyViewCreate();
                                          },
                                          child: ListTile(
                                            tileColor: Color.fromARGB(
                                                255, 249, 252, 255),
                                            leading: prePareUserPhotoOld(
                                                filtereData[index]["uid"] !=
                                                        null
                                                    ? filtereData[index]["uid"]
                                                    : (filtereData[index]
                                                                ["sender"] !=
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? filtereData[index]
                                                            ["sender"]
                                                        : filtereData[index]
                                                            ["receiver"])),
                                            title: Text(
                                                filtereData[index]["name"]),
                                            subtitle: Padding(
                                              padding:
                                                  const EdgeInsets.all(5.0),
                                              child: Text("Send Message"),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                } else {
                                  return Text("No Match");
                                }
                              }),
                          //searchController.text
                        ],
                      ),
              ],
            ),
          ),
        ),
        widget.showMiniProfile
            ? Positioned(
                left: 0,
                right: 0,
                top: 60,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    color: Colors.white,
                    elevation: 8,
                    child: Column(
                      children: [
                        ListTile(
                          title: Padding(
                            padding: EdgeInsets.all(0),
                            child: Image.asset(
                              "assets/maulaji_sqr.png",
                              height: 50,
                              fit: BoxFit.cover,
                            ),
                          ),
                          onTap: () {
                            setState(() {
                              widget.showMiniProfile = false;
                            });
                          },
                          trailing: Icon(Icons.close),
                        ),
                        Divider(),
                        Center(
                          child: Row(
                            children: [
                              Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(20, 0, 10, 0),
                                  child: prePareUserPhoto(widget.auth,
                                      widget.auth.currentUser.uid)),

                              // child: CircleAvatar(radius: 18,backgroundImage: NetworkImage("https://images-na.ssl-images-amazon.com/images/I/71Y2Ov9rHaL._SL1500_.jpg",)),

                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  getNameFromIdWithStyle(
                                      widget.auth.currentUser.uid,
                                      TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                      widget.firestore,
                                      widget.auth),
                                  Text(widget.auth.currentUser.email != null &&
                                          widget.auth.currentUser.email.length >
                                              0
                                      ? (widget.auth.currentUser.email)
                                      : (widget.auth.currentUser.phoneNumber)),
                                  InkWell(
                                    onTap: () async {
                                      FilePickerResult result =
                                          await FilePicker.platform.pickFiles();

                                      if (result != null) {
                                        PlatformFile file = result.files.first;

                                        print(file.name);
                                        // print(file.bytes);
                                        // _base64 = BASE64.encode(response.bodyBytes);
                                        String base = base64.encode(file.bytes);

                                        String url =
                                            "https://talk.maulaji.com/uploadfilemessenger.php";

                                        print(file.size);
                                        print(file.extension);
                                        print(file.path);
                                        //print("base");
                                        // print(base);

                                        var response = await http.post(
                                            Uri.parse(url),
                                            body: jsonEncode({
                                              'name': file.name,
                                              'file': base,
                                              'ex': file.extension
                                            }));
                                        print(
                                            'Response status: ${response.statusCode}');
                                        print(response.body);
                                        dynamic res = jsonDecode(response.body);
                                        if (res["status"]) {
                                          //res["path"]
                                          widget.firestore
                                              .collection("users")
                                              .where("uid",
                                                  isEqualTo: widget
                                                      .auth.currentUser.uid)
                                              .get()
                                              .then((value) {
                                            widget.firestore
                                                .collection("users")
                                                .doc(value.docs.first.id)
                                                .update({"photo": res["path"]});
                                          });
                                        } else {
                                          print("could not save");
                                        }
                                      } else {
                                        // User canceled the picker
                                      }
                                    },
                                    child: Text(
                                      "Change Photo",
                                      style: TextStyle(
                                          color:
                                              Theme.of(context).primaryColor),
                                    ),
                                  ),
                                ],
                              )

                              //Text(widget.sharedPreferences.get("uphoto")),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 300,
                        ),
                      ],
                    ),
                  ),
                ))
            : Container(
                height: 0,
                width: 0,
              ),
      ],
    );
  }

  Widget getBody() {
    if (false) {
      return Container(
          height: MediaQuery.of(context).size.height,
          width: widget.showMobileView
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width - 350,
          child: Scaffold(
            body: Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text("Select a user to chat"),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Visibility(
                    visible: widget.callWidgetShow,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 10,
                        child: Container(
                          //color: Colors.grey,
                          height: widget.isCallFullScreen
                              ? MediaQuery.of(context).size.height
                              : (MediaQuery.of(context).size.height * 0.20),
                          width: widget.isCallFullScreen
                              ? MediaQuery.of(context).size.width - 350
                              : (MediaQuery.of(context).size.width * 0.20),
                          child: Stack(
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: widget.callWidget,
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.isCallFullScreen =
                                            !widget.isCallFullScreen;
                                      });
                                    },
                                    child: Icon(
                                      widget.isCallFullScreen
                                          ? Icons.fullscreen_exit
                                          : Icons.fullscreen_outlined,
                                      color: Colors.white,
                                    )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ));
    } else {
      return Container(width: MediaQuery.of(context).size.width-358,
        child: Padding(
          padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
          child: Container(
              color: Colors.white,
              height: !kIsWeb && !widget.callWidgetShow
                  ? MediaQuery.of(context).size.height
                  : MediaQuery.of(context).size.height,
              width: widget.showMobileView
                  ? MediaQuery.of(context).size.width
                  : MediaQuery.of(context).size.width - 0,
              child: widget.chatBodyWidget),
        ),
      );
    }
  }

  // Future<void> _handleCameraAndMic() async {
  //   await PermissionHandler().requestPermissions(
  //     [PermissionGroup.camera, PermissionGroup.microphone],
  //   );
  // }
  void initCallIntent(String callTYpe, String ownid, String partner,
      bool isCaller, FirebaseFirestore firestore, BuildContext context) async {
    //socket2.emit("calldial",{"partner":partner});
    setState(() {
      widget.shouldShowIncomming = false;
    });

    if (true) {
      if (!kIsWeb) {
        // await _handleCameraAndMic();
      }
/*
    QuerySnapshot callerNameQ = await firestore
        .collection("users")
        .where("uid", isEqualTo: isCaller ? ownid : partner)
        .get();
    String callerName = callerNameQ.docs.first.data()["name"];

    QuerySnapshot targetNameQ = await firestore
        .collection("users")
        .where("uid", isEqualTo: isCaller ? partner : ownid)
        .get();
    String targetName = targetNameQ.docs.first.data()["name"];
    await firestore.collection("callQue").doc(ownid).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid,
      "callerName": callerName,
      "targetName": targetName
    });
    await firestore.collection("callQue").doc(partner).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid,
      "callerName": callerName,
      "targetName": targetName
    });
    await firestore.collection("refresh").doc(ownid).delete();
    await firestore.collection("refresh").doc(partner).delete();
    firestore
        .collection("callQue")
        .doc(ownid)
        .snapshots()
        .listen((valueCaller) {
      if (valueCaller.exists &&
          valueCaller.data() != null &&
          valueCaller.data()["active"] == null) {} else {
        setState(() {
          widget.callWidgetShow = false;
          widget.userStatus = "incall";
        });
      }
    });

 */
      List ids = [];
      ids.add(ownid);
      ids.add(partner);
      ids.sort();

      doSomething() {
        setState(() {
          widget.callWidgetShow = false;
          widget.userStatus = "free";
          widget.CallDuration = 0;
        });
     //   Navigator.pop(context);
      }

      callUserIsNoAvailable() {
        setState(() {
          widget.callWidgetShow = false;

        });
       // Navigator.pop(context);
      }
      // firestore.collection("callHistory").add({
      //   "caller": isCaller ? ownid : partner,
      //   "target": isCaller ? partner : ownid,
      //   "time":DateTime.now().millisecondsSinceEpoch
      // }).then((value) {
      //
      // });

      callStartedNotify() {
        // setState(() {
        //   widget.CallDuration = widget.CallDuration + 1 ;
        // });
        if (false) {
          setState(() {
            widget.CallDuration = widget.CallDuration + 1;
          });

          Timer.periodic(Duration(milliseconds: 1000), (timer) {
            if (mounted) {
              setState(() {
                widget.CallDuration = widget.CallDuration + 1;
              });
            } else {
              timer.cancel();
            }
          });
        }
      }

      firestore.collection("users").where("uid",isEqualTo: partner).get().then((value){
        String partnerName = value.docs.first.data()["name"];
        firestore.collection("users").where("uid",isEqualTo: ownid).get().then((value){
          String ownName = value.docs.first.data()["name"];
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>WillPopScope(
                    onWillPop: () async => false,
                    child: SimpleWebCall(
                      containsVideo: false,
                      ownID: ownid,
                      partnerid: partner,
                      isCaller: isCaller,
                      firestore: firestore,
                      partnerPair: ids.first + "-" + ids.last,
                      callback: doSomething,
                      callStartedNotify: callStartedNotify,
                      callUserIsNoAvailable: callUserIsNoAvailable,
                      partnerName: partnerName,
                      ownName: ownName,

                    ),
                  )));
          // setState(() {
          //   widget.callWidget = WillPopScope(
          //     onWillPop: () async => false,
          //     child: SimpleWebCall(
          //       containsVideo: false,
          //       ownID: ownid,
          //       partnerid: partner,
          //       isCaller: isCaller,
          //       firestore: firestore,
          //       partnerPair: ids.first + "-" + ids.last,
          //       callback: doSomething,
          //       callStartedNotify: callStartedNotify,
          //       callUserIsNoAvailable: callUserIsNoAvailable,
          //       partnerName: partnerName,
          //       ownName: ownName,
          //
          //     ),
          //   );
          //   widget.callWidgetShow = true;
          // });
        });
      });




      if (widget.showMobileView) {}




    }
  }

  void initCallIntentMobile(String callTYpe, String ownid, String partner,
      bool isCaller, FirebaseFirestore firestore, BuildContext context) async {
    print("found");
    if (!kIsWeb) {
      // await _handleCameraAndMic();
    }

/*
    await firestore.collection("callQue").doc(ownid).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("callQue").doc(partner).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("refresh").doc(ownid).delete();
    await firestore.collection("refresh").doc(partner).delete();
    firestore
        .collection("callQue")
        .doc(ownid)
        .snapshots()
        .listen((valueCaller) {
      if (valueCaller.exists &&
          valueCaller.data() != null &&
          valueCaller.data()["active"] == null) {
      } else {
        setState(() {
          widget.callWidgetShow = false;
        });
      }

    });

 */
    List ids = [];
    ids.add(ownid);
    ids.add(partner);
    ids.sort();

    doSomething() {
      setState(() {
        widget.callWidgetShow = false;
      });
    }

    firestore
        .collection("users")
        .where("uid", isEqualTo: FirebaseAuth.instance.currentUser.uid)
        .get()
        .then((value) {
      print(value.docs.first.data()["name"]);
      setState(() {
        widget.callWidget = WillPopScope(
          onWillPop: () async => false,
          child: SimpleWebCall(
            containsVideo: false,
            ownID: ownid,
            partnerid: partner,
            isCaller: isCaller,
            firestore: firestore,
            partnerPair: ids.first + "-" + ids.last,
            callback: doSomething,
            ownName: value.docs.first.data()["name"] == null
                ? "No name found"
                : value.docs.first.data()["name"],
          ),
        );
        widget.callWidgetShow = true;
      });
    });

/*
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => WillPopScope(
                  onWillPop: () async => false,
                  child: SimpleWebCall(
                    containsVideo: callTYpe == false,
                    ownID: ownid,
                    partnerid: partner,
                    isCaller: isCaller,
                    firestore: firestore,
                    partnerPair: ids.first + "-" + ids.last,
                  ),
                )));

 */
  }

  Widget getEmailFromId(body) {
    return FutureBuilder<QuerySnapshot>(
        future: widget.firestore
            .collection("users")
            .where("uid",
                isEqualTo: body["uid"] != null
                    ? body["uid"]
                    : (body["receiver"] == widget.auth.currentUser.uid
                        ? body["sender"]
                        : body["receiver"]))
            .get(),
        builder: (context, snapuserInfo) {
          if (snapuserInfo.hasData) {
            return Text(
              snapuserInfo.data.docs.first.data()["email"],
              style: TextStyle(),
            );
          } else {
            return Text("No Email address found");
          }
        });
  }

  Widget createLastChatList() {
    //return Text("Please wait") ;
    List oneS = [];
    List oneR = [];
    List Sum = [];

    Widget returnWidget = Text("Please wait");

    widget.firestore
        .collection("last")
        .where("sender", isEqualTo: widget.auth.currentUser.uid)
        .snapshots()
        .listen((event) {
      if (event.size > 0 && event.docs.length > 0) {
        oneS = event.docs;
        Sum.clear();
        Sum.addAll(oneS);
        Sum.addAll(oneR);

        returnWidget = Text(Sum.length.toString());

        return returnWidget;
      } else {
        return returnWidget;
      }
    });
    widget.firestore
        .collection("last")
        .where("receiver", isEqualTo: widget.auth.currentUser.uid)
        .snapshots()
        .listen((event) {
      if (event.size > 0 && event.docs.length > 0) {
        oneR = event.docs;
        Sum.clear();
        Sum.addAll(oneS);
        Sum.addAll(oneR);

        returnWidget = Text(Sum.length.toString());
        return returnWidget;
      } else {
        return returnWidget;
      }
    });

    return returnWidget;

    /*

    StreamBuilder<QuerySnapshot>(
        stream: widget.firestore
            .collection("last")
            .where("sender", isEqualTo: widget.auth.currentUser.uid)
            .snapshots(),
        builder: (context, projectSnapSender) {
          List allHistory = [];
          if (projectSnapSender.hasData) {
            if (true || projectSnapSender.data.docs.length > 0)
              allHistory.addAll(projectSnapSender.data.docs);
            return StreamBuilder<QuerySnapshot>(
                stream: widget.firestore
                    .collection("last")
                    .where("receiver", isEqualTo: widget.auth.currentUser.uid)
                    .snapshots(),
                builder: (context, projectSnapReceiver) {
                  if (projectSnapReceiver.hasData) {
                    if (true|| projectSnapReceiver.data.docs.length > 0)
                      allHistory.addAll(projectSnapSender.data.docs);
                  } else {
                    return Text("Please wait");
                  }
                  List filteredData = [];
                  for (int i = 0; i < allHistory.length; i++) {
                    if ( allHistory[i].data()["sender"] != widget.auth.currentUser.uid) {
                      filteredData.add(allHistory[i]);
                    }
                    if ( allHistory[i].data()["receiver"] !=
                        widget.auth.currentUser.uid) {
                      filteredData.add(allHistory[i]);
                    }
                  }
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: (filteredData == null)
                        ? 0
                        : filteredData.length,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return Container(
                        child: new InkWell(
                          onTap: () async {
                            setState(() {
                              widget.chatBody =
                                  filteredData[index]
                                      .data();
                              widget.selectedItem = index;
                            });
                          },
                          child: ListTile(
                            tileColor:
                            widget.selectedItem == index
                                ? Color.fromARGB(
                                255, 206, 231, 255)
                                : Color.fromARGB(
                                255, 249, 252, 255),
                            leading: CircleAvatar(
                                radius: 18,
                                backgroundImage: NetworkImage(
                                    "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                            // title: Text(filteredData[index].data()["receiver"]),
                            title: getNameFromId(filteredData[index].data(),false),
                            subtitle: Padding(
                              padding:
                              const EdgeInsets.all(5.0),
                              child: Text("Sub title"),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                });
          } else {
            return Text("No Chat history");
            return StreamBuilder<QuerySnapshot>(
                stream: widget.firestore
                    .collection("last")
                    .where("receiver",
                    isEqualTo:
                    widget.auth.currentUser.uid)
                    .snapshots(),
                builder: (context, projectSnapReceiver) {
                  if (projectSnapReceiver.hasData) {
                    if (projectSnapReceiver
                        .data.docs.length >
                        0)
                      allHistory.addAll(
                          projectSnapSender.data.docs);
                  } else {
                    return Text("Please wait");
                  }
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: (allHistory == null)
                        ? 0
                        : allHistory.length,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return Container(
                        child: new InkWell(
                          onTap: () async {
                            setState(() {
                              widget.chatBody =
                                  allHistory[index].data();
                              widget.selectedItem = index;
                            });
                          },
                          child: ListTile(
                            tileColor:
                            widget.selectedItem == index
                                ? Color.fromARGB(
                                255, 206, 231, 255)
                                : Color.fromARGB(
                                255, 249, 252, 255),
                            leading: CircleAvatar(
                                radius: 18,
                                backgroundImage: NetworkImage(
                                    "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                            title: Text(allHistory[index]
                                .data()["receiver"]),
                            subtitle: Padding(
                              padding:
                              const EdgeInsets.all(5.0),
                              child: Text("Sub title"),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                });
            ;
          }
        })

     */
  }

  prePareUserPhotoOld(String uid) {
    return StreamBuilder<DocumentSnapshot>(
        // Initialize FlutterFire:
        //  future: Firebase.initializeApp(),
        stream: widget.firestore.collection("user_status").doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData &&
              snapshot.data.exists &&
              snapshot.data.data() != null) {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Image.asset("assets/user_photo.jpg"),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: snapshot.data.data()["status"] == "free" &&
                                    snapshot.data.data()["time"] + 3000 >
                                        DateTime.now().millisecondsSinceEpoch
                                ? Colors.greenAccent
                                : (snapshot.data.data()["status"] == "incall" &&
                                        snapshot.data.data()["time"] + 3000 >
                                            DateTime.now()
                                                .millisecondsSinceEpoch
                                    ? Colors.redAccent
                                    : Colors.grey)),
                      ),
                    ),
                  )
                ],
              ),
            );
          } else {
            return Container(
              height: 40,
              width: 40,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Image.asset("assets/user_photo.jpg"),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.grey),
                      ),
                    ),
                  )
                ],
              ),
            );
          }
        });
  }

  String getCallTime() {
    // return " 00:" + widget.CallDuration.toString();
  }

  Widget showAddFndDialog() {
    if (widget.chatBody == null) {
      return Container(
        height: 0,
        width: 0,
      );
    } else {
      String fndID = widget.chatBody["sender"] != null
          ? (widget.chatBody["sender"] == widget.auth.currentUser.uid
              ? widget.chatBody["receiver"]
              : widget.chatBody["sender"])
          : widget.chatBody["uid"];

      return StreamBuilder<QuerySnapshot>(
          stream: widget.firestore
              .collection("fnd")
              .where("self", isEqualTo: widget.auth.currentUser.uid)
              .where("fnd", isEqualTo: fndID)
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData &&
                snapshot.data.size > 0 &&
                snapshot.data.size > 0) {
              return Container(
                width: 0,
                height: 0,
              );
            } else {
              return Positioned(
                  top: 75,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Wrap(
                      children: [
                        InkWell(
                          onTap: () {
                            widget.firestore.collection("fnd").add({
                              "self": widget.auth.currentUser.uid,
                              "fnd": fndID,
                              "active": true
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                color: Theme.of(context).primaryColor,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(10, 5, 10, 5),
                                  child: Text(
                                    "Add to Contact",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            widget.firestore.collection("fnd").add({
                              "self": widget.auth.currentUser.uid,
                              "fnd": fndID,
                              "active": false
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                                color: Colors.white,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(10, 5, 10, 5),
                                  child: Text(
                                    "Don't add to Contact",
                                    style: TextStyle(
                                        color: Colors.redAccent,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                        )
                      ],
                    ),
                  ));
            }
          });
    }

    // return  widget.chatBody != null
    //       ? Positioned(
    //       top: 75,
    //       left: 0,
    //       right: 0,
    //       child: Center(
    //         child: Wrap(
    //           children: [
    //             InkWell(onTap: (){
    //
    //
    //               widget.firestore.collection("fnd").add({"self":widget.auth.currentUser.uid,"fnd":fndID,"active":true});
    //
    //             },
    //               child: Padding(
    //                 padding: const EdgeInsets.all(8.0),
    //                 child: Card(
    //                     color: Theme.of(context).primaryColor,
    //                     child: Padding(
    //                       padding:
    //                       const EdgeInsets.fromLTRB(10, 5, 10, 5),
    //                       child: Text(
    //                         "Add to Contact",
    //                         style: TextStyle(
    //                             color: Colors.white,
    //                             fontWeight: FontWeight.bold),
    //                       ),
    //                     )),
    //               ),
    //             ),
    //             InkWell(onTap: (){
    //
    //
    //               widget.firestore.collection("fnd").add({"self":widget.auth.currentUser.uid,"fnd":fndID,"active":false});
    //
    //             },
    //               child: Padding(
    //                 padding: const EdgeInsets.all(8.0),
    //                 child: Card(
    //                     color: Colors.white,
    //                     child: Padding(
    //                       padding:
    //                       const EdgeInsets.fromLTRB(10, 5, 10, 5),
    //                       child: Text(
    //                         "Don't add to Contact",
    //                         style: TextStyle(
    //                             color: Colors.redAccent,
    //                             fontWeight: FontWeight.bold),
    //                       ),
    //                     )),
    //               ),
    //             )
    //           ],
    //         ),
    //       ))
    //       : Container(
    //     width: 0,
    //     height: 0,
    //   );
  }

  getString() {}

  void initSignaling() async {
    Timer.periodic(Duration(milliseconds: 500), (timer) {
      if (mounted) {
        AppSignal()
            .initSignal()
            .emit('setOnline', {"userId": widget.auth.currentUser.uid});
      }
    });

    AppSignal().initSignal().on("online", (data) {
      print("online users");
      // print(data.toString());
      onlineUser[data] = DateTime.now().millisecondsSinceEpoch;
      //print(onlineUser);
    });

    AppSignal().initSignal().on(widget.auth.currentUser.uid, (data) {
      print("you have data income");
    });

    // Timer.periodic(Duration(milliseconds: 10000), (timer) {
    //   if (mounted) {
    //     onlineUser.clear();
    //   } else {
    //     timer.cancel();
    //   }
    // });

    // socket2.on('getOnline', (data) {
    //   List all = [];
    //  // all = jsonDecode(data.toString());
    //  // print(data);
    //   all.clear();
    //   jsonDecode(data.toString()).asMap().forEach((i, value) {
    //     print('index=$i, value=$value');
    //     all.add(value);
    //   });
    //   print(all.length.toString());
    // });
  }

  void callReceiveSignal() {
    try {
      AppSignal().initSignal().on("callincome" + widget.auth.currentUser.uid,
          (data) {
        showIncome(data);
        print("call income hit");
        print(data);
        AppSignal()
            .initSignal()
            .emit("ringing", {"id": widget.auth.currentUser.uid});





      });
    } catch (e) {}
    // Timer.periodic(Duration(milliseconds: 1000), (timer) {
    //   if (mounted) {
    //     if(lastSeenTime+3000>DateTime.now().millisecondsSinceEpoch){
    //
    //     }else{
    //       widget.shouldShowIncomming = false ;
    //
    //     }
    //     StopRing();
    //
    //   }else{
    //     timer.cancel();
    //   }
    // });
  }

  void sendMessage(String val, String type, String name) async {
    print("sent " + type);
    String room = createRoomName(
        widget.auth.currentUser.uid,
        widget.chatBody["sender"] != null
            ? (widget.chatBody["sender"] == widget.auth.currentUser.uid
                ? widget.chatBody["receiver"]
                : widget.chatBody["sender"])
            : widget.chatBody["uid"]);

    await widget.firestore.collection("last").doc(room).set({
      "message": val,
      "type": type,
      "fname": name,
      "sender": widget.auth.currentUser.uid,
      "receiver": widget.chatBody["sender"] != null
          ? (widget.chatBody["sender"] == widget.auth.currentUser.uid
              ? widget.chatBody["receiver"]
              : widget.chatBody["sender"])
          : widget.chatBody["uid"]
    });

    await widget.firestore.collection(room).add({
      "time": DateTime.now().millisecondsSinceEpoch,
      "message": val,
      "type": type,
      "fname": name,
      "sender": widget.auth.currentUser.uid,
      "receiver": widget.chatBody["sender"] != null
          ? (widget.chatBody["sender"] == widget.auth.currentUser.uid
              ? widget.chatBody["receiver"]
              : widget.chatBody["sender"])
          : widget.chatBody["uid"]
    });
  }

  void sendMessageGroup(
      String val, String type, String name, String groupID) async {
    print("sent " + type);

    await widget.firestore
        .collection("groupChats")
        .doc(groupID)
        .collection("chats")
        .add({
      "time": DateTime.now().millisecondsSinceEpoch,
      "message": val,
      "type": type,
      "fname": name,
      "sender": widget.auth.currentUser.uid,
    });
  }

  void showIncome(dynamic data) {
    //  int lastSeenTime = DateTime.now().millisecondsSinceEpoch;

    if(this.mounted){
      AppSignal().initSignal().on("callCanceled" +data["callerId"], (data) {
        print("callended on other side");

        setState(() {

          widget.shouldShowIncomming = false;
        });
        StopRing();




      });
    }

    if (this.mounted) {
      setState(() {
        // Your state change code goes here
        playLocal();
        setState(() {
          playLocal();
          widget.shouldShowIncomming = true;
          widget.partnerName =
              data["callerName"] != null ? data["callerName"] : "No Name";
          //widget.partnerName ="caller" ;
          widget.partnerId = data["callerId"];
          //  lastSeenTime =  DateTime.now().millisecondsSinceEpoch;
          // widget.partnerId = "id" ;
        });
      });
    } else {
      print("income dialog stopped ");
    }
  }

  getSmallTab() {
    if (widget.selectedTabMenu == 0) {
      return LastChatHistoryWidget(
        widgetparent: widget,
        callback: doSomething,
        firestore: widget.firestore,
        firebaseAuth: widget.auth,
      );
    } else if (widget.selectedTabMenu == 1) {
      return StreamBuilder<QuerySnapshot>(
          stream: widget.firestore
              .collection("fnd")
              .where("self", isEqualTo: widget.auth.currentUser.uid)
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasData &&
                snapshot.data.size > 0 &&
                snapshot.data.docs.length > 0) {
              return ListView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data.docs.length,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    child: new InkWell(
                      onTap: () async {
                        setState(() {
                          widget.chatBody = {
                            "uid": snapshot.data.docs[index]["fnd"]
                          };
                        });

                        if (widget.showMobileView) {
                          setState(() {
                            widget.mobileViewLevel = 2;

                          });
                        }
                        startChatBodyViewCreate();
                      },
                      child: ListTile(
                        tileColor: Color.fromARGB(255, 249, 252, 255),
                        leading: prePareUserPhotoOld(
                            snapshot.data.docs[index]["fnd"]),
                        title: getNameFromIdR(snapshot.data.docs[index]["fnd"],
                            false, widget.firestore, widget.auth),
                        subtitle: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text("Send Message"),
                        ),
                      ),
                    ),
                  );
                },
              );

              return Center(
                  child: Text(
                      "Total fnd " + snapshot.data.docs.length.toString()));
            } else {
              return Center(child: Text("No Contacts"));
            }
          });
    } else if (widget.selectedTabMenu == 2) {
      return Column(
        children: [
          InkWell(
            child: ListTile(
              onTap: () {
                final SimpleDialog dialog1 = SimpleDialog(
                  title: Text('Add Participents'),
                  children: [
                    Container(
                      height: 400,
                      child: StreamBuilder<QuerySnapshot>(
                          stream: widget.firestore
                              .collection("fnd")
                              .where("self",
                                  isEqualTo: widget.auth.currentUser.uid)
                              .snapshots(),
                          builder: (BuildContext context,
                              AsyncSnapshot<QuerySnapshot> snapshot) {
                            if (snapshot.hasData &&
                                snapshot.data.size > 0 &&
                                snapshot.data.docs.length > 0) {
                              return SizedBox(
                                height: 400,
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: snapshot.data.docs.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return ListTile(
                                      onTap: () {
                                        setState(() {});
                                      },
                                      tileColor:
                                          Color.fromARGB(255, 249, 252, 255),
                                      leading: prePareUserPhotoOld(
                                          snapshot.data.docs[index]["fnd"]),
                                      title: getNameFromIdR(
                                          snapshot.data.docs[index]["fnd"],
                                          false,
                                          widget.firestore,
                                          widget.auth),
                                      subtitle: Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Text("Add"),
                                      ),
                                    );
                                  },
                                ),
                              );

                              return Center(
                                  child: Text("Total fnd " +
                                      snapshot.data.docs.length.toString()));
                            } else {
                              return Center(child: Text("No Contacts"));
                            }
                          }),
                    )
                  ],
                );

                done(List list) {
                  print("returned " + list.length.toString());
                  Navigator.pop(context);
                  grpCreated(String name) {
                    //create group
                    List ids = [];
                    ids.add(widget.auth.currentUser.uid);
                    for (int i = 0; i < list.length; i++) {
                      ids.add(list[i]["fnd"]);
                    }

                    widget.firestore.collection("groupChats").add({
                      "admin": widget.auth.currentUser.uid,
                      "name": name,
                      "users": ids
                    }).then((value) {
                      Navigator.pop(context);
                    });
                  }

                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (BuildContext context) => NameOfTheNewGrpChat(
                        Auth: widget.auth,
                        firestore: widget.firestore,
                        grpCreated: grpCreated,
                      ),
                      fullscreenDialog: true,
                    ),
                  );
                }

                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (BuildContext context) => ParticipentChooseForGrp(
                      auth: widget.auth,
                      firestore: widget.firestore,
                      callback: done,
                    ),
                    fullscreenDialog: true,
                  ),
                );
              },
              leading: Icon(
                Icons.group_add,
                color: Theme.of(context).primaryColor,
              ),
              title: Text("New Group"),
            ),
          ),
          StreamBuilder<QuerySnapshot>(
              stream: widget.firestore
                  .collection("groupChats")
                  .where("users", arrayContains: widget.auth.currentUser.uid)
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> groupChatSnaps) {
                if (groupChatSnaps.hasData &&
                    groupChatSnaps.data.size > 0 &&
                    groupChatSnaps.data.docs.length > 0) {
                  return ListView.builder(
                      shrinkWrap: true,
                      itemCount: groupChatSnaps.data.docs.length,
                      itemBuilder: (BuildContext context, int index) {
                        return ListTile(
                          onTap: () {
                            setState(() {
// groupChatSnaps.data.docs
                              widget.chatBodyWidget = GroupChatThread(
                                widgetHome: widget,
                                firestore: widget.firestore,
                                auth: widget.auth,
                                documentSnapshot:
                                    groupChatSnaps.data.docs[index],
                              );
                            });
                          },
                          leading: Icon(Icons.group),
                          title: Text(
                              groupChatSnaps.data.docs[index].data()["name"]),
                          subtitle: Text(groupChatSnaps.data.docs[index]
                                  .data()["users"]
                                  .length
                                  .toString() +
                              " users"),
                        );
                      });
                } else {
                  return Center(child: Text("No Groups"));
                }
              }),
        ],
      );
    }
  }

  void startChatBodyViewCreate() {
    setState(() {
      if (widget.chatBody == null) {
        widget.chatBodyWidget = Center(
            child: Image.asset(
          "assets/background.png",
          fit: BoxFit.cover,
        ));
      } else {
        call(dynamic data) {
          print(data);
          try{
            initCallIntent("v", widget.auth.currentUser.uid, data, true, widget.firestore, context);
          }catch(e){
            print(e.toString());

          }
        }

        widget.chatBodyWidget = Container(width: MediaQuery.of(context).size.width,
          child: SingleChatThread(homeWidget: widget,
            chatBody: widget.chatBody,
            auth: widget.auth,
            firestore: widget.firestore,
            call: call,
          ),
        );
      }
      // widget.chatBodyWidget = Stack(
      //   children: [
      //     widget.chatBody == null
      //         ? Center(
      //             child: Image.asset(
      //             "assets/background.png",
      //             fit: BoxFit.cover,
      //           ))
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //     widget.chatBody != null
      //         ? Positioned(
      //             top: 70,
      //             child: Container(
      //               color: Colors.grey,
      //               height: 0.5,
      //               width: MediaQuery.of(context).size.width,
      //             ))
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //     widget.chatBody != null
      //         ? Container(
      //             height: 70,
      //             //  color:   Color.fromARGB(255,238, 246, 255),
      //             child: Center(
      //                 child: Stack(
      //               children: [
      //                 Visibility(
      //                     visible: widget.showMobileView,
      //                     child: Align(
      //                       alignment: Alignment.centerLeft,
      //                       child: InkWell(
      //                         onTap: () {
      //                           setState(() {
      //                             widget.mobileViewLevel = 1;
      //                           });
      //                         },
      //                         child: Padding(
      //                           padding: const EdgeInsets.all(10.0),
      //                           child: Icon(Icons.chevron_left),
      //                         ),
      //                       ),
      //                     )),
      //                 Positioned(
      //                     left: widget.showMobileView ? 50 : 0,
      //                     top: 0,
      //                     bottom: 0,
      //                     child: Container(
      //                       width: 300,
      //                       child: Padding(
      //                         padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
      //                         child: Column(
      //                           mainAxisAlignment: MainAxisAlignment.center,
      //                           crossAxisAlignment: CrossAxisAlignment.start,
      //                           children: [
      //                             widget.chatBody["name"] != null
      //                                 ? Text(
      //                                     widget.chatBody["name"] == null
      //                                         ? "No user Name"
      //                                         : widget.chatBody["name"],
      //                                     style: TextStyle(
      //                                         fontWeight: FontWeight.bold,
      //                                         color: Colors.black,
      //                                         fontSize: 20),
      //                                   )
      //                                 : getNameFromId(widget.chatBody, true,
      //                                     widget.firestore, widget.auth),
      //                             widget.chatBody["email"] != null
      //                                 ? Text(widget.chatBody["email"])
      //                                 : getEmailFromId(widget.chatBody),
      //                           ],
      //                         ),
      //                       ),
      //                     )),
      //                 Align(
      //                   alignment: Alignment.centerRight,
      //                   child: Padding(
      //                     padding: const EdgeInsets.all(5.0),
      //                     child: Container(
      //                       width: 50,
      //                       child: InkWell(
      //                         onTap: () async {
      //                           String partnerID;
      //                           if (widget.chatBody["uid"] != null) {
      //                             partnerID = widget.chatBody["uid"];
      //                             initCallIntent(
      //                                 "v",
      //                                 widget.auth.currentUser.uid,
      //                                 partnerID,
      //                                 true,
      //                                 widget.firestore,
      //                                 context);
      //                           } else {
      //                             if (widget.chatBody["sender"] ==
      //                                 widget.auth.currentUser.uid) {
      //                               partnerID = widget.chatBody["receiver"];
      //                             } else {
      //                               partnerID = widget.chatBody["sender"];
      //                             }
      //                             initCallIntent(
      //                                 "v",
      //                                 widget.auth.currentUser.uid,
      //                                 partnerID,
      //                                 true,
      //                                 widget.firestore,
      //                                 context);
      //                           }
      //                         },
      //                         child: Container(
      //                           height: 50,
      //                           width: 50,
      //                           child: Card(
      //                             elevation: 0,
      //                             shape: RoundedRectangleBorder(
      //                               borderRadius: BorderRadius.circular(35.0),
      //                             ),
      //                             color: Color.fromARGB(255, 241, 241, 241),
      //                             child: Icon(Icons.call_outlined),
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                   ),
      //                 )
      //               ],
      //             )),
      //           )
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //     widget.chatBody != null
      //         ? Positioned(
      //             top: 75,
      //             left: 0,
      //             right: 0,
      //             bottom: 70,
      //             child: StreamBuilder<QuerySnapshot>(
      //                 stream: widget.firestore
      //                     .collection(createRoomName(
      //                         widget.auth.currentUser.uid,
      //                         widget.chatBody["sender"] != null
      //                             ? (widget.chatBody["sender"] ==
      //                                     widget.auth.currentUser.uid
      //                                 ? widget.chatBody["receiver"]
      //                                 : widget.chatBody["sender"])
      //                             : widget.chatBody["uid"]))
      //                     .orderBy("time")
      //                     .snapshots(),
      //                 builder: (BuildContext c,
      //                     AsyncSnapshot<QuerySnapshot> snapshot) {
      //                   if (snapshot.hasData && snapshot.data.size > 0) {
      //                     return Padding(
      //                       padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
      //                       child: ListView.builder(
      //                           // controller: scrollController,
      //                           shrinkWrap: true,
      //                           itemCount: snapshot.data == null
      //                               ? 0
      //                               : snapshot.data.size,
      //                           itemBuilder: (BuildContext context, int index) {
      //                             return Padding(
      //                               padding: const EdgeInsets.all(8.0),
      //                               child: Stack(
      //                                 children: [
      //                                   Align(
      //                                     alignment: snapshot.data.docs[index]
      //                                                 .data()["sender"] ==
      //                                             widget.auth.currentUser.uid
      //                                         ? Alignment.centerRight
      //                                         : Alignment.centerLeft,
      //                                     child: Padding(
      //                                       padding: const EdgeInsets.all(0.0),
      //                                       child: snapshot.data.docs[index]
      //                                                   .data()["sender"] ==
      //                                               widget.auth.currentUser.uid
      //                                           ? Column(
      //                                               mainAxisAlignment:
      //                                                   MainAxisAlignment
      //                                                       .center,
      //                                               crossAxisAlignment: snapshot
      //                                                               .data
      //                                                               .docs[index]
      //                                                               .data()[
      //                                                           "sender"] ==
      //                                                       widget.auth
      //                                                           .currentUser.uid
      //                                                   ? CrossAxisAlignment.end
      //                                                   : CrossAxisAlignment
      //                                                       .start,
      //                                               children: [
      //                                                 Padding(
      //                                                   padding:
      //                                                       const EdgeInsets
      //                                                               .fromLTRB(
      //                                                           0, 0, 5, 0),
      //                                                   child: Text(
      //                                                     DateFormat('hh:mm aa')
      //                                                         .format(DateTime
      //                                                             .fromMillisecondsSinceEpoch(snapshot
      //                                                                     .data
      //                                                                     .docs[
      //                                                                         index]
      //                                                                     .data()[
      //                                                                 "time"])),
      //                                                     style: TextStyle(
      //                                                         fontSize: 12),
      //                                                   ),
      //                                                 ),
      //                                                 Card(
      //                                                   color: snapshot.data
      //                                                                   .docs[index]
      //                                                                   .data()[
      //                                                               "sender"] ==
      //                                                           widget
      //                                                               .auth
      //                                                               .currentUser
      //                                                               .uid
      //                                                       ? Colors.white
      //                                                       : Color.fromARGB(
      //                                                           255,
      //                                                           238,
      //                                                           246,
      //                                                           255),
      //                                                   child: Container(
      //                                                       child: Padding(
      //                                                     padding:
      //                                                         const EdgeInsets
      //                                                             .all(8.0),
      //                                                     child:
      //                                                         makeChatMessageHead1(
      //                                                             context,
      //                                                             snapshot
      //                                                                 .data
      //                                                                 .docs[
      //                                                                     index]
      //                                                                 .data()),
      //                                                   )),
      //                                                 ),
      //                                               ],
      //                                             )
      //                                           : Row(
      //                                               mainAxisAlignment:
      //                                                   MainAxisAlignment.start,
      //                                               crossAxisAlignment:
      //                                                   CrossAxisAlignment
      //                                                       .start,
      //                                               children: [
      //                                                 widget.chatBody["img"] ==
      //                                                         null
      //                                                     ? CircleAvatar(
      //                                                         radius: 10,
      //                                                       )
      //                                                     : CircleAvatar(
      //                                                         radius: 10,
      //                                                         backgroundImage:
      //                                                             NetworkImage(
      //                                                                 widget.chatBody[
      //                                                                     "img"]),
      //                                                       ),
      //                                                 Column(
      //                                                   mainAxisAlignment:
      //                                                       MainAxisAlignment
      //                                                           .center,
      //                                                   crossAxisAlignment: snapshot
      //                                                                   .data
      //                                                                   .docs[index]
      //                                                                   .data()[
      //                                                               "sender"] ==
      //                                                           widget
      //                                                               .auth
      //                                                               .currentUser
      //                                                               .uid
      //                                                       ? CrossAxisAlignment
      //                                                           .end
      //                                                       : CrossAxisAlignment
      //                                                           .start,
      //                                                   children: [
      //                                                     Padding(
      //                                                       padding:
      //                                                           const EdgeInsets
      //                                                                   .fromLTRB(
      //                                                               5, 0, 0, 0),
      //                                                       child: Text(
      //                                                         DateFormat(
      //                                                                 'hh:mm aa')
      //                                                             .format(DateTime.fromMillisecondsSinceEpoch(snapshot
      //                                                                     .data
      //                                                                     .docs[
      //                                                                         index]
      //                                                                     .data()[
      //                                                                 "time"])),
      //                                                         style: TextStyle(
      //                                                             fontSize: 12),
      //                                                       ),
      //                                                     ),
      //                                                     Card(
      //                                                       color: snapshot
      //                                                                       .data
      //                                                                       .docs[
      //                                                                           index]
      //                                                                       .data()[
      //                                                                   "sender"] ==
      //                                                               widget
      //                                                                   .auth
      //                                                                   .currentUser
      //                                                                   .uid
      //                                                           ? Colors.white
      //                                                           : Color
      //                                                               .fromARGB(
      //                                                                   255,
      //                                                                   238,
      //                                                                   246,
      //                                                                   255),
      //                                                       child: Container(
      //                                                           child: Padding(
      //                                                         padding:
      //                                                             const EdgeInsets
      //                                                                 .all(8.0),
      //                                                         child: makeChatMessageHead1(
      //                                                             context,
      //                                                             snapshot
      //                                                                 .data
      //                                                                 .docs[
      //                                                                     index]
      //                                                                 .data()),
      //                                                       )),
      //                                                     ),
      //                                                   ],
      //                                                 ),
      //                                               ],
      //                                             ),
      //                                     ),
      //                                   )
      //                                 ],
      //                               ),
      //                             );
      //                           }),
      //                     );
      //                   } else {
      //                     return Center(
      //                       child: Text("Send your first message"),
      //                     );
      //                   }
      //                 }))
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //
      //     //
      //     // widget.chatBody!=null? Align(
      //     //   alignment: Alignment.bottomCenter,
      //     //   child: Wrap(children: [
      //     //     Container(height: 60,
      //     //       child: Stack(
      //     //         children: [
      //     //           Positioned(
      //     //             bottom: 10,
      //     //             left: 10,
      //     //             right: 130,
      //     //             child: Container(
      //     //               height: 60,
      //     //               child: Center(
      //     //                 child: Card(
      //     //                   elevation: 0,
      //     //                   color: Color.fromARGB(255, 238, 246, 255),
      //     //                   child: Container(
      //     //                     child: new TextField(
      //     //                       onSubmitted: (val) async {
      //     //                         sendMessage(val, "txt", "-");
      //     //
      //     //                         controller.clear();
      //     //                       },
      //     //                       controller: controller,
      //     //                       textAlign: TextAlign.left,
      //     //                       decoration: new InputDecoration(
      //     //                         hintText: "Type your message",
      //     //                         contentPadding: EdgeInsets.all(10),
      //     //                         border: InputBorder.none,
      //     //                       ),
      //     //                     ),
      //     //                   ),
      //     //                 ),
      //     //               ),
      //     //             ),
      //     //           ),
      //     //           Positioned(
      //     //             bottom: 10,
      //     //             right: 10,
      //     //             child: Container(
      //     //               height: 60,
      //     //               child: Row(
      //     //                 mainAxisAlignment: MainAxisAlignment.center,
      //     //                 crossAxisAlignment: CrossAxisAlignment.center,
      //     //                 children: [
      //     //                   Center(
      //     //                     child: new InkWell(
      //     //                       onTap: () async {
      //     //                         //widget.room
      //     //                         FilePickerResult result =
      //     //                         await FilePicker.platform
      //     //                             .pickFiles();
      //     //
      //     //                         if (result != null) {
      //     //                           PlatformFile file =
      //     //                               result.files.first;
      //     //
      //     //                           print(file.name);
      //     //                           // print(file.bytes);
      //     //                           // _base64 = BASE64.encode(response.bodyBytes);
      //     //                           String base =
      //     //                           base64.encode(file.bytes);
      //     //
      //     //                           String url =
      //     //                               "https://talk.maulaji.com/uploadfilemessenger.php";
      //     //
      //     //                           print(file.size);
      //     //                           print(file.extension);
      //     //                           print(file.path);
      //     //                           //print("base");
      //     //                           // print(base);
      //     //
      //     //                           var response = await http.post(
      //     //                               Uri.parse(url),
      //     //                               body: jsonEncode({
      //     //                                 'name': file.name,
      //     //                                 'file': base,
      //     //                                 'ex': file.extension
      //     //                               }));
      //     //                           print(
      //     //                               'Response status: ${response.statusCode}');
      //     //                           print(response.body);
      //     //                           dynamic res =
      //     //                           jsonDecode(response.body);
      //     //                           if (res["status"]) {
      //     //                             sendMessage(res["path"],
      //     //                                 file.extension, file.name);
      //     //                           } else {
      //     //                             print("could not save");
      //     //                           }
      //     //                         } else {
      //     //                           // User canceled the picker
      //     //                         }
      //     //                       },
      //     //                       child: Padding(
      //     //                         padding: const EdgeInsets.all(8.0),
      //     //                         child: Icon(
      //     //                           Icons.attach_file,
      //     //                           color:
      //     //                           Theme.of(context).primaryColor,
      //     //                         ),
      //     //                       ),
      //     //                     ),
      //     //                   ),
      //     //                   Center(
      //     //                     child: new InkWell(
      //     //                       onTap: () async {
      //     //                         //widget.room
      //     //                         setState(() {
      //     //                           widget.showEmojiList = ! widget.showEmojiList;
      //     //                         });
      //     //                         print("emoji "+ widget.showEmojiList.toString());
      //     //                       },
      //     //                       child: Padding(
      //     //                         padding: const EdgeInsets.all(8.0),
      //     //                         child: Icon(
      //     //                           Icons.emoji_emotions,
      //     //                           color:
      //     //                           Theme.of(context).primaryColor,
      //     //                         ),
      //     //                       ),
      //     //                     ),
      //     //                   ),
      //     //                   Center(
      //     //                     child: new InkWell(
      //     //                       onTap: () async {
      //     //                         //widget.room
      //     //                         String text = controller.text;
      //     //                         if (text.length > 0) {
      //     //                           String room = createRoomName(
      //     //                               widget.auth.currentUser.uid,
      //     //                               widget.chatBody["sender"] !=
      //     //                                   null
      //     //                                   ? (widget.chatBody[
      //     //                               "sender"] ==
      //     //                                   widget.auth
      //     //                                       .currentUser.uid
      //     //                                   ? widget.chatBody[
      //     //                               "receiver"]
      //     //                                   : widget
      //     //                                   .chatBody["sender"])
      //     //                                   : widget.chatBody["uid"]);
      //     //
      //     //                           await widget.firestore
      //     //                               .collection("last")
      //     //                               .doc(room)
      //     //                               .set({
      //     //                             "message": text,
      //     //                             "sender":
      //     //                             widget.auth.currentUser.uid,
      //     //                             "receiver": widget
      //     //                                 .chatBody["sender"] !=
      //     //                                 null
      //     //                                 ? (widget.chatBody[
      //     //                             "sender"] ==
      //     //                                 widget.auth
      //     //                                     .currentUser.uid
      //     //                                 ? widget
      //     //                                 .chatBody["receiver"]
      //     //                                 : widget
      //     //                                 .chatBody["sender"])
      //     //                                 : widget.chatBody["uid"]
      //     //                           });
      //     //
      //     //                           await widget.firestore
      //     //                               .collection(room)
      //     //                               .add({
      //     //                             "time": DateTime.now()
      //     //                                 .millisecondsSinceEpoch,
      //     //                             "message": text,
      //     //                             "sender":
      //     //                             widget.auth.currentUser.uid,
      //     //                             "receiver": widget
      //     //                                 .chatBody["sender"] !=
      //     //                                 null
      //     //                                 ? (widget.chatBody[
      //     //                             "sender"] ==
      //     //                                 widget.auth
      //     //                                     .currentUser.uid
      //     //                                 ? widget
      //     //                                 .chatBody["receiver"]
      //     //                                 : widget
      //     //                                 .chatBody["sender"])
      //     //                                 : widget.chatBody["uid"]
      //     //                           });
      //     //                           controller.clear();
      //     //                         }
      //     //                       },
      //     //                       child: Padding(
      //     //                         padding: const EdgeInsets.all(8.0),
      //     //                         child: Icon(
      //     //                           Icons.send,
      //     //                           color: Colors.blue,
      //     //                         ),
      //     //                       ),
      //     //                     ),
      //     //                   ),
      //     //                 ],
      //     //               ),
      //     //             ),
      //     //           ),
      //     //         ],
      //     //       ),
      //     //     ),
      //     //     widget.showEmojiList? Container(height: 300,
      //     //       // width: 500,
      //     //       child: GridView.builder(
      //     //         itemCount:Emoji.all().length,
      //     //         gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      //     //             crossAxisCount:widget.showMobileView?7:15),
      //     //         itemBuilder: (BuildContext context, int index) {
      //     //           return InkWell(onTap: (){
      //     //             controller.text = controller.text+Emoji.all()[index].char;
      //     //           },child: Center(child: new Text(Emoji.all()[index].char)));
      //     //         },
      //     //       ),
      //     //     ):Container(width: 0,height: 0,)
      //     //
      //     //   ],),
      //     // ):Container(width: 0,height: 0,),
      //     widget.chatBody != null
      //         ? Align(
      //             alignment: Alignment.bottomCenter,
      //             child: Wrap(
      //               children: [
      //                 Container(
      //                   height: 60,
      //                   child: Stack(
      //                     children: [
      //                       Positioned(
      //                         bottom: 10,
      //                         left: 10,
      //                         right: 130,
      //                         child: Container(
      //                           height: 60,
      //                           child: Center(
      //                             child: Card(
      //                               elevation: 0,
      //                               color: Color.fromARGB(255, 238, 246, 255),
      //                               child: Container(
      //                                 child: new TextField(
      //                                   onSubmitted: (val) async {
      //                                     sendMessage(val, "txt", "-");
      //
      //                                     controller.clear();
      //                                   },
      //                                   controller: controller,
      //                                   textAlign: TextAlign.left,
      //                                   decoration: new InputDecoration(
      //                                     hintText: "Type your message",
      //                                     contentPadding: EdgeInsets.all(10),
      //                                     border: InputBorder.none,
      //                                   ),
      //                                 ),
      //                               ),
      //                             ),
      //                           ),
      //                         ),
      //                       ),
      //                       Positioned(
      //                         bottom: 10,
      //                         right: 10,
      //                         child: Container(
      //                           height: 60,
      //                           child: Row(
      //                             mainAxisAlignment: MainAxisAlignment.center,
      //                             crossAxisAlignment: CrossAxisAlignment.center,
      //                             children: [
      //                               Center(
      //                                 child: new InkWell(
      //                                   onTap: () async {
      //                                     //widget.room
      //                                     FilePickerResult result =
      //                                         await FilePicker.platform
      //                                             .pickFiles();
      //
      //                                     if (result != null) {
      //                                       PlatformFile file =
      //                                           result.files.first;
      //
      //                                       print(file.name);
      //                                       // print(file.bytes);
      //                                       // _base64 = BASE64.encode(response.bodyBytes);
      //                                       String base =
      //                                           base64.encode(file.bytes);
      //
      //                                       String url =
      //                                           "https://talk.maulaji.com/uploadfilemessenger.php";
      //
      //                                       print(file.size);
      //                                       print(file.extension);
      //                                       print(file.path);
      //                                       //print("base");
      //                                       // print(base);
      //
      //                                       var response = await http.post(
      //                                           Uri.parse(url),
      //                                           body: jsonEncode({
      //                                             'name': file.name,
      //                                             'file': base,
      //                                             'ex': file.extension
      //                                           }));
      //                                       print(
      //                                           'Response status: ${response.statusCode}');
      //                                       print(response.body);
      //                                       dynamic res =
      //                                           jsonDecode(response.body);
      //                                       if (res["status"]) {
      //                                         sendMessage(res["path"],
      //                                             file.extension, file.name);
      //                                       } else {
      //                                         print("could not save");
      //                                       }
      //                                     } else {
      //                                       // User canceled the picker
      //                                     }
      //                                   },
      //                                   child: Padding(
      //                                     padding: const EdgeInsets.all(8.0),
      //                                     child: Icon(
      //                                       Icons.attach_file,
      //                                       color:
      //                                           Theme.of(context).primaryColor,
      //                                     ),
      //                                   ),
      //                                 ),
      //                               ),
      //                               Center(
      //                                 child: new InkWell(
      //                                   onTap: () async {
      //                                     //widget.room
      //                                     setState(() {
      //                                       widget.showEmojiListSingle =
      //                                           !widget.showEmojiListSingle;
      //                                     });
      //                                     print("emoji " +
      //                                         widget.showEmojiListSingle
      //                                             .toString());
      //                                   },
      //                                   child: Padding(
      //                                     padding: const EdgeInsets.all(8.0),
      //                                     child: Icon(
      //                                       Icons.emoji_emotions,
      //                                       color:
      //                                           Theme.of(context).primaryColor,
      //                                     ),
      //                                   ),
      //                                 ),
      //                               ),
      //                               Center(
      //                                 child: new InkWell(
      //                                   onTap: () async {
      //                                     //widget.room
      //                                     String text = controller.text;
      //                                     if (text.length > 0) {
      //                                       String room = createRoomName(
      //                                           widget.auth.currentUser.uid,
      //                                           widget.chatBody["sender"] !=
      //                                                   null
      //                                               ? (widget.chatBody[
      //                                                           "sender"] ==
      //                                                       widget.auth
      //                                                           .currentUser.uid
      //                                                   ? widget.chatBody[
      //                                                       "receiver"]
      //                                                   : widget
      //                                                       .chatBody["sender"])
      //                                               : widget.chatBody["uid"]);
      //
      //                                       await widget.firestore
      //                                           .collection("last")
      //                                           .doc(room)
      //                                           .set({
      //                                         "message": text,
      //                                         "sender":
      //                                             widget.auth.currentUser.uid,
      //                                         "receiver": widget
      //                                                     .chatBody["sender"] !=
      //                                                 null
      //                                             ? (widget.chatBody[
      //                                                         "sender"] ==
      //                                                     widget.auth
      //                                                         .currentUser.uid
      //                                                 ? widget
      //                                                     .chatBody["receiver"]
      //                                                 : widget
      //                                                     .chatBody["sender"])
      //                                             : widget.chatBody["uid"]
      //                                       });
      //
      //                                       await widget.firestore
      //                                           .collection(room)
      //                                           .add({
      //                                         "time": DateTime.now()
      //                                             .millisecondsSinceEpoch,
      //                                         "message": text,
      //                                         "sender":
      //                                             widget.auth.currentUser.uid,
      //                                         "receiver": widget
      //                                                     .chatBody["sender"] !=
      //                                                 null
      //                                             ? (widget.chatBody[
      //                                                         "sender"] ==
      //                                                     widget.auth
      //                                                         .currentUser.uid
      //                                                 ? widget
      //                                                     .chatBody["receiver"]
      //                                                 : widget
      //                                                     .chatBody["sender"])
      //                                             : widget.chatBody["uid"]
      //                                       });
      //                                       controller.clear();
      //                                     }
      //                                   },
      //                                   child: Padding(
      //                                     padding: const EdgeInsets.all(8.0),
      //                                     child: Icon(
      //                                       Icons.send,
      //                                       color: Colors.blue,
      //                                     ),
      //                                   ),
      //                                 ),
      //                               ),
      //                             ],
      //                           ),
      //                         ),
      //                       ),
      //                     ],
      //                   ),
      //                 ),
      //                 widget.showEmojiListSingle
      //                     ? Container(
      //                         height: 300,
      //                         // width: 500,
      //                         color: Colors.redAccent,
      //                       )
      //                     : Container(
      //                         width: 0,
      //                         height: 0,
      //                       )
      //               ],
      //             ),
      //           )
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //     widget.showProfileCompleteDialog
      //         ? Align(
      //             alignment: Alignment.center,
      //             child: Card(
      //               color: Color.fromARGB(255, 239, 247, 255),
      //               elevation: 20,
      //               child: Container(
      //                   width: 400,
      //                   height: 400,
      //                   child: ProfileUpdateDialog(
      //                     auth: widget.auth,
      //                     firestore: widget.firestore,
      //                     currentProfile: widget.currentProfile,
      //                   )),
      //             ),
      //           )
      //         : Container(
      //             width: 0,
      //             height: 0,
      //           ),
      //     showAddFndDialog(),
      //   ],
      // );
    });
  }

  Widget getListOfPeople(List users) {
    List<Widget> allnames = [];
    for (int i = 0; i < users.length; i++) {
      allnames.add(Padding(
        padding: const EdgeInsets.all(0.0),
        child: getNameFromIdR(users[i], false, widget.firestore, widget.auth),
      ));
      allnames.add(Text(", "));
    }
    return Row(
      children: allnames,
    );
  }
}

Widget getListOfPeople(List users) {
  List<Widget> allnames = [];
  for (int i = 0; i < users.length; i++) {
    allnames.add(Padding(
      padding: const EdgeInsets.all(0.0),
      child: getNameFromIdR(
          users[i], false, FirebaseFirestore.instance, FirebaseAuth.instance),
    ));
    allnames.add(Text(", "));
  }
  return Row(
    children: allnames,
  );
}

class LastChatHistoryWidget extends StatefulWidget {
  String selectedItemId;

  void Function(dynamic) callback;

  FirebaseFirestore firestore;
  FirebaseAuth firebaseAuth;

  List oneS = [];
  List oneR = [];
  List Sum = [];
  Home widgetparent;
  IO.Socket socket;

  // Widget returnWidget = Scaffold(body: Center(child: Text("Please wait"),),);
  Widget returnWidget = Padding(
    padding: EdgeInsets.all(50),
    child: CircularProgressIndicator(),
  );

  LastChatHistoryWidget(
      {this.widgetparent,
      this.firestore,
      this.firebaseAuth,
      this.callback,
      this.socket});

  @override
  _LastChatHistoryWidgetState createState() => _LastChatHistoryWidgetState();
}

class _LastChatHistoryWidgetState extends State<LastChatHistoryWidget> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer.periodic(Duration(milliseconds: 1000), (timer) {
      if (mounted) {
        widget.firestore
            .collection("last")
            .where("sender", isEqualTo: widget.firebaseAuth.currentUser.uid)
            .get()
            .then((value) {
          if (mounted) {
            setState(() {
              widget.oneS = value.docs;
              /* widget.Sum.clear();
                widget.Sum .addAll(widget.oneS);
                widget.Sum .addAll(widget.oneR);

                */
            });
          }

          widget.firestore
              .collection("last")
              .where("receiver", isEqualTo: widget.firebaseAuth.currentUser.uid)
              .get()
              .then((value) {
            if (mounted) {
              setState(() {
                widget.oneR = value.docs;
                widget.Sum.clear();
                widget.Sum.addAll(widget.oneS);
                widget.Sum.addAll(widget.oneR);
              });
              setState(() {
                widget.returnWidget = ListView.builder(
                    shrinkWrap: true,
                    itemCount: (widget.Sum == null || widget.Sum == null)
                        ? 0
                        : widget.Sum.length,
                    itemBuilder: (BuildContext context, int index) {
                      return ListTile(
                        tileColor: widget.selectedItemId != null &&
                                ((widget.selectedItemId ==
                                        widget.Sum[index].data()["receiver"]) |
                                    (widget.selectedItemId ==
                                        widget.Sum[index].data()["sender"]))
                            ? Color.fromARGB(255, 217, 236, 255)
                            : Color.fromARGB(255, 239, 247, 255),
                        onTap: () {
                          widget.callback(widget.Sum[index].data());
                          setState(() {
                            // widget.chatBody = filtereData[index];
                            widget.selectedItemId =
                                widget.Sum[index].data()["receiver"] ==
                                        widget.firebaseAuth.currentUser.uid
                                    ? widget.Sum[index].data()["sender"]
                                    : widget.Sum[index].data()["receiver"];
                          });

                          setState(() {
                            //  widget.widgetparent.chatBody =  widget.Sum[index];
                            widget.widgetparent.selectedItem = index;
                          });
                          if (widget.widgetparent.showMobileView) {
                            setState(() {
                              widget.widgetparent.mobileViewLevel = 2;

                            });
                          }
                        },
                        leading: prePareUserPhoto(
                            widget.firebaseAuth,
                            widget.Sum[index].data()["receiver"] ==
                                    widget.firebaseAuth.currentUser.uid
                                ? widget.Sum[index].data()["sender"]
                                : widget.Sum[index].data()["receiver"]),
                        title: getNameFromIdR(
                            widget.Sum[index].data()["receiver"] ==
                                    widget.firebaseAuth.currentUser.uid
                                ? widget.Sum[index].data()["sender"]
                                : widget.Sum[index].data()["receiver"],
                            false,
                            widget.firestore,
                            widget.firebaseAuth),
                        subtitle: Text(widget.Sum[index].data()["message"]),
                      );
                    });
              });
            }
          });
        });
      }
    });

/*

    widget.firestore
        .collection("last")
        .where("sender", isEqualTo: widget.firebaseAuth.currentUser.uid)
        .snapshots().listen((event) {
      if(event.size>0 && event.docs.length>0){


        widget.oneS = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);



        setState(() {


        widget.oneS = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);

        widget.returnWidget = ListView.builder(
            shrinkWrap: true,
            itemCount:
            (widget.Sum == null || widget.Sum == null)
                ? 0
                : widget.Sum.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(tileColor:  widget.selectedItemId!=null && ((widget.selectedItemId ==  widget.Sum[index].data()["receiver"]) |( widget.selectedItemId ==  widget.Sum[index].data()["sender"]))?Color.fromARGB(255, 217, 236, 255 ):Colors.white,onTap: (){
                setState(() {
                 // widget.chatBody = filtereData[index];
                  widget.selectedItemId =  widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"];
                });
              },leading: CircleAvatar(radius: 18,),title:getNameFromIdR( widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"] ,false,widget.firestore,widget.firebaseAuth) ,subtitle: Text(widget.Sum[index].data()["message"]),);

            });
        });

      }

    });
    widget.firestore
        .collection("last")
        .where("receiver", isEqualTo: widget.firebaseAuth.currentUser.uid)
        .snapshots().listen((event) {
      if(event.size>0 && event.docs.length>0){

        setState(() {


        widget.oneR = event.docs;
        widget.Sum.clear();
        widget.Sum .addAll(widget.oneS);
        widget.Sum .addAll(widget.oneR);

        widget.returnWidget =  ListView.builder(
            shrinkWrap: true,
            itemCount:
            (widget.Sum == null || widget.Sum == null)
                ? 0
                : widget.Sum.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(tileColor: widget.selectedItemId!=null && ((widget.selectedItemId ==  widget.Sum[index].data()["receiver"]) |( widget.selectedItemId ==  widget.Sum[index].data()["sender"]))?Color.fromARGB(255, 217, 236, 255 ):Colors.white,onTap: (){
                setState(() {
                 // widget.chatBody = filtereData[index];
                  widget.selectedItemId =  widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"];
                });
              },leading: CircleAvatar(radius: 18,),title:getNameFromIdR( widget.Sum[index].data()["receiver"]== widget.firebaseAuth.currentUser.uid? widget.Sum[index].data()["sender"]: widget.Sum[index].data()["receiver"] ,false,widget.firestore,widget.firebaseAuth) ,subtitle: Text(widget.Sum[index].data()["message"]),);

            });
        });
      }

    });
    */
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: widget.returnWidget,
    );
  }
}

prePareUserPhoto(FirebaseAuth auth, String uid) {
  Widget statusWIdget;

  if (onlineUser.containsKey(uid) &&
      onlineUser[uid] + 3000 > DateTime.now().millisecondsSinceEpoch) {
    statusWIdget = Container(
      width: 10,
      height: 10,
      decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.greenAccent),
    );
  } else {
    statusWIdget = Container(
      width: 10,
      height: 10,
      decoration:
          BoxDecoration(shape: BoxShape.circle, color: Colors.redAccent),
    );
  }

  return StreamBuilder<QuerySnapshot>(
    // Initialize FlutterFire:
    //  future: Firebase.initializeApp(),
      stream: FirebaseFirestore.instance.collection("users").where("uid",isEqualTo: uid).snapshots(),
      builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot) {

        if(snapshot.hasData && snapshot.data!=null){
          return Container(
            height: 40,
            width: 40,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.center,

                  child: snapshot.data.docs.first.data()["photo"]!=null?CircleAvatar(backgroundImage: NetworkImage("https://talk.maulaji.com/"+snapshot.data.docs.first.data()["photo"]),): Image.asset("assets/user_photo.jpg"),
                ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: const EdgeInsets.all(1.0),
                    child: statusWIdget,
                  ),
                )
              ],
            ),
          );
        }else return CircularProgressIndicator();
      });




}

Widget getNameFromIdWithStyle(String id, TextStyle style,
    FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore.collection("users").where("uid", isEqualTo: id).get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style,
          );
        } else {
          return Text("Please wait");
        }
      });
}

Widget getNameFromIdR(
    String id, bool style, FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore.collection("users").where("uid", isEqualTo: id).get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style
                ? TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20)
                : TextStyle(),
          );
        } else {
          return Text("Please wait");
        }
      });
}

class ProfileUpdateDialog extends StatefulWidget {
  dynamic currentProfile;

  FirebaseFirestore firestore;

  FirebaseAuth auth;

  ProfileUpdateDialog({this.currentProfile, this.auth, this.firestore});

  @override
  _ProfileUpdateDialogState createState() => _ProfileUpdateDialogState();
}

class _ProfileUpdateDialogState extends State<ProfileUpdateDialog> {
  TextEditingController textEditingControllerName = TextEditingController();
  TextEditingController textEditingControllerEmail = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    textEditingControllerName.text = widget.currentProfile["name"];
    textEditingControllerEmail.text = widget.currentProfile["email"];
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 400,
        height: 400,
        child: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                color: Colors.blue,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Profile Update",
                    style: TextStyle(
                        backgroundColor: Colors.blue,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 20, 8, 0),
                child: Text(
                  "Display Name",
                  style: TextStyle(
                      color: Colors.blue, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                child: TextField(
                  controller: textEditingControllerName,
                  decoration:
                      InputDecoration(contentPadding: EdgeInsets.all(10)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 20, 8, 0),
                child: Text(
                  "Email",
                  style: TextStyle(
                      color: Colors.blue, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                child: TextField(
                  controller: textEditingControllerEmail,
                  decoration:
                      InputDecoration(contentPadding: EdgeInsets.all(10)),
                ),
              ),
              InkWell(
                onTap: () {
                  widget.firestore
                      .collection("users")
                      .where("uid", isEqualTo: widget.auth.currentUser.uid)
                      .get()
                      .then((value) {
                    widget.firestore
                        .collection("users")
                        .doc(value.docs.first.id)
                        .update({
                      "email": textEditingControllerEmail.text,
                      "name": textEditingControllerName.text
                    });
                  });
                },
                child: Card(
                  elevation: 0,
                  color: Theme.of(context).primaryColor,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                          child: Text(
                        "Save",
                        style: TextStyle(color: Colors.white),
                      )),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

Widget getNameFromId(
    dynamic body, bool style, FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore
          .collection("users")
          .where("uid",
              isEqualTo: body["uid"] != null
                  ? body["uid"]
                  : (body["receiver"] == auth.currentUser.uid
                      ? body["sender"]
                      : body["receiver"]))
          .get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["name"],
            style: style
                ? TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20)
                : TextStyle(),
          );
        } else {
          return Text("Please wait");
        }
      });
}

class CreateRoomActivity extends StatefulWidget {
  FirebaseFirestore firestore;

  FirebaseAuth auth;

  CreateRoomActivity({this.firestore, this.auth});

  @override
  _CreateRoomActivityState createState() => _CreateRoomActivityState();
}

class _CreateRoomActivityState extends State<CreateRoomActivity> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: InkWell(
                onTap: () async {
                  QuerySnapshot q = await widget.firestore
                      .collection("users")
                      .where("uid", isEqualTo: widget.auth.currentUser.uid)
                      .get();

                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => WillPopScope(
                  //           onWillPop: () async => false,
                  //           child: Conf(
                  //             containsVideo:  false,
                  //             ownID: widget.auth.currentUser.uid,
                  //             isCaller: true,
                  //             firestore: widget.firestore,
                  //
                  //           ),
                  //         )));
                  // widget.firestore.collection("con").add({"created_by":widget.auth.currentUser.uid}).then((value) {
                  //
                  // });
                },
                child: Card(
                  color: Colors.blue,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Join Room as Presenter"),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: InkWell(
                onTap: () {
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => WillPopScope(
                  //               onWillPop: () async => false,
                  //               child: Conf(
                  //                 containsVideo: false,
                  //                 ownID: widget.auth.currentUser.uid,
                  //                 isCaller: false,
                  //                 firestore: widget.firestore,
                  //               ),
                  //             )));
                },
                child: Card(
                  color: Colors.blue,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Join Room as Audience"),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class ProfileUpdate extends StatefulWidget {
  FirebaseAuth auth;

  FirebaseFirestore firestore;

  ProfileUpdate({this.auth, this.firestore});

  @override
  _ProfileUpdateState createState() => _ProfileUpdateState();
}

class _ProfileUpdateState extends State<ProfileUpdate> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

class StreamSocket {
  final _socketResponse = StreamController<dynamic>();

  void Function(dynamic) get addResponse => _socketResponse.sink.add;

  Stream<dynamic> get getResponse => _socketResponse.stream;

  void dispose() {
    _socketResponse.close();
  }
}

class ParticipentChooseForGrp extends StatefulWidget {
  List downloaded = [];

  FirebaseFirestore firestore;
  FirebaseAuth auth;
  void Function(List) callback;

  ParticipentChooseForGrp({this.firestore, this.auth, this.callback});

  @override
  _ParticipentChooseForGrpState createState() =>
      _ParticipentChooseForGrpState();
}

class _ParticipentChooseForGrpState extends State<ParticipentChooseForGrp> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.firestore
        .collection("fnd")
        .where("self", isEqualTo: widget.auth.currentUser.uid)
        .get()
        .then((value) {
      if (value.size > 0 && value.docs.length > 0) {
        for (int i = 0; i < value.docs.length; i++) {
          setState(() {
            dynamic da = value.docs[i].data();
            da["selected"] = false;
            widget.downloaded.add(da);
          });
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          InkWell(
            onTap: () {
              List newList = [];
              for (int i = 0; i < widget.downloaded.length; i++) {
                if (widget.downloaded[i]["selected"] == true) {
                  newList.add(widget.downloaded[i]);
                }
              }
              widget.callback(newList);
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.done),
            ),
          )
        ],
        title: Text("Add participants"),
      ),
      body: widget.downloaded.length > 0
          ? ListView.builder(
              shrinkWrap: true,
              itemCount: widget.downloaded.length,
              itemBuilder: (BuildContext context, int index) {
                // return ListTile(leading:  prePareUserPhoto( widget.downloaded[index]
                // ["fnd"],FirebaseAuth.instance.currentUser.uid),title:  getNameFromIdR(
                //     widget.downloaded[index]["fnd"],
                //     false,
                //     widget.firestore,
                //     widget.auth),);
                return InkWell(
                  onTap: () {
                    setState(() {
                      widget.downloaded[index]["selected"] =
                          !widget.downloaded[index]["selected"];
                    });
                  },
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(10),
                              child: prePareUserPhoto(
                                  widget.auth, widget.downloaded[index]["fnd"]),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10),
                              child: getNameFromIdR(
                                  widget.downloaded[index]["fnd"],
                                  false,
                                  widget.firestore,
                                  widget.auth),
                            )
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Checkbox(
                            onChanged: (value) {
                              // setState(() {
                              //   widget.downloaded[index]["selected"] = value ;
                              // });
                            },
                            value: widget.downloaded[index]["selected"],
                          ),
                        ),
                      )
                    ],
                  ),
                );
                // return ListTile(trailing: Checkbox(value: true,),
                //   tileColor: Color.fromARGB(
                //       255, 249, 252, 255),
                //   leading: prePareUserPhoto(
                //       snapshot.data
                //           .docs[index]
                //       ["fnd"]),
                //   title: getNameFromIdR(
                //       snapshot.data
                //           .docs[index]["fnd"],
                //       false,
                //       widget.firestore,
                //       widget.auth),
                //   subtitle: Padding(
                //     padding:
                //     const EdgeInsets.all(
                //         5.0),
                //     child:
                //     Text("Add"),
                //   ),
                // );
              },
            )
          : Center(
              child: Text("No friends"),
            ),
    );
  }
}

class NameOfTheNewGrpChat extends StatefulWidget {
  FirebaseAuth Auth;
  FirebaseFirestore firestore;

  void Function(String) grpCreated;

  NameOfTheNewGrpChat({this.Auth, this.firestore, this.grpCreated});

  @override
  _NameOfTheNewGrpChatState createState() => _NameOfTheNewGrpChatState();
}

class _NameOfTheNewGrpChatState extends State<NameOfTheNewGrpChat> {
  TextEditingController controller = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Group Discription"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: controller,
              decoration: InputDecoration(
                labelText: 'Group Name',
                //errorText: 'Please give  a name',
                border: OutlineInputBorder(),
                suffixIcon: Icon(
                  Icons.title,
                ),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              widget.grpCreated(controller.text);
            },
            child: Padding(
              padding: EdgeInsets.fromLTRB(10, 20, 10, 10),
              child: Container(
                color: Theme.of(context).primaryColor,
                child: Center(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Create",
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                )),
              ),
            ),
          )
        ],
      ),
    );
  }
}

class SingleChatThread extends StatefulWidget {
  dynamic chatBody;
  FirebaseAuth auth;
  FirebaseFirestore firestore;
  void Function(dynamic) call;
  bool showEmojiListSingle = false;
  Home homeWidget;

  SingleChatThread({this.homeWidget,this.chatBody, this.auth, this.firestore, this.call});

  @override
  _SingleChatThreadState createState() => _SingleChatThreadState();
}

class _SingleChatThreadState extends State<SingleChatThread> {
  TextEditingController controller = new TextEditingController();
  ScrollController _scrollController = new ScrollController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    listenDisplayStatus();
  }

  @override
  Widget build(BuildContext context) {
    // return Text(widget.chatBody);

    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              top: 70,
              child: Container(
                color: Colors.grey,
                height: 0.5,
                width: MediaQuery.of(context).size.width,
              )),
          Container(
            height: 70,
              color:   Color.fromARGB(255,238, 246, 255),
            child: Center(
                child: Stack(
              children: [

                Positioned(
                    left: widget.homeWidget.showMobileView? 50:0,
                    top: 0,
                    bottom: 0,
                    child: Container(
                      width: 300,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            widget.chatBody["name"] != null
                                ? Text(
                                    widget.chatBody["name"] == null
                                        ? "No user Name"
                                        : widget.chatBody["name"],
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        fontSize: 20),
                                  )
                                : getNameFromId(widget.chatBody, true,
                                    widget.firestore, widget.auth),
                            widget.chatBody["email"] != null
                                ? Text(widget.chatBody["email"])
                                : getEmailFromId(widget.chatBody,
                                    widget.firestore, widget.auth),
                          ],
                        ),
                      ),
                    )),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Container(
                      width: 50,
                      child: InkWell(
                        onTap: () async {
                          String partnerID;
                          if (widget.chatBody["uid"] != null) {
                            partnerID = widget.chatBody["uid"];
                            // initCallIntent(
                            //     "v",
                            //     widget.homeWidget.auth.currentUser.uid,
                            //     partnerID,
                            //     true,
                            //     widget.homeWidget.firestore,
                            //     context);
                          } else {
                            if (widget.chatBody["sender"] ==
                                widget.auth.currentUser.uid) {
                              partnerID = widget.chatBody["receiver"];
                            } else {
                              partnerID = widget.chatBody["sender"];
                            }

                            widget.call(partnerID);
                            // here add call button

                          }
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          child: Card(
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0),
                            ),
                            color: Color.fromARGB(255, 241, 241, 241),
                            child: Icon(Icons.call_outlined),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Visibility(
                    visible: widget.homeWidget.showMobileView,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: InkWell(
                        onTap: () {
                          print("pressed to go back");
                          setState(() {
                            widget.homeWidget.mobileViewLevel = 1;

                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Icon(Icons.chevron_left),
                        ),
                      ),
                    )),
              ],
            )),
          ),
          Positioned(
              top: 75,
              left: 0,
              right: 0,
              bottom:widget.showEmojiListSingle? 370:70,
              child: StreamBuilder<QuerySnapshot>(
                  stream: widget.firestore
                      .collection(createRoomName(
                          widget.auth.currentUser.uid,
                          widget.chatBody["sender"] != null
                              ? (widget.chatBody["sender"] ==
                                      widget.auth.currentUser.uid
                                  ? widget.chatBody["receiver"]
                                  : widget.chatBody["sender"])
                              : widget.chatBody["uid"]))
                      .orderBy("time")
                      .snapshots(),
                  builder:
                      (BuildContext c, AsyncSnapshot<QuerySnapshot> snapshot) {
                        // _scrollController
                        //     .jumpTo(_scrollController.position.maxScrollExtent);


                    if (snapshot.hasData && snapshot.data.size > 0) {
                      WidgetsBinding.instance
                          .addPostFrameCallback((_){
                        _scrollController.animateTo(
                            _scrollController.position.maxScrollExtent,
                            curve: Curves.easeOut,
                            duration: const Duration(milliseconds: 300));
                      });

                      return Padding(
                        padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                        child: ListView.builder(

                             controller: _scrollController,
                            shrinkWrap: true,
                            itemCount:
                                snapshot.data == null ? 0 : snapshot.data.size,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: snapshot.data.docs[index]
                                                  .data()["sender"] ==
                                              widget.auth.currentUser.uid
                                          ? Alignment.centerRight
                                          : Alignment.centerLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.all(0.0),
                                        child: snapshot.data.docs[index]
                                                    .data()["sender"] ==
                                                widget.auth.currentUser.uid
                                            ? Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment: snapshot
                                                            .data.docs[index]
                                                            .data()["sender"] ==
                                                        widget.auth.currentUser
                                                            .uid
                                                    ? CrossAxisAlignment.end
                                                    : CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0, 0, 5, 0),
                                                    child: Text(
                                                      DateFormat('hh:mm aa')
                                                          .format(DateTime
                                                              .fromMillisecondsSinceEpoch(
                                                                  snapshot
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                      style: TextStyle(
                                                          fontSize: 12),
                                                    ),
                                                  ),
                                                  Card(
                                                    color: snapshot.data
                                                                    .docs[index]
                                                                    .data()[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? Colors.white
                                                        : Color.fromARGB(
                                                            255, 238, 246, 255),
                                                    child: Container(
                                                        child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                  //   child: Text(snapshot.data.docs[index].data()["message"]),

                                                     child:
                                                      makeChatMessageHead1WithEmoji(
                                                              context,
                                                              snapshot.data
                                                                  .docs[index]
                                                                  .data()),
                                                    )),
                                                  ),
                                                ],
                                              )
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  widget.chatBody["img"] == null
                                                      ? CircleAvatar(
                                                          radius: 10,
                                                        )
                                                      : CircleAvatar(
                                                          radius: 10,
                                                          backgroundImage:
                                                              NetworkImage(widget
                                                                      .chatBody[
                                                                  "img"]),
                                                        ),
                                                  Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment: snapshot
                                                                    .data
                                                                    .docs[index]
                                                                    .data()[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? CrossAxisAlignment.end
                                                        : CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                5, 0, 0, 0),
                                                        child: Text(
                                                          DateFormat('hh:mm aa')
                                                              .format(DateTime
                                                                  .fromMillisecondsSinceEpoch(snapshot
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                          style: TextStyle(
                                                              fontSize: 12),
                                                        ),
                                                      ),
                                                      Card(
                                                        color: snapshot.data
                                                                        .docs[index]
                                                                        .data()[
                                                                    "sender"] ==
                                                                widget
                                                                    .auth
                                                                    .currentUser
                                                                    .uid
                                                            ? Colors.white
                                                            : Color.fromARGB(
                                                                255,
                                                                238,
                                                                246,
                                                                255),
                                                        child: Container(
                                                            child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                             // child: Text(snapshot.data.docs[index].data()["message"]),
                                                           child:
                                                          makeChatMessageHead1WithEmoji(
                                                                  context,
                                                                  snapshot
                                                                      .data
                                                                      .docs[
                                                                          index]
                                                                      .data()),
                                                        )),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }),
                      );
                    } else {
                      return Center(
                        child: Text("Send your first message"),
                      );
                    }
                  })),

          //
          // widget.chatBody!=null? Align(
          //   alignment: Alignment.bottomCenter,
          //   child: Wrap(children: [
          //     Container(height: 60,
          //       child: Stack(
          //         children: [
          //           Positioned(
          //             bottom: 10,
          //             left: 10,
          //             right: 130,
          //             child: Container(
          //               height: 60,
          //               child: Center(
          //                 child: Card(
          //                   elevation: 0,
          //                   color: Color.fromARGB(255, 238, 246, 255),
          //                   child: Container(
          //                     child: new TextField(
          //                       onSubmitted: (val) async {
          //                         sendMessage(val, "txt", "-");
          //
          //                         controller.clear();
          //                       },
          //                       controller: controller,
          //                       textAlign: TextAlign.left,
          //                       decoration: new InputDecoration(
          //                         hintText: "Type your message",
          //                         contentPadding: EdgeInsets.all(10),
          //                         border: InputBorder.none,
          //                       ),
          //                     ),
          //                   ),
          //                 ),
          //               ),
          //             ),
          //           ),
          //           Positioned(
          //             bottom: 10,
          //             right: 10,
          //             child: Container(
          //               height: 60,
          //               child: Row(
          //                 mainAxisAlignment: MainAxisAlignment.center,
          //                 crossAxisAlignment: CrossAxisAlignment.center,
          //                 children: [
          //                   Center(
          //                     child: new InkWell(
          //                       onTap: () async {
          //                         //widget.room
          //                         FilePickerResult result =
          //                         await FilePicker.platform
          //                             .pickFiles();
          //
          //                         if (result != null) {
          //                           PlatformFile file =
          //                               result.files.first;
          //
          //                           print(file.name);
          //                           // print(file.bytes);
          //                           // _base64 = BASE64.encode(response.bodyBytes);
          //                           String base =
          //                           base64.encode(file.bytes);
          //
          //                           String url =
          //                               "https://talk.maulaji.com/uploadfilemessenger.php";
          //
          //                           print(file.size);
          //                           print(file.extension);
          //                           print(file.path);
          //                           //print("base");
          //                           // print(base);
          //
          //                           var response = await http.post(
          //                               Uri.parse(url),
          //                               body: jsonEncode({
          //                                 'name': file.name,
          //                                 'file': base,
          //                                 'ex': file.extension
          //                               }));
          //                           print(
          //                               'Response status: ${response.statusCode}');
          //                           print(response.body);
          //                           dynamic res =
          //                           jsonDecode(response.body);
          //                           if (res["status"]) {
          //                             sendMessage(res["path"],
          //                                 file.extension, file.name);
          //                           } else {
          //                             print("could not save");
          //                           }
          //                         } else {
          //                           // User canceled the picker
          //                         }
          //                       },
          //                       child: Padding(
          //                         padding: const EdgeInsets.all(8.0),
          //                         child: Icon(
          //                           Icons.attach_file,
          //                           color:
          //                           Theme.of(context).primaryColor,
          //                         ),
          //                       ),
          //                     ),
          //                   ),
          //                   Center(
          //                     child: new InkWell(
          //                       onTap: () async {
          //                         //widget.room
          //                         setState(() {
          //                           widget.showEmojiList = ! widget.showEmojiList;
          //                         });
          //                         print("emoji "+ widget.showEmojiList.toString());
          //                       },
          //                       child: Padding(
          //                         padding: const EdgeInsets.all(8.0),
          //                         child: Icon(
          //                           Icons.emoji_emotions,
          //                           color:
          //                           Theme.of(context).primaryColor,
          //                         ),
          //                       ),
          //                     ),
          //                   ),
          //                   Center(
          //                     child: new InkWell(
          //                       onTap: () async {
          //                         //widget.room
          //                         String text = controller.text;
          //                         if (text.length > 0) {
          //                           String room = createRoomName(
          //                               widget.auth.currentUser.uid,
          //                               widget.chatBody["sender"] !=
          //                                   null
          //                                   ? (widget.chatBody[
          //                               "sender"] ==
          //                                   widget.auth
          //                                       .currentUser.uid
          //                                   ? widget.chatBody[
          //                               "receiver"]
          //                                   : widget
          //                                   .chatBody["sender"])
          //                                   : widget.chatBody["uid"]);
          //
          //                           await widget.firestore
          //                               .collection("last")
          //                               .doc(room)
          //                               .set({
          //                             "message": text,
          //                             "sender":
          //                             widget.auth.currentUser.uid,
          //                             "receiver": widget
          //                                 .chatBody["sender"] !=
          //                                 null
          //                                 ? (widget.chatBody[
          //                             "sender"] ==
          //                                 widget.auth
          //                                     .currentUser.uid
          //                                 ? widget
          //                                 .chatBody["receiver"]
          //                                 : widget
          //                                 .chatBody["sender"])
          //                                 : widget.chatBody["uid"]
          //                           });
          //
          //                           await widget.firestore
          //                               .collection(room)
          //                               .add({
          //                             "time": DateTime.now()
          //                                 .millisecondsSinceEpoch,
          //                             "message": text,
          //                             "sender":
          //                             widget.auth.currentUser.uid,
          //                             "receiver": widget
          //                                 .chatBody["sender"] !=
          //                                 null
          //                                 ? (widget.chatBody[
          //                             "sender"] ==
          //                                 widget.auth
          //                                     .currentUser.uid
          //                                 ? widget
          //                                 .chatBody["receiver"]
          //                                 : widget
          //                                 .chatBody["sender"])
          //                                 : widget.chatBody["uid"]
          //                           });
          //                           controller.clear();
          //                         }
          //                       },
          //                       child: Padding(
          //                         padding: const EdgeInsets.all(8.0),
          //                         child: Icon(
          //                           Icons.send,
          //                           color: Colors.blue,
          //                         ),
          //                       ),
          //                     ),
          //                   ),
          //                 ],
          //               ),
          //             ),
          //           ),
          //         ],
          //       ),
          //     ),
          //     widget.showEmojiList? Container(height: 300,
          //       // width: 500,
          //       child: GridView.builder(
          //         itemCount:Emoji.all().length,
          //         gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //             crossAxisCount:widget.showMobileView?7:15),
          //         itemBuilder: (BuildContext context, int index) {
          //           return InkWell(onTap: (){
          //             controller.text = controller.text+Emoji.all()[index].char;
          //           },child: Center(child: new Text(Emoji.all()[index].char)));
          //         },
          //       ),
          //     ):Container(width: 0,height: 0,)
          //
          //   ],),
          // ):Container(width: 0,height: 0,),
          Align(
            alignment: Alignment.bottomCenter,
            child: Wrap(
              children: [
                Container(
                  height: 60,
                  child: Stack(
                    children: [
                      Positioned(
                        bottom: 10,
                        left: 10,
                        right: 130,
                        child: Container(
                          height: 60,
                          child: Center(
                            child: Card(
                              elevation: 0,
                              color: Color.fromARGB(255, 238, 246, 255),
                              child: Container(
                                child: new TextField(
                                  onSubmitted: (val) async {
                                    sendMessage(widget.auth, widget.firestore,
                                        val, "txt", "-", widget.chatBody);

                                    controller.clear();
                                  },
                                  controller: controller,
                                  textAlign: TextAlign.left,
                                  decoration: new InputDecoration(
                                    hintText: "Type your message",
                                    contentPadding: EdgeInsets.all(10),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10,
                        right: 10,
                        child: Container(
                          height: 60,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room
                                    FilePickerResult result =
                                        await FilePicker.platform.pickFiles();

                                    if (result != null) {
                                      PlatformFile file = result.files.first;

                                      print(file.name);
                                      // print(file.bytes);
                                      // _base64 = BASE64.encode(response.bodyBytes);
                                      String base = base64.encode(file.bytes);

                                      String url =
                                          "https://talk.maulaji.com/uploadfilemessenger.php";

                                      print(file.size);
                                      print(file.extension);
                                      print(file.path);
                                      //print("base");
                                      // print(base);

                                      var response = await http.post(
                                          Uri.parse(url),
                                          body: jsonEncode({
                                            'name': file.name,
                                            'file': base,
                                            'ex': file.extension
                                          }));
                                      print(
                                          'Response status: ${response.statusCode}');
                                      print(response.body);
                                      dynamic res = jsonDecode(response.body);
                                      if (res["status"]) {
                                        sendMessage(
                                            widget.auth,
                                            widget.firestore,
                                            res["path"],
                                            file.extension,
                                            file.name,
                                            widget.chatBody);
                                      } else {
                                        print("could not save");
                                      }
                                    } else {
                                      // User canceled the picker
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.attach_file,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room
                                    setState(() {
                                      widget.showEmojiListSingle =
                                          !widget.showEmojiListSingle;
                                    });
                                    print("emoji " +
                                        widget.showEmojiListSingle.toString());
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.emoji_emotions,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room
                                    String text = controller.text;
                                    if (text.length > 0) {
                                      String room = createRoomName(
                                          widget.auth.currentUser.uid,
                                          widget.chatBody["sender"] != null
                                              ? (widget.chatBody["sender"] ==
                                                      widget
                                                          .auth.currentUser.uid
                                                  ? widget.chatBody["receiver"]
                                                  : widget.chatBody["sender"])
                                              : widget.chatBody["uid"]);

                                      await widget.firestore
                                          .collection("last")
                                          .doc(room)
                                          .set({
                                        "message": text,
                                        "sender": widget.auth.currentUser.uid,
                                        "receiver": widget.chatBody["sender"] !=
                                                null
                                            ? (widget.chatBody["sender"] ==
                                                    widget.auth.currentUser.uid
                                                ? widget.chatBody["receiver"]
                                                : widget.chatBody["sender"])
                                            : widget.chatBody["uid"]
                                      });

                                      await widget.firestore
                                          .collection(room)
                                          .add({
                                        "time": DateTime.now()
                                            .millisecondsSinceEpoch,
                                        "message": text,
                                        "sender": widget.auth.currentUser.uid,
                                        "receiver": widget.chatBody["sender"] !=
                                                null
                                            ? (widget.chatBody["sender"] ==
                                                    widget.auth.currentUser.uid
                                                ? widget.chatBody["receiver"]
                                                : widget.chatBody["sender"])
                                            : widget.chatBody["uid"]
                                      });
                                      controller.clear();
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.send,
                                      color: Colors.blue,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                widget.showEmojiListSingle
                    ? Container(
                        height: 300,
                        // width: 500,
                        color: Colors.white,
                        child: GridView.builder(
                          itemCount: Emoji.all().length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 15),
                          itemBuilder: (BuildContext context, int index) {
                            return InkWell(
                                onTap: () {
                                  controller.text =
                                      controller.text + Emoji.all()[index].char;
                                },
                                child: Center(
                                    child: new Text(Emoji.all()[index].char)));
                          },
                        ),
                      )
                    : Container(
                        width: 0,
                        height: 0,
                      )
              ],
            ),
          ),
          // widget.showProfileCompleteDialog
          //     ? Align(
          //   alignment: Alignment.center,
          //   child: Card(
          //     color: Color.fromARGB(255, 239, 247, 255),
          //     elevation: 20,
          //     child: Container(
          //         width: 400,
          //         height: 400,
          //         child: ProfileUpdateDialog(
          //           auth: widget.auth,
          //           firestore: widget.firestore,
          //           currentProfile: widget.currentProfile,
          //         )),
          //   ),
          // )
          //     : Container(
          //   width: 0,
          //   height: 0,
          // ),
          // showAddFndDialog(),
          Align(alignment: Alignment.center,
          child:
          DropZone(
              onDragEnter: () {
                print('drag enter');
              },
              onDragExit: () {
                print('drag exit');
              },
              onDrop: (List<html.File> files) {
                print('files dropped');
                //print(files);
                sendThisFileAsDropped(files);
              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
              )
          ) ,)
        ],
      ),
    );
  }

  void listenDisplayStatus() {

  }
String getExtention(String mime){
    if(mime == "audio/aac")return "aac";
    if(mime == "video/x-msvideo")return "avi";
    if(mime == "image/bmp")return "bmp";
    if(mime == "text/csv")return "csv";
    if(mime == "application/msword")return "doc";
    if(mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document")return "docx";
    if(mime == "image/gif")return "gif";
    if(mime == "text/html")return "html";
    if(mime == "image/jpeg")return "jpeg";
    if(mime == "image/jpg")return "jpeg";
    if(mime == "application/json")return "mp3";
    if(mime == "audio/mpeg")return "aac";
    if(mime == "video/mp4")return "mp4";
    if(mime == "video/mpeg")return "mpeg";
    if(mime == "image/png")return "png";
    if(mime == "application/pdf")return "pdf";
    if(mime == "ppt")return "application/vnd.ms-powerpoint";
    if(mime == "pptx")return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    if(mime == "rar")return "application/vnd.rar";
    if(mime == "svg")return "image/svg+xml";
    if(mime == "txt")return "text/plain";
    if(mime == "webm")return "video/webm";
    if(mime == "zip")return "application/zip";
    if(mime == "3gp")return "video/3gpp";
    if(mime == "3gp")return "audio/3gpp";

}
  void sendThisFileAsDropped(List<html.File> files)async {
    for(int i  = 0 ; i < files.length ; i ++){
      //File()
     // String base = base64.encode(files.last.);
     // print(files[i].relativePath);
      FileReader reader =  FileReader();

      reader.onLoadEnd.listen((e) async{
      Uint8List  baseuntint = reader.result;
      print(" / "+i.toString());
      String base =   base64Encode(baseuntint);
      print(files[i].name);
      print(files[i].type);
      String extention = getExtention(files[i].type);

      //up,oad work
      String url =
          "https://talk.maulaji.com/uploadfilemessenger.php";


      //print("base");
      // print(base);

      var response = await http.post(
          Uri.parse(url),
          body: jsonEncode({
            'name':files[i].name,
            'file': base,
            'ex': files[i].type
          }));
      print(
          'Response status: ${response.statusCode}');
      print(response.body);
      dynamic res = jsonDecode(response.body);
      if (res["status"]) {
        sendMessage(
            widget.auth,
            widget.firestore,
            res["path"],
            files[i].type,
            files[i].name,
            widget.chatBody);
      } else {
        print("could not save");
      }

        //end upload


      });
      reader.readAsArrayBuffer(files[i]);
    }

    // String base = base64.encode(file.bytes);
    //
    // String url =
    //     "https://talk.maulaji.com/uploadfilemessenger.php";
    //
    // print(file.size);
    // print(file.extension);
    // print(file.path);
    // //print("base");
    // // print(base);
    //
    // var response = await http.post(
    //     Uri.parse(url),
    //     body: jsonEncode({
    //       'name': file.name,
    //       'file': base,
    //       'ex': file.extension
    //     }));
    // print(
    //     'Response status: ${response.statusCode}');
    // print(response.body);
    // dynamic res = jsonDecode(response.body);
    // if (res["status"]) {
    //
    // }
  }


}

class GroupChatThread extends StatefulWidget {
  Home widgetHome;
  bool showEmojiList = false;

  QueryDocumentSnapshot documentSnapshot;

  FirebaseAuth auth;

  FirebaseFirestore firestore;

  GroupChatThread(
      {this.widgetHome, this.documentSnapshot, this.auth, this.firestore});

  @override
  _GroupChatThreadState createState() => _GroupChatThreadState();
}

class _GroupChatThreadState extends State<GroupChatThread> {
  TextEditingController controllerGrp = TextEditingController();
  ScrollController _scrollController = new ScrollController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              top: 75,
              left: 0,
              right: 0,
              bottom: 70,
              child: StreamBuilder<QuerySnapshot>(
                  stream: widget.widgetHome.firestore
                      .collection("groupChats")
                      .doc(widget.documentSnapshot.id)
                      .collection("chats")
                      .orderBy("time")
                      .snapshots(),
                  builder: (BuildContext c,
                      AsyncSnapshot<QuerySnapshot> snapshotMEssage) {
                    if (snapshotMEssage.hasData &&
                        snapshotMEssage.data.size > 0) {
                      WidgetsBinding.instance
                          .addPostFrameCallback((_){
                        _scrollController.animateTo(
                            _scrollController.position.maxScrollExtent,
                            curve: Curves.easeOut,
                            duration: const Duration(milliseconds: 300));
                      });
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                        child: ListView.builder(
                             controller: _scrollController,
                            shrinkWrap: true,
                            itemCount: snapshotMEssage.data == null
                                ? 0
                                : snapshotMEssage.data.size,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: snapshotMEssage
                                                  .data.docs[index]
                                                  .data()["sender"] ==
                                              widget.auth.currentUser.uid
                                          ? Alignment.centerRight
                                          : Alignment.centerLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.all(0.0),
                                        child: snapshotMEssage.data.docs[index]
                                                    .data()["sender"] ==
                                                widget.auth.currentUser.uid
                                            ? Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    snapshotMEssage.data
                                                                    .docs[index]
                                                                    .data()[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? CrossAxisAlignment.end
                                                        : CrossAxisAlignment
                                                            .start,
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0, 0, 5, 0),
                                                    child: Text(
                                                      DateFormat('hh:mm aa')
                                                          .format(DateTime
                                                              .fromMillisecondsSinceEpoch(
                                                                  snapshotMEssage
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                      style: TextStyle(
                                                          fontSize: 12),
                                                    ),
                                                  ),
                                                  Card(
                                                    color: snapshotMEssage.data
                                                                    .docs[index]
                                                                    .data()[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? Colors.white
                                                        : Color.fromARGB(
                                                            255, 238, 246, 255),
                                                    child: Container(
                                                        child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                      //child: Text( snapshotMEssage.data.docs[index].data()["message"]),
                                                      child:
                                                          makeChatMessageHead1(
                                                              context,
                                                              snapshotMEssage
                                                                  .data
                                                                  .docs[index]
                                                                  .data()),
                                                    )),
                                                  ),
                                                ],
                                              )
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CircleAvatar(
                                                    radius: 10,
                                                  ),
                                                  Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        snapshotMEssage.data
                                                                        .docs[index]
                                                                        .data()[
                                                                    "sender"] ==
                                                                widget
                                                                    .auth
                                                                    .currentUser
                                                                    .uid
                                                            ? CrossAxisAlignment
                                                                .end
                                                            : CrossAxisAlignment
                                                                .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                5, 0, 0, 0),
                                                        child: Text(
                                                          DateFormat('hh:mm aa').format(
                                                              DateTime.fromMillisecondsSinceEpoch(
                                                                  snapshotMEssage
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                          style: TextStyle(
                                                              fontSize: 12),
                                                        ),
                                                      ),
                                                      Card(
                                                        color: snapshotMEssage
                                                                        .data
                                                                        .docs[index]
                                                                        .data()[
                                                                    "sender"] ==
                                                                widget
                                                                    .auth
                                                                    .currentUser
                                                                    .uid
                                                            ? Colors.white
                                                            : Color.fromARGB(
                                                                255,
                                                                238,
                                                                246,
                                                                255),
                                                        child: Container(
                                                            child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          //child: Text( snapshotMEssage.data.docs[index].data()["message"]),
                                                          child:
                                                              makeChatMessageHead1(
                                                                  context,
                                                                  snapshotMEssage
                                                                      .data
                                                                      .docs[
                                                                          index]
                                                                      .data()),
                                                        )),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }),
                      );
                    } else {
                      return Center(
                        child: Text("Send your first message"),
                      );
                    }
                  })),
          Align(
            alignment: Alignment.bottomCenter,
            child: Wrap(
              children: [
                Container(
                  height: 60,
                  child: Stack(
                    children: [
                      Positioned(
                        bottom: 10,
                        left: 10,
                        right: 130,
                        child: Container(
                          height: 60,
                          child: Center(
                            child: Card(
                              elevation: 0,
                              color: Color.fromARGB(255, 238, 246, 255),
                              child: Container(
                                child: new TextField(
                                  onSubmitted: (val) async {
                                    sendMessageGroup(
                                        widget.firestore,
                                        widget.auth,
                                        val,
                                        "txt",
                                        "-",
                                        widget.documentSnapshot.id);

                                    controllerGrp.clear();
                                  },
                                  controller: controllerGrp,
                                  textAlign: TextAlign.left,
                                  decoration: new InputDecoration(
                                    hintText: "Type your message",
                                    contentPadding: EdgeInsets.all(10),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10,
                        right: 10,
                        child: Container(
                          height: 60,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room
                                    FilePickerResult result =
                                        await FilePicker.platform.pickFiles();

                                    if (result != null) {
                                      PlatformFile file = result.files.first;

                                      print(file.name);
                                      // print(file.bytes);
                                      // _base64 = BASE64.encode(response.bodyBytes);
                                      String base = base64.encode(file.bytes);

                                      String url =
                                          "https://talk.maulaji.com/uploadfilemessenger.php";

                                      print(file.size);
                                      print(file.extension);
                                      print(file.path);
                                      //print("base");
                                      // print(base);

                                      var response = await http.post(
                                          Uri.parse(url),
                                          body: jsonEncode({
                                            'name': file.name,
                                            'file': base,
                                            'ex': file.extension
                                          }));
                                      print(
                                          'Response status: ${response.statusCode}');
                                      print(response.body);
                                      dynamic res = jsonDecode(response.body);
                                      if (res["status"]) {
                                        sendMessageGroup(
                                            widget.firestore,
                                            widget.auth,
                                            res["path"],
                                            file.extension,
                                            file.name,
                                            widget.documentSnapshot.id);
                                      } else {
                                        print("could not save");
                                      }
                                    } else {
                                      // User canceled the picker
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.attach_file,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room

                                    setState(() {
                                      widget.showEmojiList =
                                          !widget.showEmojiList;
                                    });
                                    print("emoji " +
                                        widget.showEmojiList.toString());
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.emoji_emotions,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: new InkWell(
                                  onTap: () async {
                                    //widget.room
                                    String text = controllerGrp.text;
                                    sendMessageGroup(
                                        widget.firestore,
                                        widget.auth,
                                        text,
                                        "txt",
                                        "-",
                                        widget.documentSnapshot.id);
                                    controllerGrp.clear();
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(
                                      Icons.send,
                                      color: Colors.blue,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                widget.showEmojiList
                    ? Container(
                        height: 300,
                        color: Colors.white,
                        // width: 500,
                        child: GridView.builder(
                          itemCount: Emoji.all().length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount:
                                      widget.widgetHome.showMobileView
                                          ? 7
                                          : 15),
                          itemBuilder: (BuildContext context, int index) {
                            return InkWell(
                                onTap: () {
                                  controllerGrp.text = controllerGrp.text +
                                      Emoji.all()[index].char;
                                },
                                child: Center(
                                    child: new Text(Emoji.all()[index].char)));
                          },
                        ),
                      )
                    : Container(
                        width: 0,
                        height: 0,
                      )
              ],
            ),
          ),
          Positioned(
              top: 70,
              child: Container(
                color: Colors.grey,
                height: 0.5,
                width: MediaQuery.of(context).size.width,
              )),
          Align(
            alignment: Alignment.topLeft,
            child: Container(
              height: 70,
              // width: MediaQuery.of(context).size.height,
              color: Colors.white,
              child: Container(
                width: 300,
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(8, 8, 15, 8),
                          child: Icon(Icons.supervised_user_circle),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.documentSnapshot.data()["name"],
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                  fontSize: 20),
                            ),
                            getListOfPeople(
                                widget.documentSnapshot.data()["users"]),
                            // Text(groupChatSnaps.data.docs[index].data()["users"].length.toString()+" users"),
                          ],
                        ),
                      ],
                    )),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

void sendMessageGroup(FirebaseFirestore firestore, FirebaseAuth auth,
    String val, String type, String name, String groupID) async {
  print("sent " + type);

  await firestore
      .collection("groupChats")
      .doc(groupID)
      .collection("chats")
      .add({
    "time": DateTime.now().millisecondsSinceEpoch,
    "message": val,
    "type": type,
    "fname": name,
    "sender": auth.currentUser.uid,
  });
}

class ImageDialog extends StatelessWidget {
  String path;

  ImageDialog({this.path});

  @override
  Widget build(BuildContext context) {
    String base = "https://talk.maulaji.com/";
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Image.network(
        base + path,
        height: MediaQuery.of(context).size.height,
      ),
    );
  }
}
makeChatMessageHead1WithEmoji(BuildContext context, dynamic data) {
 // return Text(data["message"]);


  String base = "https://talk.maulaji.com/";
  if (data["type"] == null){
  return Text(data["message"]);
  }else
  if (data["type"] != null && data["type"] == "txt")
    return Text(data["message"]);
  else if (data["type"] != null) if (data["type"] == "img" ||
      data["type"] == "png" ||
      data["type"] == "PNG" ||
      data["type"] == "jpg" ||
      data["type"] == "JPG" ||
      data["type"] == "jpeg" ||
      data["type"] == "JPEG")
    return InkWell(
      onTap: () async {
        await showDialog(
            context: context,
            builder: (_) => ImageDialog(
              path: data["message"],
            ));
      },
      child: Image.network(
        base + data["message"],
        height: 200,
        width: 200,
      ),
    );
  else if (data["type"] != null) if (data["type"] == "vdo" ||
      data["type"] == "mp4" ||
      data["type"] == "mov" ||
      data["type"] == "avi" ||
      data["type"] == "3gp" ||
      data["type"] == "mpeg4")
    return Container(
        width: 200,
        height: 200,
        child: VideoApp(
          link: data["message"],
        ));
  else
    return InkWell(
      onTap: () {
        html.AnchorElement anchorElement =
        new html.AnchorElement(href: base + data["message"]);
        anchorElement.download = base + data["message"];
        anchorElement.click();
      },
      child: Text(data["message"]),
    );
}

makeChatMessageHead1(BuildContext context, dynamic data) {


  if (data["type"] != null && data["type"] == "txt")
    return Text(data["message"]);
  else if (data["type"] != null) if (data["type"] == "img" ||
      data["type"] == "png" ||
      data["type"] == "PNG" ||
      data["type"] == "jpg" ||
      data["type"] == "JPG" ||
      data["type"] == "jpeg" ||
      data["type"] == "JPEG")
    return InkWell(
      onTap: () async {
        await showDialog(
            context: context,
            builder: (_) => ImageDialog(
                  path: data["message"],
                ));
      },
      child: Image.network(
        base + data["message"],
        height: 200,
        width: 200,
      ),
    );
  else if (data["type"] != null) if (data["type"] == "vdo" ||
      data["type"] == "mp4" ||
      data["type"] == "mov" ||
      data["type"] == "avi" ||
      data["type"] == "3gp" ||
      data["type"] == "mpeg4")
    return Container(
        width: 200,
        height: 200,
        child: VideoApp(
          link: data["message"],
        ));
  else
    return InkWell(
      onTap: () {
        html.AnchorElement anchorElement =
            new html.AnchorElement(href: base + data["message"]);
        anchorElement.download = base + data["message"];
        anchorElement.click();
      },
      child: Text(data["message"]),
    );
}

class VideoApp extends StatefulWidget {
  String link;

  VideoApp({this.link});

  @override
  _VideoAppState createState() => _VideoAppState();
}

class _VideoAppState extends State<VideoApp> {
  VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(widget.link)
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '',
      home: Scaffold(
        body: Stack(
          children: [
            Align(
              alignment: Alignment.center,
              child: Center(
                child: _controller.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _controller.value.aspectRatio,
                        child: VideoPlayer(_controller),
                      )
                    : Container(),
              ),
            ),
            Align(
              child: InkWell(
                onTap: () {
                  setState(() {
                    _controller.value.isPlaying
                        ? _controller.pause()
                        : _controller.play();
                  });
                },
                child: Icon(
                  _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}

void sendMessage(FirebaseAuth auth, FirebaseFirestore firestore, String val,
    String type, String name, dynamic chatBody) async {
  print("sent " + type);
  String room = createRoomName(
      auth.currentUser.uid,
      chatBody["sender"] != null
          ? (chatBody["sender"] == auth.currentUser.uid
              ? chatBody["receiver"]
              : chatBody["sender"])
          : chatBody["uid"]);

  await firestore.collection("last").doc(room).set({
    "message": val,
    "type": type,
    "fname": name,
    "sender": auth.currentUser.uid,
    "receiver": chatBody["sender"] != null
        ? (chatBody["sender"] == auth.currentUser.uid
            ? chatBody["receiver"]
            : chatBody["sender"])
        : chatBody["uid"]
  });

  await firestore.collection(room).add({
    "time": DateTime.now().millisecondsSinceEpoch,
    "message": val,
    "type": type,
    "fname": name,
    "sender": auth.currentUser.uid,
    "receiver": chatBody["sender"] != null
        ? (chatBody["sender"] == auth.currentUser.uid
            ? chatBody["receiver"]
            : chatBody["sender"])
        : chatBody["uid"]
  });
}

String createRoomName(String uid, partner) {
  final List<String> ids = <String>[uid, partner];
  ids.sort();
  return ids.first + "-" + ids.last;
}

Widget getEmailFromId(
    dynamic body, FirebaseFirestore firestore, FirebaseAuth auth) {
  return FutureBuilder<QuerySnapshot>(
      future: firestore
          .collection("users")
          .where("uid",
              isEqualTo: body["uid"] != null
                  ? body["uid"]
                  : (body["receiver"] == auth.currentUser.uid
                      ? body["sender"]
                      : body["receiver"]))
          .get(),
      builder: (context, snapuserInfo) {
        if (snapuserInfo.hasData) {
          return Text(
            snapuserInfo.data.docs.first.data()["email"],
            style: TextStyle(),
          );
        } else {
          return Text("No Email address found");
        }
      });
}
