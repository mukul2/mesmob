import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

String _baseUrl = "https://api.callgpnow.com/api/";
String _baseUrl_image = "https://api.callgpnow.com/";

class CallButonsClickStreamCamera {
  static CallButonsClickStreamCamera model = null;
  final StreamController<bool> _Controller = StreamController<bool>.broadcast();

  Stream<bool> get outData => _Controller.stream;

  Sink<bool> get inData => _Controller.sink;

  dataReload(bool status) {
    fetch().then((value) => inData.add(status));
  }

  void dispose() {
    _Controller.close();
  }

  static CallButonsClickStreamCamera getInstance() {
    if (model == null) {
      model = new CallButonsClickStreamCamera();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}

class CallButonsClickStreamScreen{
  static CallButonsClickStreamScreen model = null;
  final StreamController<bool> _Controller = StreamController<bool>.broadcast();

  Stream<bool> get outData => _Controller.stream;

  Sink<bool> get inData => _Controller.sink;

  dataReload(bool status) {
    fetch().then((value) => inData.add(status));
  }

  void dispose() {
    _Controller.close();
  }

  static CallButonsClickStreamScreen getInstance() {
    if (model == null) {
      model = new CallButonsClickStreamScreen();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}


class WidgetReadyStream{
  static WidgetReadyStream model = null;
  final StreamController<Widget> _Controller = StreamController<Widget>.broadcast();

  Stream<Widget> get outData => _Controller.stream;

  Sink<Widget> get inData => _Controller.sink;

  dataReload(Widget status) {
    fetch().then((value) => inData.add(status));
  }

  void dispose() {
    _Controller.close();
  }

  static WidgetReadyStream getInstance() {
    if (model == null) {
      model = new WidgetReadyStream();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}



class SelfStatusStream{
  static SelfStatusStream model = null;
  final StreamController<String> _Controller = StreamController<String>.broadcast();

  Stream<String> get outData => _Controller.stream;

  Sink<String> get inData => _Controller.sink;

  dataReload(String status) {
    fetch().then((value) => inData.add(status));
  }

  void dispose() {
    _Controller.close();
  }

  static SelfStatusStream getInstance() {
    if (model == null) {
      model = new SelfStatusStream();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}