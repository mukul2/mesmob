import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:maulajimessenger/services/Settings.dart';

import 'package:socket_io_client/socket_io_client.dart' as IO;



class AppSignal {

   IO.Socket socket;

   AppSignal();
   IO.Socket initSignal(){
    if(socket==null){
      //socket = IO.io('https://signal1.maulaji.com');
      socket = IO.io('http://localhost:3000');
      socket = IO.io(AppSettings().Signal_link);
      socket.onConnect((_) {

      });
      return socket;
    }else{

      return socket;
    }

  }




}
