import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:maulajimessenger/services/Signal.dart';
import 'package:http/http.dart' as http;



class AppSettings {

  String Signal_link = "http://localhost:3000";
  String Api_link = "http://localhost:3001/";


  AppSettings();


}
