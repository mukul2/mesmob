import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/Screens/logged_in_home.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        fontFamily: 'Poppins',

        primarySwatch: Colors.blue,
      ),
      home:  FutureBuilder(
        // Initialize FlutterFire:
        future: Firebase.initializeApp(),
        builder: (context, snapshot) {
          // Check for errors
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                child: Text("Error"),
              ),
            );
          }

          // Once complete, show your application
          if (snapshot.connectionState == ConnectionState.done) {
            return Root();
          }

          // Otherwise, show something whilst waiting for initialization to complete
          return Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        },
      ),
    );
  }
}

class Root extends StatefulWidget {
  Root({Key key}) : super(key: key);
  dynamic userData;

  @override
  _RootState createState() => _RootState();
}

class _RootState extends State<Root> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (_auth != null &&
        _auth.currentUser != null &&
        _auth.currentUser.uid != null) {
      // fetchuser();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Auth(auth: _auth).user,
      builder: (BuildContext context, AsyncSnapshot<User> snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          if (snapshot.hasData == false ||
              snapshot.data == null ||
              snapshot.data.uid == null) {
            // login screen
            return Login(
              auth: _auth,
              firestore: _firestore,
            );
          } else {
            // home screen
            return  FutureBuilder<SharedPreferences>(
                future: SharedPreferences.getInstance(), builder: (BuildContext context,AsyncSnapshot<SharedPreferences> projectSnap) {
              if(projectSnap.hasData && projectSnap.data!=null){
                return    Home(
                  auth: FirebaseAuth.instance,
                  firestore: _firestore,
                  sharedPreferences: projectSnap.data,
                );
              }else {
                return Scaffold(
                  body: Center(
                      child: CircularProgressIndicator()
                  ),
                );
              }

            });

          }
        } else {
          return const Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        }
      },
    );
  }
}
