import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/Screens/create_account_page.dart';
import 'package:maulajimessenger/services/Auth.dart';


class Login extends StatefulWidget {
  final FirebaseAuth auth;
  final FirebaseFirestore firestore;

  const Login({
    Key key,
    @required this.auth,
    @required this.firestore,
  }) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(0.0),
          ),
          color: Colors.white,
          child: Container(
            width: 400,
            // height: 400,
            child: Padding(
              padding: const EdgeInsets.all(60.0),
              child: Builder(builder: (BuildContext context) {
                return Wrap(
                 // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Image.asset(
                    //   "assets/stahtlogogreen.jpg",
                    //   height: 100,
                    // ),
                    Container(width: MediaQuery.of(context).size.width,child: Text("Maulaji Messenger",style: TextStyle(fontSize: 20),)),
                    TextFormField(
                      textAlign: TextAlign.left,
                      decoration: const InputDecoration(hintText: "Email"),
                      controller: _emailController,
                    ),
                    TextFormField(
                      textAlign: TextAlign.left,
                      decoration: const InputDecoration(hintText: "Password"),
                      controller: _passwordController,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CreateAccount(
                                              auth: widget.auth,
                                              firestore: widget.firestore,
                                            )),
                                  );

                                  //CreateAccount
                                },
                                child: Text(
                                  "Create an Account",
                                  style: TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: RaisedButton(
                              color: Theme.of(context).primaryColor,

                              onPressed: () async {
                                final String retVal =
                                    await Auth(auth: widget.auth).signIn(
                                  email: _emailController.text,
                                  password: _passwordController.text,
                                );
                                if (retVal == "Success") {
                                  _emailController.clear();
                                  _passwordController.clear();
                                } else {
                                  Scaffold.of(context).showSnackBar(
                                      SnackBar(content: Text(retVal)));
                                }
                              },
                              child: const Text(
                                "SIGN IN",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),



                  ],
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
