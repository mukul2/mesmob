import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
// import 'package:flutter_webrtc/web/rtc_session_description.dart';

import 'package:sdp_transform/sdp_transform.dart';

Future<FirebaseApp> customInitialize() {
  return Firebase.initializeApp();
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      home: FutureBuilder(
        // Initialize FlutterFire:
        //  future: Firebase.initializeApp(),
        future: customInitialize(),
        builder: (context, snapshot) {
          // Check for errors
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                child: Text("Error"),
              ),
            );
          }

          // Once complete, show your application
          if (snapshot.connectionState == ConnectionState.done) {
            //  FirebaseFirestore.instance.collection("9feb").add({"data":"data7"});

            return MyApp();
          }

          // Otherwise, show something whilst waiting for initialization to complete
          return const Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        },
      ),
    );
  }
}

var ownCandidateID = null;

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Login(),
    );
  }
}

class SimpleWebCall extends StatefulWidget {
  List streams = [];

  dynamic ownCandidateID;
  String appbart = "";

  bool isAudioMuted = false;
  bool isScreenSharing = false;

  bool isVideoMuted = false;

  bool hasCallOffered = false;

  String callerID = "0";

  String ownID = "0";
  String partnerid = "0";
  bool isCaller = false;
  bool isRecording = false;

  FirebaseFirestore firestore;

  bool didOpositConnected = false;

  String partnerPair;

  dynamic offer;
  String title = "t";

  bool containsVideo;
  String room ;

  SimpleWebCall(
      {this.partnerPair,
      this.ownID,
      this.partnerid,
      this.isCaller,
      this.firestore,
      this.containsVideo});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<SimpleWebCall>
    with WidgetsBindingObserver {
  Timer timer;
  bool _offer = false;
  RTCPeerConnection _peerConnection;
  MediaStream _localStream;
  RTCVideoRenderer _localRenderer = new RTCVideoRenderer();
  RTCVideoRenderer _remoteRenderer = new RTCVideoRenderer();

  MediaRecorder _mediaRecorder;

  bool get _isRec => _mediaRecorder != null;
  final sdpController = TextEditingController();
  List<RTCVideoRenderer> remoteRenderList = [];

  @override
  dispose() {
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    sdpController.dispose();
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    List ids = [widget.ownID, widget.partnerid];
    ids.sort();

    setState(() {
      widget.partnerPair = ids.first + "-" + ids.last;
    });

    if (widget.partnerPair != null) {
      if (widget.isCaller) {
        submitCallEngaggePush(widget.ownID);
        submitCallEngaggePushReverse(widget.ownID);
        FirebaseFirestore.instance
            .collection("rooms")
            .add({"roomId": "sample"}).then((value) {
          FirebaseFirestore.instance
              .collection("rooms")
              .doc(value.id)
              .update({"roomId": value.id});
          setState(() {
            widget.appbart = value.id;
            widget.room = value.id;
          });
          initWorkLoad(value.id);
        });
      } else {
        submitCallEngaggePush(widget.ownID);
        submitCallEngaggePushReverse(widget.ownID);

        FirebaseFirestore.instance
            .collection("queu")
            .doc(widget.partnerPair).snapshots().listen((value) {
          if (value.exists &&
              value.data() != null &&
              value.data()["room"] != null) {
            setState(() {
              widget.appbart = value.data()["room"];
            });
            initWorkLoad(value.data()["room"]);
          }
        });



        // FirebaseFirestore.instance
        //     .collection("queu")
        //     .doc(widget.partnerPair)
        //     .get()
        //     .then((value) {
        //   if (value.exists &&
        //       value.data() != null &&
        //       value.data()["room"] != null) {
        //     setState(() {
        //       widget.appbart = value.data()["room"];
        //     });
        //     initWorkLoad(value.data()["room"]);
        //   }
        // });
      }

      widget.partnerid.replaceAll("dd", "d");
      widget.partnerid.replaceAll("pp", "p");

      widget.ownID.replaceAll("dd", "d");
      widget.ownID.replaceAll("pp", "p");

      if (widget.isCaller == true) {
        setState(() {
          widget.callerID = widget.ownID;
        });
      } else {
        setState(() {
          widget.callerID = widget.partnerid;
        });
      }

      super.initState();

      widget.partnerid.replaceAll("dd", "d");
      widget.partnerid.replaceAll("pp", "p");

      widget.ownID.replaceAll("dd", "d");
      widget.ownID.replaceAll("pp", "p");

      //listen for other party call reject status

      if (widget.isCaller) {
        if (widget.didOpositConnected) {
          widget.firestore
              .collection("incall")
              .doc(widget.partnerid)
              .get()
              .then((value) {
            if (value.exists) {
              if ((value.data()["time"] + 5000) >
                  DateTime.now().millisecondsSinceEpoch) {
              } else {
                Navigator.pop(context);
              }
            } else {
              Navigator.pop(context);
            }
          });
        }
      } else {
        widget.firestore
            .collection("incall")
            .doc(widget.partnerid)
            .get()
            .then((value) {
          if (value.exists) {
            if ((value.data()["time"] + 5000) >
                DateTime.now().millisecondsSinceEpoch) {
            } else {
              Navigator.pop(context);
            }
          } else {
            Navigator.pop(context);
          }
        });
      }
    } else {
      Navigator.pop(context);
    }

/*
    timer = Timer.periodic(Duration(seconds: 1), (Timer t) {
      if (widget.isCaller == true) {
        widget.firestore
            .collection("online")
            .doc(widget.ownID)
            .update({"calltime": new DateTime.now().millisecondsSinceEpoch});



      } else {
        widget.firestore
            .collection("online")
            .doc(widget.partnerid)
            .update({"calltime": new DateTime.now().millisecondsSinceEpoch});
      }
    });

 */
  }

  initRenderers() async {
    await _localRenderer.initialize();
    await _remoteRenderer.initialize();
  }

  void _createOffer(String room) async {
    RTCSessionDescription description = await _peerConnection
        .createOffer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("cerate off");
    print(json.encode(session));
    _offer = true;

    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    //FirebaseFirestore.instance.collection(widget.ownID).add(session);
    // print("writing my own des");

    await _peerConnection.setLocalDescription(description);
    await FirebaseFirestore.instance.collection("rooms").doc(room).set({
      'roolId': room,
      'offer': {
        "type": description.type,
        "sdp": description.sdp,
      }
    });

    // FirebaseFirestore.instance.collection("callQue").doc(widget.partnerid).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});
    // FirebaseFirestore.instance.collection("callQue").doc(widget.ownID).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});

    setState(() {
      widget.hasCallOffered = true;
    });

    FirebaseFirestore.instance
        .collection("rooms")
        .doc(room)
        .snapshots()
        .listen((event) async {
      if (event.exists && event.data()["answer"] != null) {
        //mkl

        print("remote des below");
        print(event.data()["answer"]);

        dynamic ss = event.data()["answer"];
        setState(() {
          widget.appbart = "gdr " + ss["type"];
        });
        RTCSessionDescription description =
            new RTCSessionDescription(ss["sdp"], ss["type"]);

        print("my suspect");
        print(description.toMap());
        print("my suspect ends");
        setState(() {
          widget.appbart = widget.appbart + ss["type"];
        });
        await _peerConnection.setRemoteDescription(description);
        setState(() {
          widget.appbart = "  remote des added ";
        });

        FirebaseFirestore.instance
            .collection("rooms")
            .doc(room)
            .collection("calleeCandidates")
            .snapshots()
            .listen((event) async {
          if (event.docs.length > 0) {
            setState(() {
              widget.appbart = widget.appbart +
                  " candidate side " +
                  event.docs.length.toString() +
                  " ";
            });
            for (int i = 0; i < event.docs.length; i++) {
              dynamic candidate = new RTCIceCandidate(
                event.docs[i].data()["candidate"],
                event.docs[i].data()["sdpMid"],
                event.docs[i].data()["sdpMLineIndex"],
              );
              print("one candidate added");

              // dynamic session = event.docs[i].data();

              //dynamic candidate = new RTCIceCandidate(session['candidate'], session['sdpMid'], session['sdpMLineIndex']);
              _peerConnection.addCandidate(candidate).then((value) {
                setState(() {
                  widget.appbart = widget.appbart + "  ca" + i.toString() + " ";
                });
              });
            }
          } else {
            setState(() {
              widget.appbart = widget.appbart + "  no candidate " + " ";
            });
          }
        });
      } else {
        setState(() {
          widget.appbart = widget.appbart + " no AF";
        });
      }
    });

    FirebaseFirestore.instance
        .collection("queu")
        .doc(widget.partnerPair)
        .set({"room": room}).then((value) {
      submitCallReceiverPush(widget.isCaller, widget.partnerid);
      submitCallReceiverPushReverse(widget.isCaller, widget.partnerid);
    });
    // print("writing my own des end of ");
  }
  void _createOfferUpdated(String room) async {
    RTCSessionDescription description = await _peerConnection
        .createOffer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("cerate off");
    print(json.encode(session));
    _offer = true;

    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    //FirebaseFirestore.instance.collection(widget.ownID).add(session);
    // print("writing my own des");

    await _peerConnection.setLocalDescription(description);
    await FirebaseFirestore.instance.collection("rooms").doc(room).set({
      'roolId': room,
      'offer': {
        "type": description.type,
        "sdp": description.sdp,
      }
    });

    // FirebaseFirestore.instance.collection("callQue").doc(widget.partnerid).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});
    // FirebaseFirestore.instance.collection("callQue").doc(widget.ownID).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});

    setState(() {
      widget.hasCallOffered = true;
    });

    FirebaseFirestore.instance
        .collection("rooms")
        .doc(room)
        .snapshots()
        .listen((event) async {
      if (event.exists && event.data()["answer"] != null) {
        //mkl

        print("remote des below");
        print(event.data()["answer"]);

        dynamic ss = event.data()["answer"];
        setState(() {
          widget.appbart = "gdr " + ss["type"];
        });
        RTCSessionDescription description =
            new RTCSessionDescription(ss["sdp"], ss["type"]);

        print("my suspect");
        print(description.toMap());
        print("my suspect ends");
        setState(() {
          widget.appbart = widget.appbart + ss["type"];
        });
        await _peerConnection.setRemoteDescription(description);
        setState(() {
          widget.appbart = "  remote des added ";
        });

        FirebaseFirestore.instance
            .collection("rooms")
            .doc(room)
            .collection("calleeCandidates")
            .snapshots()
            .listen((event) async {
          if (event.docs.length > 0) {
            setState(() {
              widget.appbart = widget.appbart +
                  " candidate side " +
                  event.docs.length.toString() +
                  " ";
            });
            for (int i = 0; i < event.docs.length; i++) {
              dynamic candidate = new RTCIceCandidate(
                event.docs[i].data()["candidate"],
                event.docs[i].data()["sdpMid"],
                event.docs[i].data()["sdpMLineIndex"],
              );
              print("one candidate added");

              // dynamic session = event.docs[i].data();

              //dynamic candidate = new RTCIceCandidate(session['candidate'], session['sdpMid'], session['sdpMLineIndex']);
              _peerConnection.addCandidate(candidate).then((value) {
                setState(() {
                  widget.appbart = widget.appbart + "  ca" + i.toString() + " ";
                });
              });
            }
          } else {
            setState(() {
              widget.appbart = widget.appbart + "  no candidate " + " ";
            });
          }
        });
      } else {
        setState(() {
          widget.appbart = widget.appbart + " no AF";
        });
      }
    });

    FirebaseFirestore.instance
        .collection("queu")
        .doc(widget.partnerPair)
        .update({"status": "screen updated "+DateTime.now().toIso8601String()}).then((value) {
      submitCallReceiverPush(widget.isCaller, widget.partnerid);
      submitCallReceiverPushReverse(widget.isCaller, widget.partnerid);
    });
    // print("writing my own des end of ");
  }

  void _createAnswer() async {
    RTCSessionDescription description = await _peerConnection
        .createAnswer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("for " + widget.ownID);
    print(json.encode(session));
    print("for " + widget.ownID + " ends");
    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    FirebaseFirestore.instance
        .collection("offer")
        .doc(widget.ownID)
        .set({"offer": json.encode(session)});
    _peerConnection.setLocalDescription(description);

    print("answer done");
    FirebaseFirestore.instance.collection("refresh").doc(widget.partnerid).set({
      "time": new DateTime.now().millisecondsSinceEpoch,
    });
  }

  void _createAnswerfb(String id) async {
    try {
      RTCSessionDescription description =
          await _peerConnection.createAnswer({'offerToReceiveVideo': 1});

      var session = parse(description.sdp);
      print("what is this");
      // print(json.encode(session));
      print("what is this end ");

      print(json.encode({
        'sdp': description.sdp.toString(),
        'type': description.type.toString(),
      }));
      print("trying start");
      // print(description.toMap().toString());

      _peerConnection.setLocalDescription(description);
      print("trying 2");
      //  print(_peerConnection.defaultSdpConstraints.toString());
      print("trying ends");
      // FirebaseFirestore.instance
      //     .collection("offer")
      //     .doc(widget.ownID)
      //     .set({"offer":json.encode(session)});
    } catch (e) {
      print("catch her e");
      print(e.toString());
    }
  }

  void _createAnswerFB(String id) async {
    RTCSessionDescription description =
        await _peerConnection.createAnswer({'offerToReceiveVideo': 1});

    var session = parse(description.sdp);
    //  print(json.encode(session));
    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    FirebaseFirestore.instance
        .collection("candidate")
        .doc(widget.ownID)
        .collection("d")
        .add({"candidate": json.encode(session)});

    //callerCandidates

    _peerConnection.setLocalDescription(description);

    print("addint candidate info ");

    //FirebaseFirestore.instance.collection("callQue").doc(makeRoomName(int.parse(widget.ownID), int.parse(widget.partnerid))).update({"candidate":session});
  }

  void _setRemoteDescription() async {
    String jsonString = sdpController.text;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
        new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');

    print("my suspect");
    print(description.toMap());
    print("my suspect ends");

    await _peerConnection.setRemoteDescription(description);
  }

  void _setRemoteDescriptionFB(String data) async {
    String jsonString = data;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
        new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');
    print("my suspect 1");
    print(description.toMap());
    print("my suspect 2 end");

    await _peerConnection.setRemoteDescription(description);

    print("now going for answer");
    //  _createAnswerfb(widget.ownID);

    _createAnswer();
  }

  void _setRemoteDescriptionNoAnswer(String data, String targetid) async {
    String jsonString = data;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
        new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');
    print("my suspect 3");
    print(description.toMap());
    print("my suspect 3 ends");

    await _peerConnection.setRemoteDescription(description);
    FirebaseFirestore.instance
        .collection("candidate")
        .doc(targetid)
        .collection("d")
        .get()
        .then((value) {
      for (int i = 0; i < value.docs.length; i++) {
        _addCandidateFB(value.docs[i].data()["candidate"]);
      }
      print("downloaded candidate");
    });
  }

  void _addCandidate() async {
    String jsonString = sdpController.text;
    dynamic session = await jsonDecode('$jsonString');
    print("my suspect 4");
    print(session['candidate']);
    print("my suspecr 5 ends");
    dynamic candidate = new RTCIceCandidate(
        session['candidate'], session['sdpMid'], session['sdpMlineIndex']);
    await _peerConnection.addCandidate(candidate);
  }

  void _addCandidateFB(String can) async {
    String jsonString = can;
    dynamic session = await jsonDecode('$jsonString');
    print("my suspect 4");
    print(session['candidate']);
    print("my suspecr 5 ends");
    dynamic candidate = new RTCIceCandidate(
        session['candidate'], session['sdpMid'], session['sdpMlineIndex']);
    await _peerConnection.addCandidate(candidate);
  }

  _createPeerConnection(String roomID) async {
    // Map<String, dynamic> configuration = {
    //   "iceServers": [
    //     {"url": "stun:stun.l.google.com:19302"},
    //   ]
    // };

    Map<String, dynamic> configuration333 = {
      'iceServers': [
        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=udp',
          'username':
              '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=udp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'username':
              '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:443?transport=tcp',
          'username':
              '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:443?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        }
      ]
    };

    Map<String, dynamic> configuration = {
      'iceServers': [
        {'urls': 'stun:stun.nextcloud.com:443'},
        {'urls': 'stun:relay.webwormhole.io'},
        {'urls': 'stun:stun.services.mozilla.com'},
        {'urls': 'stun:stun.l.google.com:19302'},
        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'urls': 'turn:86.11.136.36:3478',
          'credential': '%Welcome%4\$12345',
          'username': 'administrator'
        }
      ],
      "sdpSemantics": kIsWeb ? "plan-b" : "unified-plan"
    };
    Map<String, dynamic> configuration33 = {
      'iceServers': [
        {"url": "stun:stun.l.google.com:19302"},
        {
          'urls': 'turn:numb.viagenie.ca',
          'credential': '01620645499mkl',
          'username': 'saidur.shawon@gmail.com'
        }
      ]
    };
    Map<String, dynamic> configuration220 = {
      'iceServers': [
        {'urls': 'stun:stun.services.mozilla.com'},
        {'urls': 'stun:stun.l.google.com:19302'},
        {
          'urls': 'turn:numb.viagenie.ca',
          'credential': '01620645499mkl',
          'username': 'saidur.shawon@gmail.com'
        }
      ]
    };
    final Map<String, dynamic> offerSdpConstraints = {
      "mandatory": {
        "OfferToReceiveAudio": true,
        "OfferToReceiveVideo": widget.containsVideo,
      },
      "optional": [],
    };

    _localStream = await _getUserMedia();

//widget.containsVideo == false
//     if( widget.containsVideo == false){
//       for(int i = 0 ; i <_localStream.getVideoTracks().length ; i ++){
//         //_localStream.getVideoTracks()[i].(widget.isCameraOn);
//         _localStream.getVideoTracks()[i].enabled = !(_localStream.getVideoTracks()[i].enabled);
//       }
//       setState(() {
//         widget.isVideoMuted =  ! widget.isVideoMuted;
//       });
//     }

    RTCPeerConnection pc =
        await createPeerConnection(configuration, offerSdpConstraints);

    pc.onAddStream = (stream) {
      setState(() {
        widget.streams.add(stream);
        // widget.appbart = pc.getRemoteStreams().length.toString()+" "+ pc.getLocalStreams().length.toString()+" "+ pc.getRemoteStreams().first.getVideoTracks().toString()+" "+ pc.getLocalStreams().first.getVideoTracks().toString();
        // widget.appbart =widget.streams.length.toString();
      });
    };

    if (pc != null) {
      print(pc);
      print("yess error ");
    }
    if (kIsWeb) {
      // running on the web!
/*

      final Map<String, dynamic> mediaConstraintsScreen = {
        'audio': true,
        'video': {
          'width': {'ideal': 1280},
          'height': {'ideal': 720}
        }
      };
      MediaStream streamScreenShare = await navigator.mediaDevices.getDisplayMedia(mediaConstraintsScreen);
      await pc.addStream(streamScreenShare);

 */

      await  pc.addStream(_localStream);

    } else {
      _localStream.getTracks().forEach((track) {
        pc.addTrack(track, _localStream);
      });
    }

    pc.onAddStream = (e) {
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };

    pc.onRemoveStream = (e) {
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };

    pc.onIceCandidate = (e) {
      setState(() {
        //  widget.appbart = e.toString();
      });
      if (e.candidate != null) {
        print("supecrt 7");

        dynamic data = ({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMLineIndex': e.sdpMlineIndex,
        });

        if (ownCandidateID == null) {
          ownCandidateID = data;
        }
        FirebaseFirestore.instance
            .collection("rooms")
            .doc(roomID)
            .collection(
                widget.isCaller ? "callerCandidates" : "calleeCandidates")
            .add(data);

        print(json.encode({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMlineIndex': e.sdpMlineIndex,
        }));
        print("supecrt 7 end");
      }
    };
    pc.onSignalingState = (e) {
      if (pc.iceConnectionState ==
          RTCIceConnectionState.RTCIceConnectionStateConnected) {
        setState(() {
          widget.didOpositConnected = true;
        });
      }

      if (widget.didOpositConnected = true) {
        if (pc.iceConnectionState ==
            RTCIceConnectionState.RTCIceConnectionStateDisconnected) {
          _peerConnection.close().then((value) {
            _peerConnection.dispose().then((value) {
              Navigator.pop(context);
            });
          });
        }
      }

      setState(() {
        // widget.appbart = pc.iceConnectionState.toString();
      });

      if (pc.iceConnectionState == 'disconnected') {}
    };
    if (kIsWeb) {
      // running on the web!
      pc.onAddStream = (stream) async {
        print('addStream: ' + stream.id);
        _remoteRenderer.srcObject = stream;

        RTCVideoRenderer  _re = new RTCVideoRenderer();
        await _re.initialize();
        _re.srcObject = stream;
        setState(() {
          remoteRenderList.add(_re);

        });


      };
    } else {
      pc.onTrack = (event) {
        if (event.track.kind == 'video') {
          _remoteRenderer.srcObject = event.streams.first;
          // event.streams.first.getTracks().forEach((track) {
          //
          //
          // });

        }
      };
    }

    // ownOffer(pc);

    //
    return pc;
  }

  void _startRecording() async {
    // customStream.addTrack(_localStream.);

    // for(int i = 0 ; i < _localStream.getTracks() .length ; i ++){
    //   customStream.addTrack(_localStream.getTracks()[i]);
    // }

    // for(int i = 0 ; i < _remoteRenderer.srcObject.getTracks() .length ; i ++){
    //   customStream.addTrack(_remoteRenderer.srcObject.getTracks()[i]);
    // }

    _mediaRecorder = MediaRecorder();
    setState(() {
      widget.isRecording = true;
    });

    _mediaRecorder.startWeb(_remoteRenderer.srcObject);
  }

  void _stopRecording() async {
    // final objectUrl = await _mediaRecorder?.stop();
    // setState(() {
    //   _mediaRecorder = null;
    //   widget.isRecording = false;
    // });
    // print(objectUrl);
    // html.window.open(objectUrl, '_blank');
    // downloadFile(objectUrl);
  }

  void downloadFile(String url) {
    // html.AnchorElement anchorElement = new html.AnchorElement(href: url);
    // anchorElement.download = url;
    // anchorElement.click();
  }

  _getUserMedia() async {
    final Map<String, dynamic> mediaConstraints = {
      'audio': true,
      'video': widget.containsVideo
          ? {
              {
                'width': {'ideal': 1280},
                'height': {'ideal': 720}
              }
            }
          : false
    };


    MediaStream stream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
    //MediaStream streamScreenShare = await navigator.mediaDevices.getDisplayMedia(mediaConstraintsScreen);
    // MediaStream stream   = await navigator.mediaDevices.getDisplayMedia(mediaConstraints);

    // _localStream = stream;

    _localRenderer.srcObject = stream;
    // _localRenderer.mirror = true;

      RTCVideoRenderer  _re = new RTCVideoRenderer();
      await _re.initialize();
      _re.srcObject = stream;
      setState(() {
        remoteRenderList.add(_re);

      });



    // _peerConnection.addStream(stream);

    return stream;
  }

  SizedBox videoRenderers() => SizedBox(
      height: 500,
      child: Row(children: [
        Flexible(
          child: new Container(
              key: new Key("local"),
              margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              decoration: new BoxDecoration(color: Colors.black),
              child: new RTCVideoView(_localRenderer)),
        ),
        Flexible(
          child: new Container(
              key: new Key("remote"),
              margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              decoration: new BoxDecoration(color: Colors.black),
              child: new RTCVideoView(_remoteRenderer)),
        )
      ]));

  Widget screenView() {
    return Center(
      child: Container(
        color: Colors.black,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            Align(
                alignment: Alignment.bottomCenter,
                child: new RTCVideoView(
                  _remoteRenderer,
                  objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                )),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 100,
                color: Color.fromARGB(127, 0, 0, 0),
                child: Center(
                  child: Container(
                    width: 300,
                    height: 100,
                    child: Center(
                      child: Row(
                        children: [
                          // Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: FloatingActionButton(
                          //
                          //     onPressed: () {
                          //       if (widget.isCaller == true) {
                          //         setState(() {
                          //           widget.callerID = widget.ownID;
                          //         });
                          //         try {
                          //           _createOffer();
                          //         } catch (e) {
                          //           setState(() {
                          //             widget.appbart = "One exxecption from catch";
                          //           });
                          //           print("One exxecption from catch");
                          //           print(e.toString());
                          //         }
                          //       } else {
                          //         setState(() {
                          //           widget.callerID = widget.partnerid;
                          //         });
                          //       }
                          //     },
                          //     child: Icon(Icons.audiotrack_outlined),
                          //   ),
                          // ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller
                                  ? Colors.redAccent
                                  : Colors.greenAccent,
                              onPressed: () {
                                setState(() {
                                  widget.isScreenSharing = !widget.isScreenSharing;
                                });
                                handelScreenShaing();

                              },
                              child: Icon(widget.isScreenSharing
                                  ? Icons.screen_share
                                  : Icons.stop_screen_share),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller
                                  ? Colors.redAccent
                                  : Colors.greenAccent,
                              onPressed: () {
                                for (int i = 0;
                                    i < _localStream.getAudioTracks().length;
                                    i++) {
                                  //_localStream.getVideoTracks()[i].(widget.isCameraOn);
                                  _localStream.getAudioTracks()[i].enabled =
                                      !(_localStream
                                          .getAudioTracks()[i]
                                          .enabled);
                                }
                                setState(() {
                                  widget.isAudioMuted = !widget.isAudioMuted;
                                });
                              },
                              child: Icon(widget.isAudioMuted
                                  ? Icons.volume_off
                                  : Icons.volume_up_rounded),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller
                                  ? Colors.redAccent
                                  : Colors.greenAccent,
                              onPressed: () {
                                try {
                                  _peerConnection.close().then((value) {
                                    _peerConnection.dispose().then((value) {
                                      Navigator.pop(context);
                                    });
                                  });
                                } catch (e) {
                                  Navigator.pop(context);
                                }
                              },
                              child: Icon(Icons.call_end),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller
                                  ? Colors.redAccent
                                  : Colors.greenAccent,
                              onPressed: () async {
                                for (int i = 0;
                                    i < _localStream.getVideoTracks().length;
                                    i++) {
                                  //_localStream.getVideoTracks()[i].(widget.isCameraOn);
                                  _localStream.getVideoTracks()[i].enabled =
                                      !(_localStream
                                          .getVideoTracks()[i]
                                          .enabled);
                                }
                                setState(() {
                                  widget.isVideoMuted = !widget.isVideoMuted;
                                  widget.containsVideo = !widget.isVideoMuted;
                                  // asdasd
                                });

                                setState(() async {
                                  // _localStream = await _getUserMedia();
                                });

                                //initWorkLoad();
                              },
                              child: Icon(widget.isVideoMuted
                                  ? Icons.videocam_off_outlined
                                  : Icons.videocam),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller
                                  ? Colors.redAccent
                                  : Colors.greenAccent,
                              onPressed: () {
                                // _startRecording();
                                widget.isRecording == true
                                    ? _stopRecording()
                                    : _startRecording();
                              },
                              child: Icon(widget.isRecording == true
                                  ? Icons.fiber_manual_record_rounded
                                  : Icons.fiber_manual_record_outlined),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              right: 5,
              top: 5,
              child: Container(
                height: MediaQuery.of(context).size.height / 6,
                width: MediaQuery.of(context).size.width / 6,
                child: Container(
                    key: new Key("local"),
                    margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
                    decoration: new BoxDecoration(color: Colors.black),
                    child: new RTCVideoView(
                      _localRenderer,
                      objectFit:
                          RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                    )),
              ),
            ),

            Align(
                alignment: Alignment.topLeft,
                child: Container(
                  height: 106,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: remoteRenderList.length,
                    itemBuilder: (context, index) {
                      return Container(
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Container(
                            width: 100,
                            height: 100,
                            child: new RTCVideoView(remoteRenderList[index],objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,),
                           // child: new RTCVideoView( remoteRenderList[index],),
                          ),
                        ),
                      );
                    },
                  ),
                )),


          ],
        ),
      ),
    );
  }

  Row offerAndAnswerButtons() =>
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
        new RaisedButton(
          // onPressed: () {
          //   return showDialog(
          //       context: context,
          //       builder: (context) {
          //         return AlertDialog(
          //           content: Text(sdpController.text),
          //         );
          //       });
          // },
          // onPressed: _createOffer,
          child: Text('Offer'),
          color: Colors.amber,
        ),
        RaisedButton(
          onPressed: _createAnswer,
          child: Text('Answer'),
          color: Colors.amber,
        ),
      ]);

  Row sdpCandidateButtons() =>
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
        RaisedButton(
          onPressed: _setRemoteDescription,
          child: Text('Set Remote Desc'),
          color: Colors.amber,
        ),
        RaisedButton(
          onPressed: _addCandidate,
          child: Text('Add Candidate'),
          color: Colors.amber,
        )
      ]);

  Padding sdpCandidatesTF() => Padding(
        padding: const EdgeInsets.all(16.0),
        child: TextField(
          controller: sdpController,
          keyboardType: TextInputType.multiline,
          maxLines: 4,
          maxLength: TextField.noMaxLength,
        ),
      );

  @override
  Widget build(BuildContext context) {
    // return Scaffold(body: Text(widget.ownID+"  "+widget.partnerid+"  "+widget.isCaller.toString()),);

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          appBar: AppBar(title: Text(widget.appbart),),
          // appBar: AppBar(title: Text(widget.ownID+"  "+widget.partnerid+"  "+widget.isCaller.toString()),),
          backgroundColor: Colors.black,
          body: screenView()),
    );
  }

  void submitCallReceiverPush(bool isCaller, String partnerid) {
    if (isCaller != null && partnerid != null) {
      if (true) {
        Timer.periodic(Duration(milliseconds: 500), (timer) {
          if (mounted) {
            try {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .update({"time": new DateTime.now().millisecondsSinceEpoch});
            } catch (e) {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .set({"time": new DateTime.now().millisecondsSinceEpoch});
            }
          } else
            timer.cancel();
        });
      }
    } else {
      // Navigator.pop(context);
    }
  }

  void submitCallReceiverPushReverse(bool isCaller, String partnerid) {
    if (isCaller != null && partnerid != null) {
      if (true) {
        Timer.periodic(Duration(milliseconds: 500), (timer) {
          if (mounted) {
            try {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .set({"time": new DateTime.now().millisecondsSinceEpoch});
            } catch (e) {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .update({"time": new DateTime.now().millisecondsSinceEpoch});
            }
          } else
            timer.cancel();
        });
      }
    } else {
      // Navigator.pop(context);
    }
  }

  void submitCallEngaggePush(String ownID) {
    Timer.periodic(Duration(milliseconds: 1000), (timer) {
      if (mounted) {
        try {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .set({"time": new DateTime.now().millisecondsSinceEpoch});
        } catch (e) {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .update({"time": new DateTime.now().millisecondsSinceEpoch});
        }
      } else
        timer.cancel();
    });
  }

  void submitCallEngaggePushReverse(String ownID) {
    Timer.periodic(Duration(milliseconds: 1000), (timer) {
      if (mounted) {
        try {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .update({"time": new DateTime.now().millisecondsSinceEpoch});
        } catch (e) {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .set({"time": new DateTime.now().millisecondsSinceEpoch});
        }
      } else
        timer.cancel();
    });
  }

  void initWorkLoad(String roomId) {
    initRenderers();
    _createPeerConnection(roomId).then((pc) {
      _peerConnection = pc;

      if (widget.isCaller == true) {
        _createOffer(roomId);
      } else {
        lookForOffer(roomId);
      }

      // ownOffer();
/*
      Future.delayed(Duration(seconds: 2), () {
        for (int i = 0; i < 1; i ++) {
          Future.delayed(Duration(seconds: 1 + (i)), () {
            setState(() {
              // widget.appbart = "going one round " + i.toString();
            });
            print("going one round");
            if (widget.isCaller == true) {
              setState(() {
                widget.callerID = widget.ownID;
              });
              try {
               _createOffer(roomId);
              } catch (e) {
                setState(() {
                  // widget.appbart = "One exxecption from catch";
                });
                print("One exxecption from catch");
                print(e.toString());
              }
            } else {
              setState(() {
                widget.callerID = widget.partnerid;
              });
            }
          });
        }
      });
      */
    });
  }
  void initWorkLoadUOdate(String roomId) {
    _createOfferUpdated(roomId);
  }
  void lookForOffer(String roomId) async {
    FirebaseFirestore.instance
        .collection("rooms")
        .doc(roomId)
        .get()
        .then((event) async {
      if (event.exists && event.data()["offer"] != null) {
        //mkl
        setState(() {
          widget.appbart = " offer fo";
        });

        print("remote des below");
        print(event.data()["offer"]);

        dynamic offer = event.data()["offer"];
        setState(() {
          widget.appbart = "gdr " + offer["type"];
        });

        RTCSessionDescription description =
            new RTCSessionDescription(offer["sdp"], offer["type"]);

        print("my suspect");
        // print(description.toMap());
        print("my suspect ends");

        await _peerConnection.setRemoteDescription(description);
        setState(() {
          widget.appbart = "remote des added ";
        });

        setState(() {
          widget.appbart = widget.appbart + " answering";
        });
        RTCSessionDescription descriptionLocal = await _peerConnection
            .createAnswer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});
        setState(() {
          widget.appbart = widget.appbart + " anser done";
        });
        //var session = parse(description.sdp);
        print("cerate off");
        // print(json.encode(session));
        _offer = false;

        // print(json.encode({
        //       'sdp': description.sdp.toString(),
        //       'type': description.type.toString(),
        //     }));
        //FirebaseFirestore.instance.collection(widget.ownID).add(session);
        // print("writing my own des");

        await _peerConnection.setLocalDescription(descriptionLocal);
        setState(() {
          widget.appbart = " set ld done";
        });
        await FirebaseFirestore.instance
            .collection("rooms")
            .doc(roomId)
            .update({
          'roolId': roomId,
          'answer': {
            "type": descriptionLocal.type,
            "sdp": descriptionLocal.sdp,
          }
        });

        setState(() {
          widget.hasCallOffered = true;
        });

        FirebaseFirestore.instance
            .collection("rooms")
            .doc(roomId)
            .collection("callerCandidates")
            .get()
            .then((event) {
          if (event.docs.length > 0) {
            setState(() {
              widget.appbart =
                  " candidate side " + event.docs.length.toString() + " ";
            });

            for (int i = 0; i < event.docs.length; i++) {
              dynamic candidate = new RTCIceCandidate(
                event.docs[i].data()["candidate"],
                event.docs[i].data()["sdpMid"],
                event.docs[i].data()["sdpMLineIndex"],
              );
              print("one candidate added");

              // dynamic session = event.docs[i].data();

              //dynamic candidate = new RTCIceCandidate(session['candidate'], session['sdpMid'], session['sdpMLineIndex']);
              _peerConnection.addCandidate(candidate).then((value) {});
            }
          } else {
            setState(() {
              widget.appbart = widget.appbart + "  no candidate " + " ";
            });
          }
        });
      } else {
        setState(() {
          widget.appbart = widget.appbart + " no offer";
        });
      }
    });

    //FirebaseFirestore.instance.collection("queu").doc(widget.partnerPair).set({"room":room});
  }

  void handelScreenShaing() async{
    final Map<String, dynamic> mediaConstraintsScreen = {
      'audio': true,
      'video': {
        'width': {'ideal': 1280},
        'height': {'ideal': 720}
      }
    };
    MediaStream streamScreenShare = await navigator.mediaDevices.getDisplayMedia(mediaConstraintsScreen);
    await _peerConnection.addStream(streamScreenShare);


    initWorkLoadUOdate(widget.room);



  }
}

String makeRoomName(int one, int two) {
  if (one > two)
    return "" + one.toString() + "-" + two.toString();
  else
    return "" + two.toString() + "-" + one.toString();
}

class Login extends StatefulWidget {
  String ownID, partnerid;

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          color: Colors.white,
          child: Container(
            height: 250,
            width: 300,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: "Your Name",
                        contentPadding: EdgeInsets.all(10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          widget.ownID = value;
                        });
                      },
                    ),
                  ),
                ),
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: "partner Name",
                        contentPadding: EdgeInsets.all(10),
                      ),
                      onChanged: (value) {
                        setState(() {
                          widget.partnerid = value;
                        });
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                    onPressed: () {
                      // FirebaseFirestore.instance
                      //     .collection("refresh")
                      //     .doc(widget.ownID)
                      //     .delete();
                      // FirebaseFirestore.instance
                      //     .collection("refresh")
                      //     .doc(widget.partnerid)
                      //     .delete();
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(builder: (context) => MyWebCall(widget.ownID,widget.partnerid)),
                      // );
                    },
                    child: Text("Login"),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainHomePage extends StatefulWidget {
  @override
  _MainHomePageState createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Row(
          children: [
            Container(
              width: 300,
              height: MediaQuery.of(context).size.height,
            )
          ],
        ),
      ),
    );
  }
}
