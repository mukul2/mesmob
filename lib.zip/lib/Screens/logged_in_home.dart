import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:audioplayers/audioplayers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:maulajimessenger/call/WebCallingSimple.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Home extends StatefulWidget {
  int selectedTabMenu = 0;

  bool isSearchModeOn = true;

  int selectedItem = 0;
  String partnerId;

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;
  dynamic chatBody;
  SharedPreferences sharedPreferences;
  bool showMobileView = false;

  bool shouldShowIncomming = false;
  bool isRingTonePlaying = false;

  Home({
    Key key,
    @required this.auth,
    @required this.firestore,
    @required this.sharedPreferences,
  }) : super(key: key);

  @override
  _State createState() => _State();
}

class _State extends State<Home> {
  bool audioVolume = true;

  final GlobalKey _menuKey = new GlobalKey();
  TextEditingController searchController = new TextEditingController();
  AudioPlayer audioPlayer;

  playLocal() async {
    // audioPlayer.resume();

    if (widget.isRingTonePlaying == false) {
      setState(() {
        widget.isRingTonePlaying = true;
      });
      audioPlayer.resume();
      setState(() {
        widget.isRingTonePlaying = true;
      });
    }
  }

  initAudio() async {
    audioPlayer = await AudioPlayer(mode: PlayerMode.LOW_LATENCY);
    if (kIsWeb) {
      await audioPlayer.setUrl("assets/assets/skype_ringtone.mp3",
          isLocal: true);
    } else {
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/assets/skype_ringtone.mp3');
      // audioPlayer.se
      // await audioPlayer.setUrl("assets/skype_ringtone.mp3",isLocal: true);
      await audioPlayer.setUrl(file.path, isLocal: true);
    }

    // await audioPlayer.setUrl("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3");
    await audioPlayer.setReleaseMode(ReleaseMode.STOP);
  }

  @override
  void initState() {
    initAudio();
    // TODO: implement initState
    super.initState();
    //call income listener
    if (true) {
      Timer.periodic(Duration(milliseconds: 1000), (timer) {
        if (mounted) {
          widget.firestore
              .collection("incall")
              .doc(widget.auth.currentUser.uid)
              .get()
              .then((value) {
            if (value.exists) {
              if ((value.data()["time"] + 2000) >
                  DateTime.now().millisecondsSinceEpoch) {
                audioPlayer.pause();

                if (widget.isRingTonePlaying == true) {
                  setState(() {
                    widget.isRingTonePlaying = false;
                  });
                }
                if (widget.shouldShowIncomming == true) {
                  setState(() {
                    widget.shouldShowIncomming = false;
                  });
                }
              } else {
                widget.firestore
                    .collection("incomming")
                    .doc(widget.auth.currentUser.uid)
                    .get()
                    .then((value) {
                  if (value.exists) {
                    if ((value.data()["time"] + 2000) >
                        DateTime.now().millisecondsSinceEpoch) {
                      widget.firestore
                          .collection("callQue")
                          .doc(widget.auth.currentUser.uid)
                          .get()
                          .then((valueCaller) {
                        if (audioVolume) {
                          playLocal();
                        }

                        if (widget.shouldShowIncomming == false) {
                          setState(() {
                            widget.shouldShowIncomming = true;
                            widget.partnerId = valueCaller.data()["caller"];
                          });
                        }
                      });
                    } else {
                      audioPlayer.pause();
                      if (widget.isRingTonePlaying == true) {
                        setState(() {
                          widget.isRingTonePlaying = false;
                        });
                      }
                      if (widget.shouldShowIncomming == true) {
                        setState(() {
                          widget.shouldShowIncomming = false;
                        });
                      }
                    }
                  } else {
                    audioPlayer.pause();

                    if (widget.isRingTonePlaying == true) {
                      setState(() {
                        widget.isRingTonePlaying = false;
                      });
                    }
                    if (widget.shouldShowIncomming == true) {
                      setState(() {
                        widget.shouldShowIncomming = false;
                      });
                    }
                  }
                });
              }
            } else {
              widget.firestore
                  .collection("incomming")
                  .doc(widget.auth.currentUser.uid)
                  .get()
                  .then((value) {
                if (value.exists) {
                  if ((value.data()["time"] + 2000) >
                      DateTime.now().millisecondsSinceEpoch) {
                    widget.firestore
                        .collection("callQue")
                        .doc(widget.auth.currentUser.uid)
                        .get()
                        .then((valueCaller) {
                      if (audioVolume) {
                        playLocal();
                      }

                      if (widget.shouldShowIncomming == false)
                        setState(() {
                          widget.shouldShowIncomming = true;
                          widget.partnerId = valueCaller.data()["caller"];
                        });
                    });
                  } else {
                    audioPlayer.pause();

                    if (widget.isRingTonePlaying == true) {
                      setState(() {
                        widget.isRingTonePlaying = false;
                      });
                    }
                    if (widget.shouldShowIncomming == true) {
                      setState(() {
                        widget.shouldShowIncomming = false;
                      });
                    }
                  }
                } else {
                  audioPlayer.pause();
                  if (widget.isRingTonePlaying == true) {
                    setState(() {
                      widget.isRingTonePlaying = false;
                    });
                  }
                  if (widget.shouldShowIncomming == true) {
                    setState(() {
                      widget.shouldShowIncomming = false;
                    });
                  }
                }
              });
            }
          });
        } else {
          audioPlayer.pause();
          if (widget.isRingTonePlaying == true) {
            setState(() {
              widget.isRingTonePlaying = false;
            });
          }
          if (widget.shouldShowIncomming == true) {
            setState(() {
              widget.shouldShowIncomming = false;
            });
          }
          timer.cancel();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width > 500) {
      setState(() {
        widget.showMobileView = false;
      });
    } else {
      setState(() {
        widget.showMobileView = true;
      });
    }

    return Scaffold(
      body: widget.shouldShowIncomming
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 90,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: FloatingActionButton(
                          onPressed: () {
                            String partnerID = widget.partnerId;
                            if (partnerID != null) {
                              initCallIntent("v", widget.auth.currentUser.uid,
                                  partnerID, false, widget.firestore, context);
                            }
                          },
                          child: Icon(
                            Icons.videocam_rounded,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: FloatingActionButton(
                          onPressed: () {
                            String partnerID = widget.partnerId;
                            if (partnerID != null) {
                              initCallIntent("a", widget.auth.currentUser.uid,
                                  partnerID, false, widget.firestore, context);
                            }
                          },
                          child: Icon(Icons.call, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            )
          : !widget.showMobileView
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    getFndList(),
                    //Divider(color: Colors.grey,height: 1,),

                    getBody(),
                  ],
                )
              : getFndList(),
    );
  }

  Widget getFndList() {
    final button = new PopupMenuButton(
      key: _menuKey,
      itemBuilder: (_) => <PopupMenuItem<String>>[
        new PopupMenuItem<String>(
            child: const Text('Profile'), value: 'profile'),
        new PopupMenuItem<String>(
            child: const Text('Group Meeting'), value: 'grp'),
        new PopupMenuItem<String>(child: const Text('Plain Web'), value: 'web'),
        new PopupMenuItem<String>(child: const Text('Logout'), value: 'logout'),
      ],
      onSelected: (String choice) {
        if (choice == "logout") {
          widget.auth.signOut();
        }
        // if (choice == "grp") {
        //   //GroupCall
        //   Navigator.push(
        //       context,
        //       MaterialPageRoute(
        //           builder: (context) =>  WillPopScope(
        //             onWillPop: () async => false,
        //             child: GroupCall(
        //                 room_id: "grp",
        //                 containsVideo: true,
        //                 ownID: "p"+widget.sharedPreferences.getString("patient_id"),
        //                 partnerid:"",
        //                 isCaller:
        //                 true,
        //                 firestore:
        //                 widget.firestore),
        //
        //           )));
        // }
        // if (choice == "web") {
        //   //GroupCall
        //   Navigator.push(
        //       context,
        //       MaterialPageRoute(
        //           builder: (context) =>  WillPopScope(
        //             onWillPop: () async => false,
        //             child: PlainWebCall(
        //                 containsVideo: true,
        //                 ownID:"p"+widget.sharedPreferences.getString("patient_id"),
        //                 partnerid:"d162",
        //                 isCaller:
        //                 true,
        //                 firestore:
        //                 widget.firestore),
        //
        //           )));
        // }
      },
    );
    return Container(
      height: MediaQuery.of(context).size.height,
      color: Color.fromARGB(255, 249, 252, 255),
      width: widget.showMobileView ? MediaQuery.of(context).size.width : 349,
      child: ListView(
        shrinkWrap: true,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 0, 8),
            child: Container(
              height: 50,
              child: Center(
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Center(
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: CircleAvatar(
                                  radius: 18,
                                  backgroundImage: widget
                                              .auth.currentUser.photoURL !=
                                          null
                                      ? NetworkImage(
                                          widget.auth.currentUser.photoURL,
                                        )
                                      : NetworkImage(
                                          "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),

                              // child: CircleAvatar(radius: 18,backgroundImage: NetworkImage("https://images-na.ssl-images-amazon.com/images/I/71Y2Ov9rHaL._SL1500_.jpg",)),
                            ),
                            Text(widget.auth.currentUser.displayName != null
                                ? widget.auth.currentUser.displayName
                                : "No Display Name"),

                            //Text(widget.sharedPreferences.get("uphoto")),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: button,
                    )
                  ],
                ),
              ),
            ),
          ),
          widget.isSearchModeOn == false
              ? Column(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          widget.isSearchModeOn = true;
                        });
                      },
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(7, 10, 7, 10),
                              child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(
                                            3.0) //                 <--- border radius here
                                        ),
                                  ),
                                  width: MediaQuery.of(context).size.width,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Row(
                                      children: [
                                        Center(child: Icon(Icons.search)),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              10, 0, 0, 0),
                                          child: Center(child: Text("Search")),
                                        ),
                                      ],
                                    ),
                                  )),
                            ),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 5, 0, 0),
                      child: Container(
                        height: 50,
                        child: Row(
                          children: [
                            Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.selectedTabMenu = 0;
                                      });
                                    },
                                    child: Column(
                                      children: [
                                        Icon(Icons.chat,
                                            color: widget.selectedTabMenu == 0
                                                ? Theme.of(context).primaryColor
                                                : Colors.grey),
                                        Center(
                                            child: Text(
                                          "Chat",
                                          style: TextStyle(
                                              color: widget.selectedTabMenu == 0
                                                  ? Theme.of(context)
                                                      .primaryColor
                                                  : Colors.grey),
                                        )),
                                      ],
                                    ))),
                            Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.selectedTabMenu = 1;
                                      });
                                    },
                                    child: Column(
                                      children: [
                                        Icon(Icons.call_outlined,
                                            color: widget.selectedTabMenu == 1
                                                ? Theme.of(context).primaryColor
                                                : Colors.grey),
                                        Center(
                                            child: Text(
                                          "Call",
                                          style: TextStyle(
                                              color: widget.selectedTabMenu == 1
                                                  ? Theme.of(context)
                                                      .primaryColor
                                                  : Colors.grey),
                                        )),
                                      ],
                                    ))),
                            Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        widget.selectedTabMenu = 2;
                                      });
                                    },
                                    child: Column(
                                      children: [
                                        Icon(Icons.contacts,
                                            color: widget.selectedTabMenu == 2
                                                ? Theme.of(context).primaryColor
                                                : Colors.grey),
                                        Center(
                                            child: Text(
                                          "Contacts",
                                          style: TextStyle(
                                              color: widget.selectedTabMenu == 2
                                                  ? Theme.of(context)
                                                      .primaryColor
                                                  : Colors.grey),
                                        )),
                                      ],
                                    ))),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 5, 0, 15),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: 1,
                        color: Colors.grey,
                      ),
                    ),
                    widget.selectedTabMenu == 0
                        ? StreamBuilder<QuerySnapshot>(
                            stream: widget.firestore
                                .collection("last")
                                .where("sender", isEqualTo: widget.auth.currentUser.uid)
                                .snapshots(),
                            builder: (context, projectSnapSender) {
                              List allHistory = [];
                              if (projectSnapSender.hasData) {
                                if (true || projectSnapSender.data.docs.length > 0)
                                  allHistory.addAll(projectSnapSender.data.docs);
                                return StreamBuilder<QuerySnapshot>(
                                    stream: widget.firestore
                                        .collection("last")
                                        .where("receiver",
                                            isEqualTo:
                                                widget.auth.currentUser.uid)
                                        .snapshots(),
                                    builder: (context, projectSnapReceiver) {
                                      if (projectSnapReceiver.hasData) {
                                        if (true|| projectSnapReceiver.data.docs.length > 0)
                                          allHistory.addAll(projectSnapSender.data.docs);
                                      } else {
                                        return Text("Please wait");
                                      }
                                      List filteredData = [];
                                      for (int i = 0;
                                          i < allHistory.length;
                                          i++) {
                                        if (true || allHistory[i].data()["sender"] !=
                                            widget.auth.currentUser.uid) {
                                          filteredData.add(allHistory[i]);
                                        }
                                        if (true || allHistory[i].data()["receiver"] !=
                                            widget.auth.currentUser.uid) {
                                          filteredData.add(allHistory[i]);
                                        }
                                      }
                                      return ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: (filteredData == null)
                                            ? 0
                                            : filteredData.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Container(
                                            child: new InkWell(
                                              onTap: () async {
                                                setState(() {
                                                  widget.chatBody =
                                                      filteredData[index]
                                                          .data();
                                                  widget.selectedItem = index;
                                                });
                                              },
                                              child: ListTile(
                                                tileColor:
                                                    widget.selectedItem == index
                                                        ? Color.fromARGB(
                                                            255, 206, 231, 255)
                                                        : Color.fromARGB(
                                                            255, 249, 252, 255),
                                                leading: CircleAvatar(
                                                    radius: 18,
                                                    backgroundImage: NetworkImage(
                                                        "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                                                // title: Text(filteredData[index].data()["receiver"]),
                                                title: getNameFromId(filteredData[index].data(),false),
                                                subtitle: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: Text("Sub title"),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    });
                              } else {
                                return Text("No Chat history");
                                return StreamBuilder<QuerySnapshot>(
                                    stream: widget.firestore
                                        .collection("last")
                                        .where("receiver",
                                            isEqualTo:
                                                widget.auth.currentUser.uid)
                                        .snapshots(),
                                    builder: (context, projectSnapReceiver) {
                                      if (projectSnapReceiver.hasData) {
                                        if (projectSnapReceiver
                                                .data.docs.length >
                                            0)
                                          allHistory.addAll(
                                              projectSnapSender.data.docs);
                                      } else {
                                        return Text("Please wait");
                                      }
                                      return ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: (allHistory == null)
                                            ? 0
                                            : allHistory.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Container(
                                            child: new InkWell(
                                              onTap: () async {
                                                setState(() {
                                                  widget.chatBody =
                                                      allHistory[index].data();
                                                  widget.selectedItem = index;
                                                });
                                              },
                                              child: ListTile(
                                                tileColor:
                                                    widget.selectedItem == index
                                                        ? Color.fromARGB(
                                                            255, 206, 231, 255)
                                                        : Color.fromARGB(
                                                            255, 249, 252, 255),
                                                leading: CircleAvatar(
                                                    radius: 18,
                                                    backgroundImage: NetworkImage(
                                                        "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                                                title: Text(allHistory[index]
                                                    .data()["receiver"]),
                                                subtitle: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: Text("Sub title"),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    });
                                ;
                              }
                            })
                        : (widget.selectedTabMenu == 1
                            ? Text("Ignor")
                            : Text("Ignor")),
                  ],
                )
              : Column(
                  children: [
                    Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                            Colors.blueAccent,
                            Colors.blue,
                            Colors.lightBlue,
                            Colors.lightBlue,
                          ],
                        )),
                        child: Container(
                          height: 60,
                          child: Stack(
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextFormField(
                                    controller: searchController,
                                    cursorColor: Colors.white,
                                    style: TextStyle(color: Colors.white),
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "Search People",
                                      hintStyle: TextStyle(color: Colors.white),
                                      contentPadding: EdgeInsets.all(10),
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  width: 40,
                                  height: 40,
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            searchController.text = "";
                                         //   widget.isSearchModeOn = false;
                                          });
                                        },
                                        child: Icon(
                                          Icons.close,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                    StreamBuilder<QuerySnapshot>(
                        stream: widget.firestore
                            .collection("users")
                            //.where("uid", isNotEqualTo:  widget.auth.currentUser.uid)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasData &&
                              snapshot.data.docs.length > 0) {
                            List filtereData = [];
                            for (int i = 0;
                                i < snapshot.data.docs.length;
                                i++) {
                              if (snapshot.data.docs[i].data()["uid"] !=
                                  widget.auth.currentUser.uid)
                                filtereData.add(snapshot.data.docs[i].data());
                            }
                            return ListView.builder(
                              shrinkWrap: true,
                              itemCount:
                                  (snapshot == null || snapshot.data == null)
                                      ? 0
                                      : filtereData.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: new InkWell(
                                    onTap: () async {
                                      setState(() {
                                        widget.chatBody = filtereData[index];
                                        widget.selectedItem = index;
                                      });
                                    },
                                    child: ListTile(
                                      tileColor:
                                          Color.fromARGB(255, 249, 252, 255),
                                      leading: CircleAvatar(
                                          radius: 18,
                                          backgroundImage: NetworkImage(
                                              "https://st.depositphotos.com/2101611/4338/v/600/depositphotos_43381243-stock-illustration-male-avatar-profile-picture.jpg")),
                                      title: Text(filtereData[index]["name"]),
                                      subtitle: Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Text("Send Message"),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          } else {
                            return Text("No Match");
                          }
                        }),
                    //searchController.text
                  ],
                ),
        ],
      ),
    );
  }

  Widget getBody() {
    TextEditingController controller = new TextEditingController();
    if (widget.chatBody == null) {
      return Container(
          height: MediaQuery.of(context).size.height,
          width: widget.showMobileView
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width - 350,
          child: Scaffold(
            body: Center(
              child: Text("Select a user to chat"),
            ),
          ));
    } else {
      return Container(
          height: MediaQuery.of(context).size.height,
          width: widget.showMobileView
              ? MediaQuery.of(context).size.width
              : MediaQuery.of(context).size.width - 350,
          child: Stack(
            children: [
              Positioned(
                  top: 70,
                  child: Container(
                    color: Colors.grey,
                    height: 0.5,
                    width: MediaQuery.of(context).size.width,
                  )),
              Container(
                height: 70,
                //  color:   Color.fromARGB(255,238, 246, 255),
                child: Center(
                    child: Stack(
                  children: [
                    Positioned(
                        left: 0,
                        top: 0,
                        bottom: 0,
                        child: Container(
                          width: 300,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                widget.chatBody["name"]!=null? Text(widget.chatBody["name"] == null ? "No user Name" : widget.chatBody["name"], style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                      fontSize: 20),
                                ):getNameFromId(widget.chatBody,true),
                                widget.chatBody["email"]!=null? Text(widget.chatBody["email"]):getEmailFromId(widget.chatBody),
                              ],
                            ),
                          ),
                        )),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        width: 130,
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Container(
                                width: 50,
                                child: InkWell(
                                  onTap: () async {
                                    String partnerID;
                                    if (widget.chatBody["uid"] != null) {
                                      partnerID = widget.chatBody["uid"];
                                      initCallIntent(
                                          "v",
                                          widget.auth.currentUser.uid,
                                          partnerID,
                                          true,
                                          widget.firestore,
                                          context);
                                    } else {
                                      if (widget.chatBody["sender"] ==
                                          widget.auth.currentUser.uid) {
                                        partnerID = widget.chatBody["receiver"];
                                      } else {
                                        partnerID = widget.chatBody["sender"];
                                      }
                                      initCallIntent(
                                          "v",
                                          widget.auth.currentUser.uid,
                                          partnerID,
                                          true,
                                          widget.firestore,
                                          context);
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    child: Card(
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(35.0),
                                      ),
                                      color: Color.fromARGB(255, 241, 241, 241),
                                      child: Icon(Icons.videocam_outlined),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Container(
                                width: 50,
                                child: InkWell(
                                  onTap: () async {
                                    String partnerID;
                                    if (widget.chatBody["uid"] != null) {
                                      partnerID = widget.chatBody["uid"];
                                      initCallIntent(
                                          "a",
                                          widget.auth.currentUser.uid,
                                          partnerID,
                                          true,
                                          widget.firestore,
                                          context);
                                    } else {
                                      if (widget.chatBody["sender"] ==
                                          widget.auth.currentUser.uid) {
                                        partnerID = widget.chatBody["receiver"];
                                      } else {
                                        partnerID = widget.chatBody["sender"];
                                      }
                                      initCallIntent(
                                          "a",
                                          widget.auth.currentUser.uid,
                                          partnerID,
                                          true,
                                          widget.firestore,
                                          context);
                                    }
                                  },
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    child: Card(
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(35.0),
                                      ),
                                      color: Color.fromARGB(255, 241, 241, 241),
                                      child: Icon(Icons.call),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                )),
              ),
              Positioned(
                  top: 75,
                  left: 0,
                  right: 0,
                  bottom: 70,
                  child: StreamBuilder<QuerySnapshot>(
                      stream: widget.firestore
                          .collection(createRoomName(
                              widget.auth.currentUser.uid,
                              widget.chatBody["sender"] != null
                                  ? (widget.chatBody["sender"] ==
                                          widget.auth.currentUser.uid
                                      ? widget.chatBody["receiver"]
                                      : widget.chatBody["sender"])
                                  : widget.chatBody["uid"]))
                          .orderBy("time")
                          .snapshots(),
                      builder: (BuildContext c,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasData && snapshot.data.size > 0) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                            child: ListView.builder(
                                // controller: scrollController,
                                shrinkWrap: true,
                                itemCount: snapshot.data == null
                                    ? 0
                                    : snapshot.data.size,
                                itemBuilder: (BuildContext context, int index) {
                                  return Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Stack(
                                      children: [
                                        Align(
                                          alignment: snapshot.data.docs[index]
                                                      .data()["sender"] ==
                                                  widget.auth.currentUser.uid
                                              ? Alignment.centerRight
                                              : Alignment.centerLeft,
                                          child: Padding(
                                            padding: const EdgeInsets.all(0.0),
                                            child: snapshot.data.docs[index]
                                                        .data()["sender"] ==
                                                    widget.auth.currentUser.uid
                                                ? Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment: snapshot
                                                                    .data
                                                                    .docs[index]
                                                                    .data()[
                                                                "sender"] ==
                                                            widget.auth
                                                                .currentUser.uid
                                                        ? CrossAxisAlignment.end
                                                        : CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0, 0, 5, 0),
                                                        child: Text(
                                                          DateFormat('hh:mm aa')
                                                              .format(DateTime
                                                                  .fromMillisecondsSinceEpoch(snapshot
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                          style: TextStyle(
                                                              fontSize: 12),
                                                        ),
                                                      ),
                                                      Card(
                                                        color: snapshot.data
                                                                        .docs[index]
                                                                        .data()[
                                                                    "sender"] ==
                                                                widget
                                                                    .auth
                                                                    .currentUser
                                                                    .uid
                                                            ? Colors.white
                                                            : Color.fromARGB(
                                                                255,
                                                                238,
                                                                246,
                                                                255),
                                                        child: Container(
                                                            child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: Text(snapshot
                                                                  .data
                                                                  .docs[index]
                                                                  .data()[
                                                              "message"]),
                                                        )),
                                                      ),
                                                    ],
                                                  )
                                                : Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      widget.chatBody["img"] ==
                                                              null
                                                          ? CircleAvatar(
                                                              radius: 10,
                                                            )
                                                          : CircleAvatar(
                                                              radius: 10,
                                                              backgroundImage:
                                                                  NetworkImage(
                                                                      widget.chatBody[
                                                                          "img"]),
                                                            ),
                                                      Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment: snapshot
                                                                        .data
                                                                        .docs[index]
                                                                        .data()[
                                                                    "sender"] ==
                                                                widget
                                                                    .auth
                                                                    .currentUser
                                                                    .uid
                                                            ? CrossAxisAlignment
                                                                .end
                                                            : CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    5, 0, 0, 0),
                                                            child: Text(
                                                              DateFormat(
                                                                      'hh:mm aa')
                                                                  .format(DateTime.fromMillisecondsSinceEpoch(snapshot
                                                                          .data
                                                                          .docs[
                                                                              index]
                                                                          .data()[
                                                                      "time"])),
                                                              style: TextStyle(
                                                                  fontSize: 12),
                                                            ),
                                                          ),
                                                          Card(
                                                            color: snapshot
                                                                            .data
                                                                            .docs[
                                                                                index]
                                                                            .data()[
                                                                        "sender"] ==
                                                                    widget
                                                                        .auth
                                                                        .currentUser
                                                                        .uid
                                                                ? Colors.white
                                                                : Color
                                                                    .fromARGB(
                                                                        255,
                                                                        238,
                                                                        246,
                                                                        255),
                                                            child: Container(
                                                                child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: Text(snapshot
                                                                      .data
                                                                      .docs[index]
                                                                      .data()[
                                                                  "message"]),
                                                            )),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                }),
                          );
                        } else {
                          return Center(
                            child: Text("Send your first message"),
                          );
                        }
                      })),
              Align(
                alignment: Alignment.bottomCenter,
                child: Stack(
                  children: [
                    Positioned(
                      bottom: 10,
                      left: 10,
                      right: 100,
                      child: Container(
                        height: 60,
                        child: Center(
                          child: Card(
                            elevation: 0,
                            color: Color.fromARGB(255, 238, 246, 255),
                            child: Container(
                              child: new TextField(
                                onSubmitted: (val) async {
                                  String room = createRoomName(
                                      widget.auth.currentUser.uid,
                                      widget.chatBody["sender"] != null
                                          ? (widget.chatBody["sender"] ==
                                                  widget.auth.currentUser.uid
                                              ? widget.chatBody["receiver"]
                                              : widget.chatBody["sender"])
                                          : widget.chatBody["uid"]);

                                  await widget.firestore
                                      .collection("last")
                                      .doc(room)
                                      .set({
                                    "message": val,
                                    "sender": widget.auth.currentUser.uid,
                                    "receiver":
                                        widget.chatBody["sender"] != null
                                            ? (widget.chatBody["sender"] ==
                                                    widget.auth.currentUser.uid
                                                ? widget.chatBody["receiver"]
                                                : widget.chatBody["sender"])
                                            : widget.chatBody["uid"]
                                  });

                                  await widget.firestore.collection(room).add({
                                    "time":
                                        DateTime.now().millisecondsSinceEpoch,
                                    "message": val,
                                    "sender": widget.auth.currentUser.uid,
                                    "receiver":
                                        widget.chatBody["sender"] != null
                                            ? (widget.chatBody["sender"] ==
                                                    widget.auth.currentUser.uid
                                                ? widget.chatBody["receiver"]
                                                : widget.chatBody["sender"])
                                            : widget.chatBody["uid"]
                                  });
                                  controller.clear();
                                },
                                controller: controller,
                                textAlign: TextAlign.left,
                                decoration: new InputDecoration(
                                  hintText: "Type your message",
                                  contentPadding: EdgeInsets.all(10),
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      right: 10,
                      child: Container(
                        height: 60,
                        width: 100,
                        child: Center(
                          child: new InkWell(
                            onTap: () async {
                              //widget.room
                              String text = controller.text;
                              if (text.length > 0) {
                                String room = createRoomName(
                                    widget.auth.currentUser.uid,
                                    widget.chatBody["sender"] != null
                                        ? (widget.chatBody["sender"] ==
                                                widget.auth.currentUser.uid
                                            ? widget.chatBody["receiver"]
                                            : widget.chatBody["sender"])
                                        : widget.chatBody["uid"]);

                                await widget.firestore
                                    .collection("last")
                                    .doc(room)
                                    .set({
                                  "message": text,
                                  "sender": widget.auth.currentUser.uid,
                                  "receiver": widget.chatBody["sender"] != null
                                      ? (widget.chatBody["sender"] ==
                                              widget.auth.currentUser.uid
                                          ? widget.chatBody["receiver"]
                                          : widget.chatBody["sender"])
                                      : widget.chatBody["uid"]
                                });

                                await widget.firestore.collection(room).add({
                                  "time": DateTime.now().millisecondsSinceEpoch,
                                  "message": text,
                                  "sender": widget.auth.currentUser.uid,
                                  "receiver": widget.chatBody["sender"] != null
                                      ? (widget.chatBody["sender"] ==
                                              widget.auth.currentUser.uid
                                          ? widget.chatBody["receiver"]
                                          : widget.chatBody["sender"])
                                      : widget.chatBody["uid"]
                                });
                                controller.clear();
                              }
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Icon(
                                Icons.send,
                                color: Colors.blue,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ));
    }
  }

  String createRoomName(String uid, partner) {
    final List<String> ids = <String>[uid, partner];
    ids.sort();
    return ids.first + "-" + ids.last;
  }

  // Future<void> _handleCameraAndMic() async {
  //   await PermissionHandler().requestPermissions(
  //     [PermissionGroup.camera, PermissionGroup.microphone],
  //   );
  // }
  void initCallIntent(String callTYpe, String ownid, String partner,
      bool isCaller, FirebaseFirestore firestore, BuildContext context) async {
    if (!kIsWeb) {
      // await _handleCameraAndMic();
    }

    await firestore.collection("callQue").doc(ownid).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("callQue").doc(partner).set({
      "caller": isCaller ? ownid : partner,
      "target": isCaller ? partner : ownid
    });
    await firestore.collection("refresh").doc(ownid).delete();
    await firestore.collection("refresh").doc(partner).delete();

    List ids = [];
    ids.add(ownid);
    ids.add(partner);
    ids.sort();

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => WillPopScope(
                  onWillPop: () async => false,
                  child: SimpleWebCall(
                    containsVideo: callTYpe == "a" ? false : true,
                    ownID: ownid,
                    partnerid: partner,
                    isCaller: isCaller,
                    firestore: firestore,
                    partnerPair: ids.first + "-" + ids.last,
                  ),
                )));
  }

 Widget getNameFromId(dynamic body,bool style) {
 return  FutureBuilder<
       QuerySnapshot>(
       future: widget.firestore
           .collection("users")
           .where("uid",
           isEqualTo:body["receiver"]==widget
               .auth
               .currentUser
               .uid?body["sender"]:body["receiver"])
           .get(),
       builder: (context,
           snapuserInfo) {
         if(snapuserInfo.hasData){
           return Text(snapuserInfo.data.docs.first.data()["name"],style: style?TextStyle(
               fontWeight: FontWeight.bold,
               color: Colors.black,
               fontSize: 20):TextStyle(),);
         }else{
           return Text("Please wait");
         }
       });
 }

  Widget getEmailFromId(body) {
    return  FutureBuilder<
        QuerySnapshot>(
        future: widget.firestore
            .collection("users")
            .where("uid",
            isEqualTo:body["receiver"]==widget
                .auth
                .currentUser
                .uid?body["sender"]:body["receiver"])
            .get(),
        builder: (context,
            snapuserInfo) {
          if(snapuserInfo.hasData){
            return Text(snapuserInfo.data.docs.first.data()["email"],style:TextStyle(),);
          }else{
            return Text("No Email address found");
          }
        });
  }
}
