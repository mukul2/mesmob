import 'dart:async';
import 'dart:convert';
// import 'dart:html' as html;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:maulajimessenger/call/CallUnitGrp.dart';
import 'dart:math';
// import 'package:flutter_webrtc/web/rtc_session_description.dart';

import 'package:sdp_transform/sdp_transform.dart';



Future<FirebaseApp> customInitialize() {
  return Firebase.initializeApp();
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      home: FutureBuilder(
        // Initialize FlutterFire:
        //  future: Firebase.initializeApp(),
        future: customInitialize(),
        builder: (context, snapshot) {
          // Check for errors
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                child: Text("Error"),
              ),
            );
          }

          // Once complete, show your application
          if (snapshot.connectionState == ConnectionState.done) {
            //  FirebaseFirestore.instance.collection("9feb").add({"data":"data7"});

            return MyApp();
          }

          // Otherwise, show something whilst waiting for initialization to complete
          return const Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        },
      ),
    );
  }
}

var ownCandidateID = null;

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Login(),
    );
  }
}

class GroupCall extends StatefulWidget {

  Widget grids = Center(child: Text("Please wait"),);
  List<Widget> allWidgs = [];

  Wrap screen ;
  Widget self;


  List streams = [] ;
  dynamic ownCandidateID;
  String appbart = "";

  bool isAudioMuted = false ;
  bool isVideoMuted = false ;

  bool hasCallOffered = false;

  String callerID = "0";

  String ownID = "0";
  String partnerid = "0";
  bool isCaller = false;
  bool isRecording = false ;
  FirebaseFirestore firestore;

  bool didOpositConnected = false ;

  dynamic offer;
  String title = "t";
  String room_id = "";

  List<String>peerIds = [] ;

  bool containsVideo ;

  GroupCall({this.ownID, this.partnerid, this.isCaller, this.firestore,this.containsVideo,this.room_id});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<GroupCall> with WidgetsBindingObserver {
  bool started = false ;
  Timer timer;
  bool _offer = false;
  List<RTCPeerConnection> allPeers = [];
  RTCPeerConnection _peerConnection;
  MediaStream _localStream;
  RTCVideoRenderer _localRenderer = new RTCVideoRenderer();
  RTCVideoRenderer _remoteRenderer = new RTCVideoRenderer();

  MediaRecorder _mediaRecorder;
  bool get _isRec => _mediaRecorder != null;
  final sdpController = TextEditingController();
  List<RTCVideoRenderer> remoteRenderList = [];
  @override
  dispose() {
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    sdpController.dispose();
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    setState(() {
      widget.grids = Wrap(
        children: widget.allWidgs,
      );
    });

    widget.partnerid.replaceAll("dd", "d");
    widget.partnerid.replaceAll("pp", "p");

    widget.ownID.replaceAll("dd", "d");
    widget.ownID.replaceAll("pp", "p");

    if (widget.isCaller == true) {
      setState(() {
        widget.callerID = widget.ownID;
      });

    } else {
      setState(() {
        widget.callerID = widget.partnerid;
      });
    }
    //initRenderers();
    if(true ) initWorkLoad();


    super.initState();

    widget.partnerid.replaceAll("dd", "d");
    widget.partnerid.replaceAll("pp", "p");

    widget.ownID.replaceAll("dd", "d");
    widget.ownID.replaceAll("pp", "p");

    //  submitCallReceiverPush(widget.isCaller,widget.partnerid);
    //submitCallReceiverPushReverse(widget.isCaller,widget.partnerid);

    // submitCallEngaggePush(widget.ownID);
    //submitCallEngaggePushReverse(widget.ownID);

    //listen for other party call reject status
/*
    if(widget.isCaller){
      if(widget.didOpositConnected){
        widget.firestore.collection("incall").doc(widget.partnerid).get().then((value) {

          if(value.exists  ){
            if((value.data()["time"] +5000 ) > DateTime.now().millisecondsSinceEpoch){


            }else{
              Navigator.pop(context);
            }

          }else{
            Navigator.pop(context);

          }
        });
      }


    }else{
      widget.firestore.collection("incall").doc(widget.partnerid).get().then((value) {

        if(value.exists  ){
          if((value.data()["time"] +5000 ) > DateTime.now().millisecondsSinceEpoch){


          }else{
            Navigator.pop(context);
          }

        }else{
          Navigator.pop(context);

        }
      });
    }

 */



/*
    timer = Timer.periodic(Duration(seconds: 1), (Timer t) {
      if (widget.isCaller == true) {
        widget.firestore
            .collection("online")
            .doc(widget.ownID)
            .update({"calltime": new DateTime.now().millisecondsSinceEpoch});



      } else {
        widget.firestore
            .collection("online")
            .doc(widget.partnerid)
            .update({"calltime": new DateTime.now().millisecondsSinceEpoch});
      }
    });

 */
    //initRenderers();
    // setState(() {
    //   widget.allWidgs.add(Padding(
    //     padding: const EdgeInsets.all(8.0),
    //     child: Card(color: Colors.white,shape: RoundedRectangleBorder(
    //       borderRadius: BorderRadius.circular(0.0),
    //     ),
    //       child:  Container(
    //         width: 320,height: 240,
    //         child:Center(child: Text("You"),),
    //       ),
    //     ),
    //   ));
    // });


    setState(() {

      widget.self =Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(color: Colors.white,shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0.0),
        ),
          child:  Container(
            width: 320,height: 240,
            child:Center(child: Text(widget.ownID),),
          ),
        ),
      );

    });
  }

  initRenderers() async {
    await _localRenderer.initialize();
    // await _remoteRenderer.initialize();
    _localStream = await _getUserMedia();
    _localRenderer.srcObject = _localStream;

    setState(() {

      widget.self =Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(color: Colors.white,shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0.0),
        ),
          child:  Container(
            width: 320,height: 240,
            child:RTCVideoView(_localRenderer),
          ),
        ),
      );

    });

  }

  void _createOffer() async {
    RTCSessionDescription description = await _peerConnection
        .createOffer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("cerate off");
    print(json.encode(session));
    _offer = true;

    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    //FirebaseFirestore.instance.collection(widget.ownID).add(session);
    // print("writing my own des");

    _peerConnection.setLocalDescription(description);
    FirebaseFirestore.instance
        .collection("offer")
        .doc(widget.ownID)
        .set({"offer": json.encode(session)});

    // FirebaseFirestore.instance.collection("callQue").doc(widget.partnerid).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});
    // FirebaseFirestore.instance.collection("callQue").doc(widget.ownID).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});

    FirebaseFirestore.instance.collection("refresh").doc(widget.partnerid).set({
      "time": new DateTime.now().millisecondsSinceEpoch,

    });

    setState(() {
      widget.hasCallOffered = true;
    });
    // print("writing my own des end of ");
  }
  void _createOfferGrp(String caller,String receiver) async {
    RTCSessionDescription description = await _peerConnection
        .createOffer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("cerate off");
    print(json.encode(session));
    _offer = true;

    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    //FirebaseFirestore.instance.collection(widget.ownID).add(session);
    // print("writing my own des");

    _peerConnection.setLocalDescription(description);
    FirebaseFirestore.instance.collection(widget.room_id).doc(caller)
        .collection("offer")
        .doc(widget.ownID)
        .set({"offer": json.encode(session)});

    // FirebaseFirestore.instance.collection("callQue").doc(widget.partnerid).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});
    // FirebaseFirestore.instance.collection("callQue").doc(widget.ownID).set(
    //     {"caller": widget.ownID, "target": widget.partnerid});



    setState(() {
      widget.hasCallOffered = true;
    });
    // print("writing my own des end of ");
  }
  void _createAnswer() async {
    RTCSessionDescription description = await _peerConnection
        .createAnswer({'offerToReceiveVideo': 1, 'offerToReceiveAudio': 1});

    var session = parse(description.sdp);
    print("for " + widget.ownID);
    print(json.encode(session));
    print("for " + widget.ownID + " ends");
    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    FirebaseFirestore.instance
        .collection("offer")
        .doc(widget.ownID)
        .set({"offer": json.encode(session)});
    _peerConnection.setLocalDescription(description);

    print("answer done");
    FirebaseFirestore.instance.collection("refresh").doc(widget.partnerid).set({
      "time": new DateTime.now().millisecondsSinceEpoch,

    });
  }

  void _createAnswerfb(String id) async {
    try {
      RTCSessionDescription description =
      await _peerConnection.createAnswer({'offerToReceiveVideo': 1});

      var session = parse(description.sdp);
      print("what is this");
      // print(json.encode(session));
      print("what is this end ");

      print(json.encode({
        'sdp': description.sdp.toString(),
        'type': description.type.toString(),
      }));
      print("trying start");
      // print(description.toMap().toString());

      _peerConnection.setLocalDescription(description);
      print("trying 2");
      //  print(_peerConnection.defaultSdpConstraints.toString());
      print("trying ends");
      // FirebaseFirestore.instance
      //     .collection("offer")
      //     .doc(widget.ownID)
      //     .set({"offer":json.encode(session)});
    } catch (e) {
      print("catch her e");
      print(e.toString());
    }
  }

  void _createAnswerFB(String id) async {
    RTCSessionDescription description =
    await _peerConnection.createAnswer({'offerToReceiveVideo': 1});

    var session = parse(description.sdp);
    //  print(json.encode(session));
    // print(json.encode({
    //       'sdp': description.sdp.toString(),
    //       'type': description.type.toString(),
    //     }));
    FirebaseFirestore.instance
        .collection("candidate")
        .doc(widget.ownID)
        .set({"candidate": json.encode(session)});
    _peerConnection.setLocalDescription(description);

    print("addint candidate info ");

    //FirebaseFirestore.instance.collection("callQue").doc(makeRoomName(int.parse(widget.ownID), int.parse(widget.partnerid))).update({"candidate":session});
  }

  void _setRemoteDescription() async {
    String jsonString = sdpController.text;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
    new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');

    print("my suspect");
    print(description.toMap());
    print("my suspect ends");

    await _peerConnection.setRemoteDescription(description);
  }

  void _setRemoteDescriptionFB(String data) async {
    String jsonString = data;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
    new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');
    print("my suspect 1");
    print(description.toMap());
    print("my suspect 2 end");

    await _peerConnection.setRemoteDescription(description);

    print("now going for answer");
    //  _createAnswerfb(widget.ownID);

    _createAnswer();
  }

  void _setRemoteDescriptionNoAnswer(String data, String targetid) async {
    String jsonString = data;
    dynamic session = await jsonDecode('$jsonString');

    String sdp = write(session, null);

    // RTCSessionDescription description =
    //     new RTCSessionDescription(session['sdp'], session['type']);
    RTCSessionDescription description =
    new RTCSessionDescription(sdp, _offer ? 'answer' : 'offer');
    print("my suspect 3");
    print(description.toMap());
    print("my suspect 3 ends");

    await _peerConnection.setRemoteDescription(description);
    FirebaseFirestore.instance
        .collection("candidate")
        .doc(targetid)
        .get()
        .then((value) {
      print("downloaded candidate");
      print(value.data()["candidate"]);
      _addCandidateFB(value.data()["candidate"]);
    });
  }

  void _addCandidate() async {
    String jsonString = sdpController.text;
    dynamic session = await jsonDecode('$jsonString');
    print("my suspect 4");
    print(session['candidate']);
    print("my suspecr 5 ends");
    dynamic candidate = new RTCIceCandidate(
        session['candidate'], session['sdpMid'], session['sdpMlineIndex']);
    await _peerConnection.addCandidate(candidate);
  }

  void _addCandidateFB(String can) async {
    String jsonString = can;
    dynamic session = await jsonDecode('$jsonString');
    print("my suspect 4");
    print(session['candidate']);
    print("my suspecr 5 ends");
    dynamic candidate = new RTCIceCandidate(
        session['candidate'], session['sdpMid'], session['sdpMlineIndex']);
    await _peerConnection.addCandidate(candidate);
  }

  _createPeerConnection() async {
    // Map<String, dynamic> configuration = {
    //   "iceServers": [
    //     {"url": "stun:stun.l.google.com:19302"},
    //   ]
    // };

    Map<String, dynamic> configuration333 = {
      'iceServers': [

        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=udp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=udp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:443?transport=tcp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:443?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        }

      ]
    };

    Map<String, dynamic> configuration = {
      'iceServers': [
        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'urls': 'turn:86.11.136.36:3478',
          'credential': '%Welcome%4\$12345',
          'username': 'administrator'
        }
      ]
    };
    Map<String, dynamic> configuration33 = {
      'iceServers': [
        {"url": "stun:stun.l.google.com:19302"},
        {
          'urls': 'turn:numb.viagenie.ca',
          'credential': '01620645499mkl',
          'username': 'saidur.shawon@gmail.com'
        }
      ]
    };
    Map<String, dynamic> configuration220  = {'iceServers': [{'urls': 'stun:stun.services.mozilla.com'}, {'urls': 'stun:stun.l.google.com:19302'}, {'urls': 'turn:numb.viagenie.ca','credential': '01620645499mkl','username': 'saidur.shawon@gmail.com'}]};
    final Map<String, dynamic> offerSdpConstraints = {
      "mandatory": {
        "OfferToReceiveAudio": true,
        "OfferToReceiveVideo": widget.containsVideo,
      },
      "optional": [],
    };

    _localStream = await _getUserMedia();


//widget.containsVideo == false
//     if( widget.containsVideo == false){
//       for(int i = 0 ; i <_localStream.getVideoTracks().length ; i ++){
//         //_localStream.getVideoTracks()[i].(widget.isCameraOn);
//         _localStream.getVideoTracks()[i].enabled = !(_localStream.getVideoTracks()[i].enabled);
//       }
//       setState(() {
//         widget.isVideoMuted =  ! widget.isVideoMuted;
//       });
//     }




    RTCPeerConnection pc =
    await createPeerConnection(configuration, offerSdpConstraints);
    createPeerConnection(configuration, offerSdpConstraints).then((value) {
      print("Done");
      // print(value.iceConnectionState.toString());
    });


    pc.onAddStream = (stream) {


      setState(() {
        widget.streams.add(stream);
        // widget.appbart = pc.getRemoteStreams().length.toString()+" "+ pc.getLocalStreams().length.toString()+" "+ pc.getRemoteStreams().first.getVideoTracks().toString()+" "+ pc.getLocalStreams().first.getVideoTracks().toString();
        widget.appbart =widget.streams.length.toString();
      });

    };

    if (pc != null) {
      print(pc);
      print("yess error ");
    }
    pc.addStream(_localStream);
    pc.onAddStream =(e){
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };

    pc.onRemoveStream =(e){
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };


    pc.onIceCandidate = (e) {
      if (e.candidate != null) {
        print("supecrt 7");

        dynamic data = ({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMlineIndex': e.sdpMlineIndex,
        });

        if (ownCandidateID == null) {
          ownCandidateID = data;
        }
        FirebaseFirestore.instance
            .collection("candidate")
            .doc(widget.ownID)
            .set({"candidate": jsonEncode(ownCandidateID)});
        print(json.encode({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMlineIndex': e.sdpMlineIndex,
        }));
        print("supecrt 7 end");
      }
    };
    pc.onSignalingState = (e) {
      if(pc.iceConnectionState == RTCIceConnectionState.RTCIceConnectionStateConnected){
        setState(() {
          widget.didOpositConnected = true ;
        });
      }

      if( widget.didOpositConnected = true){
        if(pc.iceConnectionState ==  RTCIceConnectionState.RTCIceConnectionStateDisconnected){
          _peerConnection.close().then((value) {
            _peerConnection.dispose().then((value) {
              Navigator.pop(context);

            });
          });
        }
      }



      setState(() {
        // widget.appbart = pc.iceConnectionState.toString();
      });

      if(pc.iceConnectionState == 'disconnected') {


      }

    };






    pc.onAddStream = (stream) async{

      RTCVideoRenderer  _re = new RTCVideoRenderer();
      await _re.initialize();
      _re.srcObject = stream;
      setState(() {
        remoteRenderList.add(_re);

      });


      print('addStream: ' + stream.id);
      _remoteRenderer.srcObject = stream;

      setState(() {
        widget.streams.add(stream);
        // widget.appbart = pc.getRemoteStreams().length.toString()+" "+ pc.getLocalStreams().length.toString()+" "+ pc.getRemoteStreams().first.getVideoTracks().toString()+" "+ pc.getLocalStreams().first.getVideoTracks().toString();
        widget.appbart =remoteRenderList.length.toString();
      });

    };
    // ownOffer(pc);

    //
    return pc;
  }
  _createPeerConnectionGrp() async {
    // Map<String, dynamic> configuration = {
    //   "iceServers": [
    //     {"url": "stun:stun.l.google.com:19302"},
    //   ]
    // };

    Map<String, dynamic> configuration333 = {
      'iceServers': [

        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=udp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=udp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:3478?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        },
        {
          'url': 'turn:global.turn.twilio.com:443?transport=tcp',
          'username': '3f926f4477b772f4a60860bdb437393c678caed6bda265137c9f25ccabe7d7f3',
          'urls': 'turn:global.turn.twilio.com:443?transport=tcp',
          'credential': 'C0yrr3LLqUn35Yo3VTyPGQn84q8mLAgQO0xfspErp4g='
        }

      ]
    };

    Map<String, dynamic> configuration = {
      'iceServers': [
        {
          'url': 'stun:global.stun.twilio.com:3478?transport=udp',
          'urls': 'stun:global.stun.twilio.com:3478?transport=udp'
        },
        {
          'urls': 'turn:86.11.136.36:3478',
          'credential': '%Welcome%4\$12345',
          'username': 'administrator'
        }
      ]
    };
    Map<String, dynamic> configuration33 = {
      'iceServers': [
        {"url": "stun:stun.l.google.com:19302"},
        {
          'urls': 'turn:numb.viagenie.ca',
          'credential': '01620645499mkl',
          'username': 'saidur.shawon@gmail.com'
        }
      ]
    };
    Map<String, dynamic> configuration220  = {'iceServers': [{'urls': 'stun:stun.services.mozilla.com'}, {'urls': 'stun:stun.l.google.com:19302'}, {'urls': 'turn:numb.viagenie.ca','credential': '01620645499mkl','username': 'saidur.shawon@gmail.com'}]};
    final Map<String, dynamic> offerSdpConstraints = {
      "mandatory": {
        "OfferToReceiveAudio": true,
        "OfferToReceiveVideo": widget.containsVideo,
      },
      "optional": [],
    };

    _localStream = await _getUserMedia();


//widget.containsVideo == false
//     if( widget.containsVideo == false){
//       for(int i = 0 ; i <_localStream.getVideoTracks().length ; i ++){
//         //_localStream.getVideoTracks()[i].(widget.isCameraOn);
//         _localStream.getVideoTracks()[i].enabled = !(_localStream.getVideoTracks()[i].enabled);
//       }
//       setState(() {
//         widget.isVideoMuted =  ! widget.isVideoMuted;
//       });
//     }




    RTCPeerConnection pc =
    await createPeerConnection(configuration, offerSdpConstraints);
    createPeerConnection(configuration, offerSdpConstraints).then((value) {
      print("Done");
      // print(value.iceConnectionState.toString());
    });


    pc.onAddStream = (stream) {


      setState(() {
        widget.streams.add(stream);
        // widget.appbart = pc.getRemoteStreams().length.toString()+" "+ pc.getLocalStreams().length.toString()+" "+ pc.getRemoteStreams().first.getVideoTracks().toString()+" "+ pc.getLocalStreams().first.getVideoTracks().toString();
        widget.appbart =widget.streams.length.toString();
      });

    };

    if (pc != null) {
      print(pc);
      print("yess error ");
    }
    pc.addStream(_localStream);
    pc.onAddStream =(e){
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };

    pc.onRemoveStream =(e){
      setState(() {
        //widget.appbart = _peerConnection.getRemoteStreams().length.toString();
      });
    };


    pc.onIceCandidate = (e) {
      if (e.candidate != null) {
        print("supecrt 7");

        dynamic data = ({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMlineIndex': e.sdpMlineIndex,
        });

        if (ownCandidateID == null) {
          ownCandidateID = data;
        }
        FirebaseFirestore.instance
            .collection("candidate")
            .doc(widget.ownID)
            .set({"candidate": jsonEncode(ownCandidateID)});
        print(json.encode({
          'candidate': e.candidate.toString(),
          'sdpMid': e.sdpMid.toString(),
          'sdpMlineIndex': e.sdpMlineIndex,
        }));
        print("supecrt 7 end");
      }
    };
    pc.onSignalingState = (e) {
      if(pc.iceConnectionState == RTCIceConnectionState.RTCIceConnectionStateConnected){
        setState(() {
          widget.didOpositConnected = true ;
        });
      }





      setState(() {
        // widget.appbart = pc.iceConnectionState.toString();
      });

      if(pc.iceConnectionState == 'disconnected') {


      }

    };






    pc.onAddStream = (stream) async{

      RTCVideoRenderer  _re = new RTCVideoRenderer();
      await _re.initialize();
      _re.srcObject = stream;
      setState(() {
        remoteRenderList.add(_re);

      });


      print('addStream: ' + stream.id);
      _remoteRenderer.srcObject = stream;

      setState(() {
        widget.streams.add(stream);
        // widget.appbart = pc.getRemoteStreams().length.toString()+" "+ pc.getLocalStreams().length.toString()+" "+ pc.getRemoteStreams().first.getVideoTracks().toString()+" "+ pc.getLocalStreams().first.getVideoTracks().toString();
        // widget.appbart =remoteRenderList.length.toString();
      });

    };
    // ownOffer(pc);

    //
    return pc;
  }
  void _startRecording() async {
    // customStream.addTrack(_localStream.);

    // for(int i = 0 ; i < _localStream.getTracks() .length ; i ++){
    //   customStream.addTrack(_localStream.getTracks()[i]);
    // }

    // for(int i = 0 ; i < _remoteRenderer.srcObject.getTracks() .length ; i ++){
    //   customStream.addTrack(_remoteRenderer.srcObject.getTracks()[i]);
    // }

    _mediaRecorder = MediaRecorder();
    setState(() {
      widget.isRecording = true ;
    });


    _mediaRecorder.startWeb(_remoteRenderer.srcObject);
  }

  void _stopRecording() async {
    // final objectUrl = await _mediaRecorder?.stop();
    // setState(() {
    //   _mediaRecorder = null;
    //   widget.isRecording = false ;
    // });
    // print(objectUrl);
    // html.window.open(objectUrl, '_blank');
    // downloadFile(objectUrl);
  }
  void downloadFile(String url){
    // html.AnchorElement anchorElement =  new html.AnchorElement(href: url);
    // anchorElement.download = url;
    // anchorElement.click();
  }

  _getUserMedia() async {
    final Map<String, dynamic> mediaConstraints = {
      'audio': true,
      'video': widget.containsVideo?{
        'mandatory': {
          'minWidth':
          '320', // Provide your own width, height and frame rate here
          'minHeight': '240',
          'minFrameRate': '15',
        },
        'facingMode': 'user',
        'optional': [],
      }:false
    };

    MediaStream stream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
    // MediaStream stream   = await navigator.mediaDevices.getDisplayMedia(mediaConstraints);


    // _localStream = stream;

    _localRenderer.srcObject = stream;
    // _localRenderer.mirror = true;

    RTCVideoRenderer  _re = new RTCVideoRenderer();
    await _re.initialize();
    _re.srcObject = stream;
    setState(() {
      remoteRenderList.add(_re);

    });

    // _peerConnection.addStream(stream);

    return stream;
  }

  SizedBox videoRenderers() => SizedBox(
      height: 500,
      child: Row(children: [
        Flexible(
          child: new Container(
              key: new Key("local"),
              margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              decoration: new BoxDecoration(color: Colors.black),
              child: new RTCVideoView(_localRenderer)),
        ),
        Flexible(
          child: new Container(
              key: new Key("remote"),
              margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
              decoration: new BoxDecoration(color: Colors.black),
              child: new RTCVideoView(_remoteRenderer)),
        )
      ]));

  Widget screenView() {
    return Center(
      child: Container(
        //color: Colors.black,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [


            Align(
                alignment: Alignment.bottomCenter,
                child: new RTCVideoView(_remoteRenderer,objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,)),

            Align(
              alignment: Alignment.bottomCenter,
              child:Container(
                width: MediaQuery.of(context).size.width,
                height: 100,
                color: Color.fromARGB(127, 0, 0, 0),
                child: Center(
                  child: Container(
                    width: 300,
                    height: 100,


                    child: Center(
                      child: Row(
                        children: [
                          // Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: FloatingActionButton(
                          //
                          //     onPressed: () {
                          //       if (widget.isCaller == true) {
                          //         setState(() {
                          //           widget.callerID = widget.ownID;
                          //         });
                          //         try {
                          //           _createOffer();
                          //         } catch (e) {
                          //           setState(() {
                          //             widget.appbart = "One exxecption from catch";
                          //           });
                          //           print("One exxecption from catch");
                          //           print(e.toString());
                          //         }
                          //       } else {
                          //         setState(() {
                          //           widget.callerID = widget.partnerid;
                          //         });
                          //       }
                          //     },
                          //     child: Icon(Icons.audiotrack_outlined),
                          //   ),
                          // ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller?Colors.redAccent:Colors.greenAccent,
                              onPressed: () {
                                for(int i = 0 ; i <_localStream.getAudioTracks().length ; i ++){
                                  //_localStream.getVideoTracks()[i].(widget.isCameraOn);
                                  _localStream.getAudioTracks()[i].enabled = !(_localStream.getAudioTracks()[i].enabled);
                                }
                                setState(() {
                                  widget.isAudioMuted =  ! widget.isAudioMuted;
                                });

                              },
                              child: Icon(widget.isAudioMuted?Icons.volume_off:Icons.volume_up_rounded),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller?Colors.redAccent:Colors.greenAccent,
                              onPressed: () {
                                /*
                                _peerConnection.close().then((value) {
                                  _peerConnection.dispose().then((value) {
                                    Navigator.pop(context);
                                  });
                                });
                                */

                              },
                              child: Icon(Icons.call_end),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller?Colors.redAccent:Colors.greenAccent,
                              onPressed: ()async {


                                for(int i = 0 ; i <_localStream.getVideoTracks().length ; i ++){
                                  //_localStream.getVideoTracks()[i].(widget.isCameraOn);
                                  _localStream.getVideoTracks()[i].enabled = !(_localStream.getVideoTracks()[i].enabled);
                                }
                                setState(() {

                                  widget.isVideoMuted =  ! widget.isVideoMuted;
                                  widget.containsVideo =  ! widget.isVideoMuted;
                                  // asdasd
                                });

                                setState(()async {
                                  // _localStream = await _getUserMedia();


                                });






                                //initWorkLoad();


                              },
                              child: Icon(widget.isVideoMuted?Icons.videocam_off_outlined:Icons.videocam),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FloatingActionButton(
                              backgroundColor: widget.isCaller?Colors.redAccent:Colors.greenAccent,
                              onPressed: () {
                                // _startRecording();
                                widget.isRecording ==  true ?_stopRecording():_startRecording();

                              },
                              child: Icon( widget.isRecording ==  true ?Icons.fiber_manual_record_rounded:Icons.fiber_manual_record_outlined),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              right: 5,
              top: 5,
              child: Container(
                height: MediaQuery.of(context).size.height / 6,
                width: MediaQuery.of(context).size.width / 6,
                child: Container(
                    key: new Key("local"),
                    margin: new EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
                    decoration: new BoxDecoration(color: Colors.black),
                    child: new RTCVideoView(_localRenderer,objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,)),
              ),
            ),
            Align(
                alignment: Alignment.topLeft,
                child: Container(
                  height: 106,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: remoteRenderList.length,
                    itemBuilder: (context, index) {
                      return Container(
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Container(
                            width: 100,
                            height: 100,
                            child: new RTCVideoView(remoteRenderList[index],objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,),
                            // child: new RTCVideoView( remoteRenderList[index],),
                          ),
                        ),
                      );
                    },
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Row offerAndAnswerButtons() =>
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
        new RaisedButton(
          // onPressed: () {
          //   return showDialog(
          //       context: context,
          //       builder: (context) {
          //         return AlertDialog(
          //           content: Text(sdpController.text),
          //         );
          //       });
          // },
          onPressed: _createOffer,
          child: Text('Offer'),
          color: Colors.amber,
        ),
        RaisedButton(
          onPressed: _createAnswer,
          child: Text('Answer'),
          color: Colors.amber,
        ),
      ]);

  Row sdpCandidateButtons() =>
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
        RaisedButton(
          onPressed: _setRemoteDescription,
          child: Text('Set Remote Desc'),
          color: Colors.amber,
        ),
        RaisedButton(
          onPressed: _addCandidate,
          child: Text('Add Candidate'),
          color: Colors.amber,
        )
      ]);

  Padding sdpCandidatesTF() => Padding(
    padding: const EdgeInsets.all(16.0),
    child: TextField(
      controller: sdpController,
      keyboardType: TextInputType.multiline,
      maxLines: 4,
      maxLength: TextField.noMaxLength,
    ),
  );

  @override
  Widget build(BuildContext context) {

    // return Scaffold(body: Text(widget.ownID+"  "+widget.partnerid+"  "+widget.isCaller.toString()),);

    return  Scaffold(backgroundColor: Colors.black,body: Stack(children: [
      Align(alignment: Alignment.center,
        child: Wrap(
          children: [
            Padding(
              padding: const EdgeInsets.all(2.0),
              child: Card(color: Colors.white,shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0.0),
              ),
                child:  Container(
                  width: 320,height: 240,
                  child:Center(child: widget.self,),
                ),
              ),
            ),
            Wrap(
              children: widget.allWidgs,
            )
          ],
        ),
      )
    ],),);



    return Scaffold(
        backgroundColor: Colors.black,
        body: Container(
            child: Column(children: [
              // videoRenderers(),
              screenView(),

              Container(
                // onPressed: () {
                //   //for receiver
                //   print("clicked 1");
                //
                //
                //
                //   FirebaseFirestore.instance.collection("callQue").doc(widget.ownID).get().then((value) {
                //     String callerid = value.data()["caller"];
                //     print("clicked 3");
                //     FirebaseFirestore.instance.collection("offer").doc(callerid).get().then((value) {
                //       print("clicked 4");
                //
                //       print("downloaded offer from caller by receiver");
                //       print(callerid);
                //
                //
                //       print("now seting remote desc from caller by receiver");
                //       print(value.data()["offer"]);
                //        _setRemoteDescriptionFB(value.data()["offer"]);
                //        print("should happend everything abothe this");
                //
                //
                //
                //     });
                //   });
                //
                //   // FirebaseFirestore.instance.collection("callRequest").add({"target":widget.partnerid,"creator":widget.ownID,"offer":widget.offer});
                // },
                child: widget.callerID == widget.ownID
                    ? Text(
                  "Not applicable",
                  style: TextStyle(color: Colors.black),
                )
                    : Container(
                  height: 00,
                  child: StreamBuilder(
                    stream: FirebaseFirestore.instance
                        .collection("refresh")
                        .doc(widget.ownID)
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<DocumentSnapshot> snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.active) {
                        if (!snapshot.hasData ||
                            snapshot.hasError ||
                            snapshot.data == null) {
                          return Text("wait");
                        } else {
                          dynamic data = snapshot.data.data();
                          if (data != null &&
                              data["status"] != null &&
                              data["status"]) {
                            FirebaseFirestore.instance
                                .collection("callQue")
                                .doc(widget.ownID)
                                .get()
                                .then((value) {
                              String callerid = value.data()["caller"];
                              print("clicked 3");
                              FirebaseFirestore.instance
                                  .collection("offer")
                                  .doc(callerid)
                                  .get()
                                  .then((value) {
                                print("clicked 4");

                                print(
                                    "downloaded offer from caller by receiver");
                                print(callerid);
                                print(
                                    "now seting remote desc from caller by receiver");
                                print(value.data()["offer"]);
                                if (widget.callerID == widget.ownID) {
                                } else {
                                  _setRemoteDescriptionFB(
                                      value.data()["offer"]);
                                }
                                print(
                                    "should happend everything abothe this");

                                //
                                // FirebaseFirestore.instance.collection("refresh").doc(widget.partnerid).set({
                                //   "time":new DateTime.now().toString(),
                                //   "status":true,
                                //
                                //
                                // });

                                // FirebaseFirestore.instance.collection("refresh").doc(widget.ownID).set({
                                //   "time":new DateTime.now().toString(),
                                //   "status":false,
                                //
                                //
                                // });

                                //  FirebaseFirestore.instance.collection("refresh").doc(widget.ownID).delete();
                              });
                            });
                          }
                          return Text(data["status"].toString(),
                              style: TextStyle(color: Colors.white));
                        }
                      } else {
                        return const Center(
                          child: Text("Loading...",
                              style: TextStyle(color: Colors.white)),
                        );
                      }
                    },
                  ),
                ),
                //  child: Text("receive Call only for receiver"),
              ),
              Container(
                //caller again

                child: widget.callerID == widget.ownID
                    ? Container(
                  height: 00,
                  child: StreamBuilder(
                    stream: FirebaseFirestore.instance
                        .collection("refresh")
                        .doc(widget.ownID)
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<DocumentSnapshot> snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.active) {
                        if (snapshot.data == null) {
                          return Text("Remote is not ready",
                              style: TextStyle(color: Colors.white));
                        }

                        if (snapshot.data != null &&
                            snapshot.data.data() != null &&
                            snapshot.data.data()["status"] != null &&
                            snapshot.data.data()["status"] == true) {
                          FirebaseFirestore.instance
                              .collection("callQue")
                              .doc(widget.ownID)
                              .get()
                              .then((value) {
                            String callerid = value.data()["target"];
                            print("downloading target user");
                            print("target user id " + callerid);
                            FirebaseFirestore.instance
                                .collection("offer")
                                .doc(callerid)
                                .get()
                                .then((value) {
                              print("downloading target users offer des");
                              print("downloaded offer");
                              print(value.data()["offer"]);
                              if (widget.callerID == widget.ownID) {
                                _setRemoteDescriptionNoAnswer(
                                    value.data()["offer"], callerid);
                              }
                              //

                              return Text("Remote is ready",
                                  style: TextStyle(color: Colors.white));

                              //  print("clicked 5");
                              print("ignor now");
                              try {} catch (e) {}
                              print("ignor nown ends");

                              // _createAnswerfb(widget.ownID);
                            });
                          });
                          return Text("Remote is ready",
                              style: TextStyle(color: Colors.white));
                        }
                        return Text("Remote is not ready",
                            style: TextStyle(color: Colors.white));
                      } else {
                        return Center(
                          child: Text("Remote is not ready",
                              style: TextStyle(color: Colors.white)),
                        );
                      }
                    },
                  ),
                )
                    : Text("Non applicable", style: TextStyle(color: Colors.black)),
                //  child: Text("See Response from receiver only for caller"),
              ),
              /*
          Container(
            height: 40,
            child:(widget.ownID != "0" && widget.partnerid != "0")?  StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance.collection("callQue").doc(makeRoomName(int.parse(widget.ownID), int.parse(widget.partnerid))).snapshots(),
                builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                 print("going to set remotdes");

                 if(snapshot.hasData){
                   try{

                     FirebaseFirestore.instance.collection("offer").doc(snapshot.data.data()["caller"]).get().then((value) {
                       _setRemoteDescriptionFB(value.data()["offer"]);
                       print("sownloaded offer start");
                       print(value.data()["offer"]);
                       print("sownloaded offer end");
                     });


                   }catch(e){
                     print("catch 2 " +e.toString());
                   }
                 }




                 print("going to create answer");
                 try{
                   _createAnswer();
                 }catch(e){
                   print("catch 3" +e.toString());
                 }
/*
                  if(snapshot.hasData){
                    if(snapshot.data.data()["candidate"]!=null){
                      print("addint to candidate");
                      try{
                        _addCandidateFB(snapshot.data.data()["candidate"]);
                      }catch(e){
                        print("catch 4");
                      }


                    }
                  }
                  */


                  return Text(snapshot.hasData?snapshot.data.data().toString():"No Data");


                }):Center(
              child: Text("Wait"),
            ),
          ),
          */
              // offerAndAnswerButtons(),
              // sdpCandidatesTF(),
              // sdpCandidateButtons(),
            ])));
  }

  void submitCallReceiverPush(bool isCaller, String partnerid) {
    if(isCaller!=null && partnerid!=null ){

      if (isCaller == true) {
        Timer.periodic(Duration(milliseconds: 1500), (timer) {
          if (mounted) {
            try {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .update({"time": new DateTime.now().millisecondsSinceEpoch});
            } catch (e) {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .set({"time": new DateTime.now().millisecondsSinceEpoch});
            }
          }else  timer.cancel();

        });
      }
    }else{
      // Navigator.pop(context);
    }

  }
  void submitCallReceiverPushReverse(bool isCaller, String partnerid) {
    if(isCaller!=null && partnerid!=null ){

      if (isCaller == true) {
        Timer.periodic(Duration(milliseconds: 1500), (timer) {
          if (mounted) {
            try {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .set({"time": new DateTime.now().millisecondsSinceEpoch});
            } catch (e) {
              widget.firestore
                  .collection("incomming")
                  .doc(partnerid)
                  .update({"time": new DateTime.now().millisecondsSinceEpoch});
            }
          }else  timer.cancel();

        });
      }
    }else{
      // Navigator.pop(context);
    }

  }

  void submitCallEngaggePush(String ownID) {
    Timer.periodic(Duration(milliseconds: 1500), (timer) {
      if (mounted) {
        try {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .set({"time": new DateTime.now().millisecondsSinceEpoch});
        } catch (e) {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .update({"time": new DateTime.now().millisecondsSinceEpoch});
        }
      }else  timer.cancel();

    });
  }
  void submitCallEngaggePushReverse(String ownID) {
    Timer.periodic(Duration(milliseconds: 1500), (timer) {
      if (mounted) {
        try {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .update({"time": new DateTime.now().millisecondsSinceEpoch});
        } catch (e) {
          widget.firestore
              .collection("incall")
              .doc(ownID)
              .set({"time": new DateTime.now().millisecondsSinceEpoch});
        }
      }else  timer.cancel();

    });
  }

  void initWorkLoad() {

    int currentParticipents = 0 ;
    Timer.periodic(Duration(milliseconds: 1000), (timer) {
      if (mounted) {
        widget.firestore.collection(widget.room_id).doc(widget.ownID).set({"uid":widget.ownID,"time":new DateTime.now().millisecondsSinceEpoch});


      }else  timer.cancel();

    });
    widget.firestore.collection(widget.room_id).snapshots().listen((event) {
      setState(() {
        widget.appbart = "0";
      });
      if(event.size>0 && event.docs.length>0) {
        currentParticipents = 0;
        setState(() {
          widget.appbart =currentParticipents.toString();
        });
        for(int i = 0 ; i <  event.docs.length;i++){
          if(event.docs[i].data()["uid"]!=widget.ownID &&  event.docs[i].data()["time"]+3000>DateTime.now().millisecondsSinceEpoch){
            currentParticipents++;
            if(widget.peerIds.contains(event.docs[i].id)){

            }else{
              setState(() {
                Random random = new Random();
                int randomNumber = random.nextInt(9999);
                String peerID = "peerId"+randomNumber.toString()+DateTime.now().millisecondsSinceEpoch.toString();
                talkWithHim(event.docs[i].id,peerID);
                widget.peerIds.add(event.docs[i].id);

              });

            }

            // talkWithHim(event.docs[i].id);





          }
        }
        setState(() {
          widget.appbart =currentParticipents.toString();
        });


      }
    });

    widget.firestore.collection(widget.room_id).get().then((value) {

    });




  }
  void initCallIntent(String callTYpe,String ownid, String partner, bool isCaller, FirebaseFirestore firestore,BuildContext context) async{

    ownid.replaceAll("dd", "d");
    ownid.replaceAll("pp", "p");

    partner.replaceAll("dd", "d");
    partner.replaceAll("pp", "p");



    await  firestore.collection("callQue").doc(ownid).set(  {"caller":isCaller?ownid:partner, "target": isCaller?partner:ownid});
    await firestore.collection("callQue").doc(partner).set( {"caller":isCaller?ownid:partner, "target": isCaller?partner:ownid});
    await firestore.collection("refresh").doc(ownid).delete();
    await  firestore.collection("refresh").doc(partner).delete();

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>  WillPopScope(
              onWillPop: () async => false,
              child: GrpUnit(
                  containsVideo: false,
                  ownID:ownid,
                  partnerid:partner,
                  isCaller:
                  isCaller,
                  firestore:
                  firestore),

            )));
  }

  void talkWithHim(String id,String peerID)async {

    List<String>allids = [id,widget.ownID];
    allids.sort();

    bool isCaller = allids.last==id?true:false;
    //first user is the caller


    await widget.firestore.collection("callQue").doc(widget.ownID).set({
      "caller": isCaller ? widget.ownID : id,
      "target": isCaller ? id : widget.ownID
    });
    await widget.firestore.collection("callQue").doc(id).set({
      "caller": isCaller ? widget.ownID : id,
      "target": isCaller ? id : widget.ownID
    });
    await widget.firestore.collection("refresh").doc(widget.ownID).delete();
    await widget.firestore.collection("refresh").doc(id).delete();


    setState(() {
      //  widget.grids = Text(allids.first+" "+allids.last+"  "+id+"  "+widget.ownID);

      //  widget.allWidgs.add(Text("new scre"));
      // widget.allWidgs.clear();

      widget.allWidgs.add(Padding(
        padding: const EdgeInsets.all(2.0),
        child: Card(color: Colors.white,shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0.0),
        ),
          child: Container(color: Colors.white,
            width: 320,
            child:Wrap(children: [
              Center(child: Text(isCaller.toString()),),
              Container(
                width: 320,height: 240,
                child: GrpUnit(
                  containsVideo:  false,
                  ownID: widget.ownID,
                  partnerid: id,
                  isCaller: isCaller,
                  firestore: widget.firestore,
                  partnerPair: allids.first + "-" + allids.last,


                ),
              )
            ],),
          ),
        ),
      ));

/*
      widget.allWidgs.add(Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0.0),
        ),color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child:Container(
              width: 320,height: 240,
              child: GrpGridMyWebCall(peerID:peerID,
                  containsVideo:true,
                  ownID:widget.ownID,
                  partnerid:id,
                  isCaller:
                  isCaller,
                  firestore:
                  widget.firestore),
            ),
          ),
        ),
      ));
      */
      /*
      widget.allWidgs.add( Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(width: 320,height: 240,
          child: GrpGridMyWebCall(
              containsVideo:true,
              ownID:widget.ownID,
              partnerid:id,
              isCaller:
              isCaller,
              firestore:
              widget.firestore),
        ),
      ));
      */

    });































    // widget.firestore.collection(widget.room_id).doc(widget.ownID).






  }
}

String makeRoomName(int one, int two) {
  if (one > two)
    return "" + one.toString() + "-" + two.toString();
  else
    return "" + two.toString() + "-" + one.toString();
}



class MainHomePage extends StatefulWidget {
  @override
  _MainHomePageState createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Row(
          children: [
            Container(
              width: 300,
              height: MediaQuery.of(context).size.height,
            )
          ],
        ),
      ),
    );
  }
}
