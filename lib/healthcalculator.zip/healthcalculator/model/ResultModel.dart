class ResultModel{


  String value1;
  String value2;
  String value3;
}