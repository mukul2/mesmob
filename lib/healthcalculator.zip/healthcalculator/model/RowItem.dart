import 'dart:ui';

class RowItem {
  String description;
  int id;
  int imageId;
  int theme;
  int icon;
  Color color;
  String title;
  String pageName;
  String resultText;
  String resultDesc;
  String pdf;
  String image="water_intake.png";
  String transImage;


  // RowItem(int i, String str, String str2, int theme, int icon, int color) {
  //   this.imageId = i;
  //   this.title = str;
  //   this.description = str2;
  //   this.theme = theme;
  //   this.icon = icon;
  //   this.color = color;
  // }

  // RowItem() {

  // }
}
