

import 'package:maulajimessenger/healthcalculator/model/RowItem.dart';

class ScreenArguments {
  final RowItem rowItem;

  ScreenArguments(this.rowItem);
}