import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

String _baseUrl = "https://api.callgpnow.com/api/";
String _baseUrl_image = "https://api.callgpnow.com/";

class DeviceModeDesktop {
  static DeviceModeDesktop model = null;
  final StreamController<void> _Controller = StreamController<void>.broadcast();

  Stream<void> get outData => _Controller.stream;

  Sink<void> get inData => _Controller.sink;

  dataReload() {
    fetch().then((value) => inData.add(value));
  }

  void dispose() {
    _Controller.close();
  }

  static DeviceModeDesktop getInstance() {
    if (model == null) {
      model = new DeviceModeDesktop();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}

class DeviceModeMobile{
  static DeviceModeMobile model = null;
  final StreamController<void> _Controller = StreamController<bool>.broadcast();

  Stream<void> get outData => _Controller.stream;

  Sink<void> get inData => _Controller.sink;

  dataReload() {
    fetch().then((value) => inData.add(value));
  }

  void dispose() {
    _Controller.close();
  }

  static DeviceModeMobile getInstance() {
    if (model == null) {
      model = new DeviceModeMobile();
      return model;
    } else {
      return model;
    }
  }

  Future<void> fetch() async {
    return;
  }
}
