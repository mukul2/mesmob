import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';




class Auth {

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;

  Auth({this.auth,this.firestore});

  Stream<User> get user => auth.authStateChanges();

  Future<bool> createAccount({String name,String email, String password}) async {
    try {
      UserCredential result = await auth.createUserWithEmailAndPassword(email: email, password: password);
      User user = result.user;
      await user.updateProfile(displayName: name);

      await firestore.collection("users").add({"name":name,"uid":user.uid,"email":user.email});




      return true;
    } on FirebaseAuthException catch (e) {
      print(e.toString());
      return false;
    } catch (e) {
      print(e.toString());
      rethrow;
    }
  }





  Future<String> signIn({String email, String password}) async {
    try {
      await auth.signInWithEmailAndPassword(
          email: email.trim(), password: password.trim());
      return "Success";
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (e) {
      rethrow;
    }
  }

  Future<String> signOut() async {
    try {
      await auth.signOut();
      return "Success";
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (e) {
      rethrow;
    }
  }
}
