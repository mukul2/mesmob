import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:maulajimessenger/Screens/logged_in_home.dart';
import 'package:maulajimessenger/login.dart';
import 'package:maulajimessenger/services/Auth.dart';
import 'package:maulajimessenger/services/Signal.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:maulajimessenger/services/socket2.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:bubble/bubble.dart';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:socket_io_client/socket_io_client.dart';
void main() {
  // Dart client
  //HttpOverrides.global = new MyHttpOverrides();
  //IO.Socket socket = IO.io('http://localhost:3000');
  // IO.Socket  socket = IO.io('http://localhost:3000', <String, dynamic>{
  //   'transports': ['websocket'],
  // });
  // socket.onConnect((_) {
  //   print('connect');
  //   socket.emit('msg', 'test');
  // });
  // socket.on('event', (data) => print(data));
  // socket.onDisconnect((_) => print('disconnect'));
  // socket.on('fromServer', (_) => print(_));
   //HttpOverrides.global = new MyHttpOverrides();
  // print("trying to connect");
  // IO.Socket  socket = IO.io('https://mklmkl.herokuapp.com/', <String, dynamic>{
  //   'transports': ['websocket'],
  // });
  // socket.onConnect((_) {
  //   print('connected signal');
  //   //socket.emit('msg', 'test');
  // });
  //runApp(MyAppSo());
  // print("trying to con");
  //
  // try {
  //   //Connect the client to the socket
  //   IO.Socket  socket = IO.io('http://localhost:3000',
  //       <String, dynamic>{
  //         'transports': ['websocket'],
  //       });
  //   //Join the user with username to the room with roomId
  //   //Listen to the sendMessage events emitted from the socket
  //
  // } catch (e) {
  //   print("my exception");
  //   print(e);
  // }


  //
  // IO.Socket socket = IO.io('http://localhost:3000',
  //     OptionBuilder()
  //         .setTransports(['websocket']) // for Flutter or Dart VM
  //         .setExtraHeaders({'foo': 'bar'}) // optional
  //         .build());
  // socket.onConnect((_) {
  //   print('connect');
  //   socket.emit('msg', 'test');
  // });
  // socket.on('mkl', (data) => print(data));
  // socket.onDisconnect((_) => print('disconnect'));
  // socket.on('fromServer', (_) => print(_));

//   IO.Socket socket = IO.io('https://signal1.maulaji.com', <String, dynamic>{
//     'transports': ['websocket', 'polling'],
//     'autoConnect': false,
//   });
//
// // Dart client
//   socket.on('connect', (_) {
//     print('connect');
//   });
//   socket.on('mkl', (data) => print(data));
//   socket.on('disconnect', (_) => print('disconnect'));
//   socket.on('fromServer', (_) => print(_));
//
// // add this line
//   socket.connect();



//
// // add this line
//   socket.connect();
 // SocketAna.emit('test_connection');
  //SocketService().createSocketConnection();

  // Dart client
  // IO.Socket socket = IO.io('https://signal1.maulaji.com',IO.OptionBuilder().setTransports(['websocket']).build());
  // print("tyring to connect");
  // socket.onConnect((_) {
  //   print('connect');
  //   socket.emit('msg', 'test');
  // });
  // socket.on('event', (data) => print(data));
  // socket.onDisconnect((_) => print('disconnect'));
  // socket.on('fromServer', (_) => print(_));
  // Socket socket = IO.io(
  //   'https://mklmkl.herokuapp.com/',
  //   <String, dynamic>{
  //     'transports': ['websocket']
  //   },
  // );
  // socket.on('connection', (_) => print('ana loves me'));
  // socket.on('connect', (_) => print('ana loves me'));
  // socket.connect();
  // // Socket socket = io('https://signal.maulaji.com',
  // //     OptionBuilder()
  // //         .setTransports(['websocket']) // for Flutter or Dart VM
  // //         .disableAutoConnect()  // disable auto-connection
  // //         .setExtraHeaders({'foo': 'bar'}) // optional
  // //         .build()
  // // );
  // socket.onConnect((_) {
  //   print('connect');
  //   socket.emit('msg', 'test');
  // });
  // socket.on('mkl', (val) => print(val));
  // socket.connect();
  // socket.on('mkl', (val) => print(val));
  //HttpOverrides.global = new MyHttpOverrides();
  //connectAndListen();
  //Socket2.initSocket();



 runApp(MyApp());
  //runApp(MaterialApp(home: Soc2(),));
}
// class MyHttpOverrides extends HttpOverrides {
//   @override
//   HttpClient createHttpClient(SecurityContext context) {
//     return super.createHttpClient(context)
//       ..badCertificateCallback =
//           (X509Certificate cert, String host, int port) => true;
//   }
// }
void connectAndListen(){
  print("inside");
  //IO.Socket socket = IO.io('https://signal1.maulaji.com', IO.OptionBuilder().setTransports(['websocket']).build());
  IO.Socket socket = IO.io('https://signal1.maulaji.com');

  socket.onConnect((_) {
    print('connect');
    socket.emit('msg', 'test');
  });


}
class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maulaji Talk',
      theme: ThemeData(
        fontFamily: 'Poppins',

        primarySwatch: Colors.blue,
      ),
      home:  FutureBuilder(
        // Initialize FlutterFire:
        future: Firebase.initializeApp(),
        builder: (context, snapshot) {
          // Check for errors
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                child: Text("Error"),
              ),
            );
          }

          // Once complete, show your application
          if (snapshot.connectionState == ConnectionState.done) {
            return Root();
          }

          // Otherwise, show something whilst waiting for initialization to complete
          return Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        },
      ),
    );
  }
}

class Root extends StatefulWidget {
  Root({Key key}) : super(key: key);
  dynamic userData;

  @override
  _RootState createState() => _RootState();
}

class _RootState extends State<Root> {
  final FirebaseAuth _auth = FirebaseAuth.instance;



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (_auth != null &&
        _auth.currentUser != null &&
        _auth.currentUser.uid != null) {
      // fetchuser();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Auth(auth: _auth).user,
      builder: (BuildContext context, AsyncSnapshot<User> snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          if (snapshot.hasData == false ||
              snapshot.data == null ||
              snapshot.data.uid == null) {
            // login screen
            return Login(
              auth: _auth,

            );
          } else {
            // home screen
          //  IO.Socket socket = AppSignal().initSignal();
            return  FutureBuilder<SharedPreferences>(
                future: SharedPreferences.getInstance(), builder: (BuildContext context,AsyncSnapshot<SharedPreferences> projectSnap) {
              if(projectSnap.hasData && projectSnap.data!=null){
                return    Home(socket:  AppSignal().initSignal(),
                  auth: FirebaseAuth.instance,

                  sharedPreferences: projectSnap.data,
                );
              }else {
                return Scaffold(
                  body: Center(
                      child: CircularProgressIndicator()
                  ),
                );
              }

            });

          }
        } else {
          return const Scaffold(
            body: Center(
              child: Text("Loading..."),
            ),
          );
        }
      },
    );
  }
}
class MyAppSoc extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final title = 'WebSocket Demo';
    return MaterialApp(
      title: title,

    );
  }
}

class MyHomePage2 extends StatefulWidget {
  final String title;

  MyHomePage2({Key key, @required this.title,l})
      : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage2> {
  TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Form(
              child: TextFormField(
                controller: _controller,
                decoration: InputDecoration(labelText: 'Send a message'),
              ),
            ),
            StreamBuilder(

              builder: (context, snapshot) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24.0),
                  child: Text(snapshot.hasData ? '${snapshot.data}' : ''),
                );
              },
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _sendMessage,
        tooltip: 'Send message',
        child: Icon(Icons.send),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  void _sendMessage() {
    if (_controller.text.isNotEmpty) {
    }
  }

  @override
  void dispose() {
    super.dispose();
  }
}
class  Soc2 extends StatefulWidget {

  @override
  _Soc2State createState() => _Soc2State();
}

class _Soc2State extends State< Soc2> {
  Socket socket;
  IO.Socket socket2;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connectToServer();
    //connect2();
  }
  void connectToServer() {
    try {
      //https://signal1.maulaji.com
      // Configure socket transports must be sepecified
      socket = io('https://signal1.maulaji.com:3000', <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
      });

      // Connect to websocket
      socket.connect();


      // Handle socket events
      socket.on('connect', (data) => print('connect: ${socket.id}'));
     //  socket.on('location', handleLocationListen);
     //  socket.on('typing', handleTyping);
     // // socket.on('message', (data)=>print("mkl"));
     //  socket.on('disconnect', (data) => print('disconnect'));
     //  socket.on('fromServer', (dynamic) => print("er"));
     //  socket.on('message', (data) => print(data.toString()));
      socket.on("mkl", (data) => print("ok"));


    } catch (e) {
      print(e.toString());
    }


  }

  // Send Location to Server
  sendLocation(Map<String, dynamic> data) {
    socket.emit("location", data);
  }

  // Listen to Location updates of connected usersfrom server
  handleLocationListen(Map<String, dynamic> data) async {
    print(data);
  }

  // Send update of user's typing status
  sendTyping(bool typing) {
    socket.emit("typing",
        {
          "id": socket.id,
          "typing": typing,
        });
  }

  // Listen to update of typing status from connected users
  void handleTyping(Map<String, dynamic> data) {
    print(data);
  }

  // Send a Message to the server
  sendMessage(String message) {
    socket.emit("message",
      {
        "id": socket.id,
        "message": message, // Message to be sent
        "timestamp": DateTime.now().millisecondsSinceEpoch,
      },
    );
  }

  // Listen to all message events from connected users
  void handleMessage(Map<String, dynamic> data) {
    print(data.toString());
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text("app"),),body: SingleChildScrollView(
      child: InkWell(onTap: (){
        socket2.emit("mkl","dada");
        socket2.emit("mkl",{"dada":124});
        //sendMessage("mm");
      },child: Container(child: Text("Send"),),),
    ),);
  }

  void connect2() {
    // Dart client
    socket2 = IO.io('https://signal1.maulaji.com');
    socket2.onConnect((_) {
      print('connect');
      socket2.emit('msg', 'test');
    });
    socket2.on('event', (data) => print(data));
    socket2.onDisconnect((_) => print('disconnect'));
    socket2.on('fromServer', (_) => print(_));
  }
}

class MyAppSo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chat App',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          elevation: 1,
        ),
        primarySwatch: Colors.blue,
        accentColor: Colors.white,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        buttonColor: Colors.blue,
        buttonTheme: ButtonThemeData(
            buttonColor: Colors.blue,
            textTheme: ButtonTextTheme.accent,
            padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20),
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
      ),
      home: HomePageS(),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
class HomePageS extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text("Welcome To IBK Chat", style: TextStyle(fontSize: 28)),
            const SizedBox(height: 16),
            Text("Create or join a room and start talking!",
                style: TextStyle(fontSize: 18, color: Colors.grey[700])),
            const SizedBox(height: 16),
            RaisedButton(
              onPressed: () async {
                try {
                  final res = await showDialog<Map<String, String>>(
                      context: context,
                      builder: (context) {
                        TextEditingController roomIdController =
                        TextEditingController();
                        TextEditingController nameController =
                        TextEditingController();
                        GlobalKey<FormState> formkey = GlobalKey<FormState>();
                        return AlertDialog(
                          actions: [
                            FlatButton(
                              child: Text("Cancel"),
                              onPressed: () => Navigator.of(context).pop(),
                            ),
                            FlatButton(
                              child: Text("Join"),
                              onPressed: () {
                                if (formkey.currentState.validate()) {
                                  Navigator.of(context).pop({
                                    "roomId": roomIdController.text,
                                    "username": nameController.text
                                  });
                                }
                              },
                            ),
                          ],
                          title: Text(
                              "Enter a room name and username to join or create a room!"),
                          contentPadding: EdgeInsets.all(18),
                          content: Form(
                            key: formkey,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  decoration: InputDecoration(
                                    labelText: "Room Name",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  validator: (val) {
                                    if (val.length < 4) {
                                      return "Has to be longer than 3";
                                    }
                                    return null;
                                  },
                                  controller: roomIdController,
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                TextFormField(
                                  decoration: InputDecoration(
                                    labelText: "Username",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  validator: (val) {
                                    if (val.length < 4) {
                                      return "Has to be longer than 3";
                                    }
                                    return null;
                                  },
                                  controller: nameController,
                                ),
                              ],
                            ),
                          ),
                        );
                      });
                  if (res == null) return;
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => ChatPage(
                        roomId: res["roomId"],
                        username: res["username"],
                      )));
                } catch (e) {
                  print(e);
                }
              },
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Enter A Room",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w300),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Icon(Icons.person_add_alt),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class ChatPage extends StatefulWidget {
  final String roomId;
  final String username;

  const ChatPage({Key key, this.roomId, this.username}) : super(key: key);

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  ScrollController controller = ScrollController();
  GlobalKey<FormState> formKey;
  TextEditingController messageController = TextEditingController();
  IO.Socket socket;
  String theRoomId;
  List<Message> messages = [];
  FocusNode messageNode;

  @override
  void initState() {
    messageNode = FocusNode();
    initSocket();
    super.initState();
  }

  @override
  void dispose() {
    messageNode.dispose();
    return super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (this.mounted) {
      return super.setState(fn);
    }
  }

  void initSocket() {
    try {
      socket = IO.io('http://localhost:5000', <String, dynamic>{
        'transports': ['websocket'],
      });
      socket.emit("joinRoom", [widget.roomId, widget.username]);
      socket.on("sendMessage", (res) {
        Message msg = (res is String)
            ? Message(message: res, username: "Admin")
            : Message(message: res[0], username: res[1]);
        if (msg.username == widget.username) {
          return;
        }
        setState(() {
          messages.add(msg);
          controller.animateTo(controller.position.maxScrollExtent,
              duration: Duration(milliseconds: 100), curve: Curves.linear);
        });
      });
    } catch (e) {
      print(e);
    }
  }

  void sendMessage() {
    try {
      socket.emit("sendMessage",
          [messageController.text, widget.roomId, widget.username]);
      Message msg =
      Message(message: messageController.text, username: widget.username);
      setState(() {
        messages.add(msg);
        controller.animateTo(controller.position.maxScrollExtent,
            duration: Duration(milliseconds: 100), curve: Curves.linear);
      });
      messageController.clear();
      messageNode.requestFocus();
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: SelectableText(widget.roomId),),
      backgroundColor: Colors.blueGrey[50],
      body: Column(
        children: [
          Expanded(
            flex: 9,
            child: Container(
              child: ListView.builder(
                padding: EdgeInsets.symmetric(vertical: 2, horizontal: 16),
                controller: controller,
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  final message = messages[index];
                  if (message.username == widget.username) {
                    return Bubble(
                      margin: BubbleEdges.only(top: 8),
                      radius: Radius.circular(12),
                      alignment: Alignment.topRight,
                      nip: BubbleNip.rightTop,
                      elevation: 2,
                      color: Color.fromRGBO(225, 255, 199, 1.0),
                      child: SelectableText(message.message,
                        textAlign: TextAlign.right,
                        style: TextStyle(fontSize: 18),
                      ),
                    );
                  }
                  return Bubble(
                    margin: BubbleEdges.only(top: 8),
                    radius: Radius.circular(12),
                    alignment: Alignment.topLeft,
                    nip: BubbleNip.leftTop,
                    elevation: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(message.username, style: TextStyle(fontSize: 11, color: Colors.grey,), textAlign: TextAlign.left,),
                        SelectableText(message.message,
                          textAlign: TextAlign.left,
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
          Expanded(
            child: Row(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.01,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.85,
                  child: Form(
                    key: formKey,
                    child: TextFormField(
                      focusNode: messageNode,
                      onFieldSubmitted: (val) {
                        sendMessage();
                      },
                      decoration: InputDecoration(
                        labelText: "Message",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      controller: messageController,
                    ),
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.02,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.11,
                  child: RaisedButton(
                    child: Text("Send"),
                    onPressed: () {
                      sendMessage();
                    },
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.01,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
class Message {
  String username;
  String message;
  Message({
    this.username,
    this.message,
  });

  Message copyWith({
    String username,
    String message,
  }) {
    return Message(
      username: username ?? this.username,
      message: message ?? this.message,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'message': message,
    };
  }

  factory Message.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Message(
      username: map['username'],
      message: map['message'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Message.fromJson(String source) =>
      Message.fromMap(json.decode(source));

  @override
  String toString() => '$username: $message';

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;

    return o is Message && o.username == username && o.message == message;
  }

  @override
  int get hashCode => username.hashCode ^ message.hashCode;
}