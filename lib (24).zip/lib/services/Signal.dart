import 'dart:convert';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:maulajimessenger/services/Settings.dart';

import 'package:socket_io_client/socket_io_client.dart' as IO;

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}




class AppSignal {

  IO.Socket socket;

  AppSignal();
  IO.Socket initSignal(){
    if(socket==null){

      String link =AppSettings().Signal_link;
      //String link = "https://signal1.maulaji.com/";
      //String link = "http://192.168.42.3:3000";
    // String link = AppSettings().Signal_link;
      //print('trying with '+link);
      //https://signal1.maulaji.com

      // _socket = client.io('http://localhost:3000',
      //     <String, dynamic>{
      //       'transports': ['websocket'],
      //     });
    //  HttpOverrides.global = new MyHttpOverrides();
      print("trying to connect");
      IO.Socket  socket = IO.io(link, <String, dynamic>{
        'transports': ['websocket', 'polling', 'flashsocket'],
      });
    //  socket = IO.io("https://signal1.maulaji.com");
      socket.onConnect((_) {
        print('connect with '+link);
        socket.emit('msg', 'test');
      });
       socket.onError((data) {
         print("error");
         print(data.toString());
       });


      //socket = IO.io('https://signal1.maulaji.com');
      //socket = IO.io('http://localhost:3000');
      // socket = IO.io("https://signal1.maulaji.com", IO.OptionBuilder().setTransports(['websocket']).build());
      // socket.onConnect((_) {
      //   print("connected");
      //
      // });
      print("returng new");
      return socket;
    }else{
      print("returng old");

      return socket;
    }

  }




}