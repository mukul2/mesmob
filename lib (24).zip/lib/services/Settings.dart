import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:maulajimessenger/services/Signal.dart';
import 'package:http/http.dart' as http;



class AppSettings {
 // String Signal_link = "https://signal-socket-ibsjl.ondigitalocean.app";

  //String Signal_link = "https://signal.maulaji.com";
  //String Signal_link = "https://signal.maulaji.com";
  //String Signal_link = "https://pretty-cheetah-66.loca.lt";
  String Signal_link = "https://talkmaulaji.loca.lt";

  //String Signal_link = "https://signal1.maulaji.com";

 // String Api_link = "http://localhost:3001/";
  String Api_link = "https://api.maulaji.com/";


  AppSettings();


}
